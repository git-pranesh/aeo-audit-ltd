import { z } from "zod";

// Platform scores schema
export const platformScoresSchema = z.object({
  chatgpt: z.number().min(0).max(100),
  perplexity: z.number().min(0).max(100),
  gemini: z.number().min(0).max(100),
  claude: z.number().min(0).max(100)
});

// Technical findings schema
export const technicalFindingsSchema = z.object({
  domainAuthority: z.enum(["High", "Medium", "Low"]),
  contentStructure: z.enum(["Excellent", "Good", "Fair", "Poor"]),
  schemaMarkup: z.enum(["Implemented", "Partial", "Missing"]),
  entityRecognition: z.enum(["Strong", "Moderate", "Weak"])
});

// Audit results schema
export const auditResultsSchema = z.object({
  overallScore: z.number().min(0).max(100),
  letterGrade: z.enum(["A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "F"]),
  platformScores: platformScoresSchema,
  strengths: z.array(z.string()).length(3),
  weaknesses: z.array(z.string()).length(3),
  technicalFindings: technicalFindingsSchema
});

// Content topic schema (enhanced)
export const contentTopicSchema = z.object({
  topic: z.string(),
  confidence: z.number().min(30).max(95),
  justification: z.string(),
  platforms: z.array(z.string()),
  // New enhanced fields (optional for backward compatibility)
  searchVolume: z.string().optional(),
  competitionLevel: z.string().optional(),
  currentAIResponse: z.string().optional(),
  competitorGap: z.string().optional(),
  optimalContentStructure: z.object({
    format: z.string(),
    length: z.string(),
    sections: z.array(z.string()),
    contentType: z.string()
  }).optional(),
  platformOptimization: z.object({
    chatgpt: z.string(),
    perplexity: z.string(),
    gemini: z.string(),
    claude: z.string()
  }).optional(),
  citationPotential: z.object({
    currentCitations: z.string(),
    opportunityScore: z.number().min(0).max(100),
    timeToRank: z.string()
  }).optional()
});

// Content topics schema (flexible length for dynamic topic generation)
export const contentTopicsSchema = z.object({
  authoritative: z.array(contentTopicSchema).min(1),
  thoughtLeadership: z.array(contentTopicSchema).min(1),
  competitiveAdvantage: z.array(contentTopicSchema).min(1),
  emergingOpportunity: z.array(contentTopicSchema).min(1)
});

// New enhanced schemas
export const companyIntelligenceSchema = z.object({
  industry: z.string(),
  businessType: z.string(),
  targetAudience: z.string(),
  valueProposition: z.string(),
  marketPosition: z.string(),
  businessModel: z.string().optional(),
  geographicFocus: z.array(z.string()).optional(),
  serviceOfferings: z.array(z.string()).optional()
});

export const competitorAnalysisSchema = z.object({
  mainCompetitors: z.array(z.string()),
  competitorStrengths: z.array(z.string()),
  competitorWeaknesses: z.array(z.string()),
  marketOpportunities: z.array(z.string()),
  competitiveAdvantages: z.array(z.string()).optional()
});

export const citationIntelligenceSchema = z.object({
  currentCitationPresence: z.object({
    totalCitations: z.number(),
    platformBreakdown: platformScoresSchema,
    topCitedContent: z.array(z.string())
  }),
  competitorCitationAnalysis: z.object({
    competitorCitations: z.record(z.number()),
    citationGaps: z.array(z.string())
  }),
  citationOpportunities: z.array(z.string())
});

export const marketContextSchema = z.object({
  industryTrends: z.array(z.string()),
  seasonalFactors: z.object({
    peakSeason: z.string(),
    contentTiming: z.string(),
    searchTrends: z.string()
  }).optional(),
  marketSize: z.object({
    globalMarket: z.string(),
    marketGrowth: z.string(),
    targetMarketSize: z.string()
  }).optional()
});

export const enhancedRecommendationSchema = z.object({
  priority: z.enum(["High", "Medium", "Low"]),
  category: z.string(),
  recommendation: z.string(),
  implementation: z.object({
    timeframe: z.string(),
    effort: z.enum(["Low", "Medium", "High"]),
    expectedImpact: z.string(),
    specificActions: z.array(z.string())
  }).optional(),
  competitiveAdvantage: z.string().optional()
});

// Complete audit data schema (enhanced while keeping existing structure)
export const auditDataSchema = z.object({
  // Existing structure (unchanged)
  auditResults: auditResultsSchema,
  contentTopics: contentTopicsSchema,
  recommendations: z.array(z.string()).min(1),
  // New enhanced fields (optional for backward compatibility)
  companyIntelligence: companyIntelligenceSchema.optional(),
  competitorAnalysis: competitorAnalysisSchema.optional(),
  citationIntelligence: citationIntelligenceSchema.optional(),
  marketContext: marketContextSchema.optional(),
  enhancedRecommendations: z.array(enhancedRecommendationSchema).optional(),
  processingDetails: z.object({
    analysisDepth: z.string(),
    competitorsAnalyzed: z.number(),
    dataSourcesUsed: z.array(z.string()),
    processingTime: z.string()
  }).optional()
});

// API request/response schemas
export const auditRequestSchema = z.object({
  websiteUrl: z.string().url(),
  userPlan: z.string().optional(),
  userId: z.string().optional(),
  userEmail: z.string().email().optional(),
  topicsPerCategory: z.number().optional()
});

export const auditResponseSchema = z.object({
  success: z.boolean(),
  websiteUrl: z.string(),
  auditData: auditDataSchema,
  generatedAt: z.string()
});

// Types
export type PlatformScores = z.infer<typeof platformScoresSchema>;
export type TechnicalFindings = z.infer<typeof technicalFindingsSchema>;
export type AuditResults = z.infer<typeof auditResultsSchema>;
export type ContentTopic = z.infer<typeof contentTopicSchema>;
export type ContentTopics = z.infer<typeof contentTopicsSchema>;
export type AuditData = z.infer<typeof auditDataSchema>;
export type AuditRequest = z.infer<typeof auditRequestSchema>;
export type AuditResponse = z.infer<typeof auditResponseSchema>;

// New enhanced types
export type CompanyIntelligence = z.infer<typeof companyIntelligenceSchema>;
export type CompetitorAnalysis = z.infer<typeof competitorAnalysisSchema>;
export type CitationIntelligence = z.infer<typeof citationIntelligenceSchema>;
export type MarketContext = z.infer<typeof marketContextSchema>;
export type EnhancedRecommendation = z.infer<typeof enhancedRecommendationSchema>;
