import axios from 'axios';
import { getMasterPrompt } from './prompt-service';
import { perplexityTracker } from './perplexity-tracker';

interface TopicBatch {
  topics: any[];
  batchNumber: number;
}

interface DeduplicationResult {
  uniqueTopics: any[];
  duplicatesRemoved: number;
  originalCount: number;
}

export class BatchTopicGenerator {
  private apiKey: string;
  private auditId: string;
  private userId?: string;
  
  constructor(apiKey: string, auditId: string, userId?: string) {
    this.apiKey = apiKey;
    this.auditId = auditId;
    this.userId = userId;
  }

  /**
   * Generate a single batch of topics for a specific category
   */
  async generateBatch(
    websiteUrl: string,
    category: 'authoritative' | 'thoughtLeadership' | 'competitiveAdvantage' | 'emergingOpportunity',
    batchSize: number,
    batchNumber: number,
    existingTopics: string[] = []
  ): Promise<any[]> {
    console.log(`\n📦 Generating batch ${batchNumber} for ${category} (${batchSize} topics)`);
    
    const confidenceRanges = {
      authoritative: '85-95',
      thoughtLeadership: '70-84',
      competitiveAdvantage: '50-69',
      emergingOpportunity: '30-49'
    };

    const categoryDescriptions = {
      authoritative: 'high-authority topics where the website has strong expertise',
      thoughtLeadership: 'industry thought leadership and trend analysis topics',
      competitiveAdvantage: 'topics that highlight what makes THIS company unique vs competitors',
      emergingOpportunity: 'future trends and emerging market opportunities'
    };

    // Build exclusion list from existing topics
    const exclusionText = existingTopics.length > 0
      ? `\nALREADY GENERATED (DO NOT REPEAT): ${existingTopics.join(', ')}`
      : '';

    const batchPrompt = `You are an AI SEO analyst. Browse ${websiteUrl} and generate EXACTLY ${batchSize} unique topics for the "${category}" category.

CATEGORY FOCUS: ${categoryDescriptions[category]}
CONFIDENCE RANGE: ${confidenceRanges[category]}%

CRITICAL RULES:
1. Each topic must be a SPECIFIC question related to this exact website's business
2. Topics must be UNIQUE - no duplicates
3. Include REAL data: actual search volumes (e.g., "2,400/month"), real competition levels, specific competitor names
4. For competitive advantage: Mention THIS company's name and specific competitors
5. NO generic text: NOT "question 1", "reasoning", "estimate"${exclusionText}

Return ONLY a JSON array of ${batchSize} topics in this format:
[
  {
    "topic": "Specific question relevant to this business",
    "confidence": [number in ${confidenceRanges[category]} range],
    "justification": "Why this specific topic will get AI citations",
    "platforms": ["chatgpt", "perplexity", "gemini", "claude"],
    "searchVolume": "Realistic number like 2400 monthly searches or 850/month",
    "competitionLevel": "Low/Medium/High",
    "competitorGap": "Specific gap or advantage vs named competitors"
  }
]

Generate ${batchSize} completely unique topics now.`;

    const callStartTime = Date.now();
    try {
      const response = await axios.post(
        'https://api.perplexity.ai/chat/completions',
        {
          model: 'sonar-pro',
          messages: [
            {
              role: 'system',
              content: `You are an AI SEO analyst. Generate ${batchSize} unique topics. Return ONLY a JSON array, no other text.`
            },
            {
              role: 'user',
              content: batchPrompt
            }
          ],
          max_tokens: 4000,
          temperature: 0.3,
          top_p: 0.9,
          stream: false
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 60000
        }
      );

      const content = response.data.choices[0].message.content;
      const usage = response.data.usage;
      
      // Map category to tracking type
      const typeMap = {
        'authoritative': 'topic_authoritative' as const,
        'thoughtLeadership': 'topic_thought_leadership' as const,
        'competitiveAdvantage': 'topic_competitive' as const,
        'emergingOpportunity': 'topic_emerging' as const
      };
      
      // Log API call
      await perplexityTracker.logApiCall({
        auditId: this.auditId,
        type: typeMap[category],
        model: 'sonar-pro',
        tokens: {
          input: usage?.prompt_tokens || 0,
          output: usage?.completion_tokens || 0,
          total: usage?.total_tokens || 0
        },
        userId: this.userId,
        websiteUrl,
        responseTime: Date.now() - callStartTime,
        status: 'success',
        promptLength: batchPrompt.length,
        responseLength: content.length
      });
      
      // Record successful call for API health monitoring
      await perplexityTracker.recordHealthyCall();
      
      // Extract JSON array from response with robust repair
      let jsonString = content;
      const arrayMatch = content.match(/\[[\s\S]*\]/);
      if (arrayMatch) {
        jsonString = arrayMatch[0];
      } else {
        // Array might be truncated - find opening bracket
        const firstBracket = content.indexOf('[');
        if (firstBracket !== -1) {
          jsonString = content.substring(firstBracket);
        }
      }

      // Attempt to parse, with repair if needed
      let topics: any[];
      try {
        topics = JSON.parse(jsonString);
      } catch (parseError) {
        console.log(`⚠️ Batch ${batchNumber} JSON parse failed, attempting repair...`);
        
        // Repair truncated JSON array
        let repaired = jsonString.trim();
        
        // Check for unclosed strings
        let inString = false;
        for (let i = 0; i < repaired.length; i++) {
          if (repaired[i] === '"' && (i === 0 || repaired[i - 1] !== '\\')) {
            inString = !inString;
          }
        }
        if (inString) {
          repaired += '"';
        }
        
        // Remove incomplete last object in array
        const lastCompleteObject = repaired.lastIndexOf('},');
        if (lastCompleteObject > 0) {
          repaired = repaired.substring(0, lastCompleteObject + 1);
        }
        
        // Remove trailing commas and balance brackets
        repaired = repaired.replace(/,(\s*)$/, '$1');
        const openBrackets = (repaired.match(/\[/g) || []).length;
        const closeBrackets = (repaired.match(/\]/g) || []).length;
        const openBraces = (repaired.match(/\{/g) || []).length;
        const closeBraces = (repaired.match(/\}/g) || []).length;
        repaired += ']'.repeat(Math.max(0, openBrackets - closeBrackets));
        repaired += '}'.repeat(Math.max(0, openBraces - closeBraces));
        
        topics = JSON.parse(repaired);
        console.log(`✅ Batch ${batchNumber} JSON repaired successfully`);
      }
      
      console.log(`✅ Batch ${batchNumber} generated: ${topics.length} topics`);
      
      return Array.isArray(topics) ? topics : [];
    } catch (error: any) {
      // Log failed API call
      const typeMap = {
        'authoritative': 'topic_authoritative' as const,
        'thoughtLeadership': 'topic_thought_leadership' as const,
        'competitiveAdvantage': 'topic_competitive' as const,
        'emergingOpportunity': 'topic_emerging' as const
      };
      
      // Extract HTTP status code if available
      const httpStatus = error.response?.status || 0;
      
      await perplexityTracker.logApiCall({
        auditId: this.auditId,
        type: typeMap[category],
        model: 'sonar-pro',
        tokens: { input: 0, output: 0, total: 0 },
        userId: this.userId,
        websiteUrl,
        responseTime: Date.now() - callStartTime,
        status: 'error',
        errorMessage: error.message,
        httpStatus
      });
      
      // Update API status for credit/rate limit issues
      if (httpStatus === 401 || httpStatus === 402 || httpStatus === 429) {
        await perplexityTracker.updateApiStatus(httpStatus, error.message);
      }
      
      console.error(`❌ Batch ${batchNumber} failed:`, error.message);
      return [];
    }
  }

  /**
   * Deduplicate topics by comparing similarity
   */
  deduplicateTopics(topics: any[]): DeduplicationResult {
    console.log(`\n🔍 Deduplicating ${topics.length} topics...`);
    
    const uniqueTopics: any[] = [];
    const seenTopics = new Set<string>();
    let duplicatesRemoved = 0;

    for (const topic of topics) {
      // Validate topic structure
      if (!topic || typeof topic.topic !== 'string') {
        // console.warn('⚠️ Skipping invalid topic format:', topic); // Optional logging
        continue;
      }

      // Normalize topic for comparison
      const normalizedTopic = topic.topic
        .toLowerCase()
        .trim()
        .replace(/[^\w\s]/g, ''); // Remove punctuation

      // Check for exact duplicates
      if (seenTopics.has(normalizedTopic)) {
        duplicatesRemoved++;
        continue;
      }

      // Check for semantic similarity (simple keyword overlap)
      const isDuplicate = uniqueTopics.some(existing => {
        const existingNormalized = existing.topic
          .toLowerCase()
          .trim()
          .replace(/[^\w\s]/g, '');

        // Calculate word overlap
        const topicWords = new Set<string>(normalizedTopic.split(/\s+/));
        const existingWords = new Set<string>(existingNormalized.split(/\s+/));
        
        const intersection = new Set<string>(
          Array.from(topicWords).filter((word: string) => existingWords.has(word) && word.length > 3)
        );

        const similarity = intersection.size / Math.min(topicWords.size, existingWords.size);
        
        // If 70%+ word overlap, consider duplicate
        return similarity > 0.7;
      });

      if (isDuplicate) {
        duplicatesRemoved++;
      } else {
        uniqueTopics.push(topic);
        seenTopics.add(normalizedTopic);
      }
    }

    console.log(`✅ Deduplication complete:`);
    console.log(`   Original: ${topics.length} topics`);
    console.log(`   Unique: ${uniqueTopics.length} topics`);
    console.log(`   Removed: ${duplicatesRemoved} duplicates`);

    return {
      uniqueTopics,
      duplicatesRemoved,
      originalCount: topics.length
    };
  }

  /**
   * Generate topics in batches until reaching target count
   */
  async generateTopicsForCategory(
    websiteUrl: string,
    category: 'authoritative' | 'thoughtLeadership' | 'competitiveAdvantage' | 'emergingOpportunity',
    targetCount: number
  ): Promise<any[]> {
    console.log(`\n========== Generating ${targetCount} ${category} Topics ==========`);
    
    const batchSize = 10;
    let allTopics: any[] = [];
    let batchNumber = 1;
    let attempts = 0;
    const maxAttempts = 20; // Safety limit

    while (allTopics.length < targetCount && attempts < maxAttempts) {
      attempts++;
      
      // Get list of existing topic titles for exclusion
      const existingTopicTitles = allTopics.map(t => t.topic);
      
      // Generate batch
      const batchTopics = await this.generateBatch(
        websiteUrl,
        category,
        batchSize,
        batchNumber,
        existingTopicTitles
      );

      if (batchTopics.length === 0) {
        console.log(`⚠️ Batch ${batchNumber} returned no topics, skipping...`);
        continue;
      }

      // Add to collection
      allTopics.push(...batchTopics);
      
      // Deduplicate after each batch
      const deduped = this.deduplicateTopics(allTopics);
      allTopics = deduped.uniqueTopics;

      console.log(`📊 Progress: ${allTopics.length}/${targetCount} unique topics`);

      batchNumber++;

      // Small delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Final deduplication
    const finalDeduped = this.deduplicateTopics(allTopics);
    const finalTopics = finalDeduped.uniqueTopics.slice(0, targetCount);

    console.log(`\n✅ ${category} complete: ${finalTopics.length} unique topics generated`);
    console.log(`========================================\n`);

    return finalTopics;
  }
}

