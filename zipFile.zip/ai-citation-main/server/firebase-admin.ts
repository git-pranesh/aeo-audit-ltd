import admin from 'firebase-admin';

// Initialize Firebase Admin SDK
// Note: In production, use service account key file
// For development, we'll use the project credentials
let firebaseAdmin: admin.app.App;

try {
  if (!admin.apps.length) {
    firebaseAdmin = admin.initializeApp({
      projectId: process.env.VITE_FIREBASE_PROJECT_ID || 'ai-citation-51aba',
      // For production, add serviceAccountKey here
      // credential: admin.credential.cert(serviceAccount)
    });
    console.log('✅ Firebase Admin initialized successfully');
  } else {
    firebaseAdmin = admin.app();
  }
} catch (error) {
  console.error('❌ Firebase Admin initialization error:', error);
  throw error;
}

export const adminAuth = admin.auth();
export const adminDb = admin.firestore();
export default firebaseAdmin;

