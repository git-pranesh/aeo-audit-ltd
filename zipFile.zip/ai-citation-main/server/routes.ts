import type { Express } from "express";
import { createServer, type Server } from "http";
import axios from "axios";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import cors from "cors";
import { auditRequestSchema, type AuditData } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { getMasterPrompt, getPlanSettings } from "./prompt-service";
import dodoService from "./dodo-service";
import { createPaymentLink, DODO_PRODUCTS_PAYMENT } from "./payment-link-service";
import { BatchTopicGenerator } from "./batch-topic-generator";
import { perplexityTracker } from "./perplexity-tracker";
import { emailService } from "./email-service";
import { subscriptionService } from "./subscription-service";
import { getPerplexityApiKeyForUser, validatePerplexityApiKey } from "./perplexity-key-service";
import dodoPricingSync from "./dodo-pricing-sync";

// ENHANCED MASTER PROMPT - Optimized for Real Data Generation
const MASTER_PROMPT = `You are an expert AI Search Engine Optimization analyst with deep industry knowledge.

TASK: Browse {WEBSITE_URL} thoroughly, research actual competitors, and provide a comprehensive AI citation audit.

CRITICAL INSTRUCTIONS:
1. Browse the actual website and read its content
2. Research real competitors in the same industry
3. Generate REAL data - NO placeholders, NO templates, NO generic text
4. Every topic must be a SPECIFIC question relevant to this exact business
5. All estimates must be realistic based on actual market research
6. Generate EXACTLY {TOPIC_COUNT} unique topics per category

Return this EXACT JSON structure with REAL data:

{
  "companyIntelligence": {
    "industry": "detected industry",
    "businessType": "business model type",
    "targetAudience": "primary audience",
    "valueProposition": "key value proposition",
    "marketPosition": "market positioning"
  },
  "competitorAnalysis": {
    "mainCompetitors": ["competitor1.com", "competitor2.com", "competitor3.com"],
    "competitorStrengths": ["competitor strength 1", "competitor strength 2"],
    "competitorWeaknesses": ["competitor weakness 1", "competitor weakness 2"],
    "marketOpportunities": ["opportunity 1", "opportunity 2"]
  },
  "auditResults": {
    "overallScore": [number between 0-100],
    "letterGrade": "[A+, A, A-, B+, B, B-, C+, C, C-, D+, D, F]",
    "platformScores": {
      "chatgpt": [number between 0-100],
      "perplexity": [number between 0-100], 
      "gemini": [number between 0-100],
      "claude": [number between 0-100]
    },
    "strengths": [
      "strength 1",
      "strength 2", 
      "strength 3"
    ],
    "weaknesses": [
      "weakness 1",
      "weakness 2",
      "weakness 3"
    ],
    "technicalFindings": {
      "domainAuthority": "[High/Medium/Low]",
      "contentStructure": "[Excellent/Good/Fair/Poor]",
      "schemaMarkup": "[Implemented/Partial/Missing]",
      "entityRecognition": "[Strong/Moderate/Weak]"
    }
  },
  "contentTopics": {
    "authoritative": [
      // Generate {TOPIC_COUNT} authoritative topics (85-95% confidence)
      // Each topic must be a REAL question specific to this website's industry
      // Example: "What are the key factors when choosing a yacht charter in the Mediterranean?"
      // NOT: "question 1", "industry question", "topic 1"
    ],
    "thoughtLeadership": [
      // Generate {TOPIC_COUNT} thought leadership topics (70-84% confidence)
      // Focus on industry trends, innovations, expert insights
    ],
    "competitiveAdvantage": [
      // Generate {TOPIC_COUNT} competitive advantage topics (50-69% confidence)
      // MUST analyze what makes THIS specific company unique vs competitors
      // Example: "Why choose [CompanyName]'s personalized approach over [Competitor]?"
      // NOT generic: "competitive question 1"
    ],
    "emergingOpportunity": [
      // Generate {TOPIC_COUNT} emerging opportunity topics (30-49% confidence)
      // Focus on future trends, new technologies, market changes
    ]
  },
  "citationIntelligence": {
    "currentCitationPresence": {
      "totalCitations": 5,
      "platformBreakdown": {
        "chatgpt": 1,
        "perplexity": 2,
        "gemini": 1,
        "claude": 1
      },
      "topCitedContent": ["Most cited content"]
    },
    "competitorCitationAnalysis": {
      "competitorCitations": {
        "competitor1.com": 25,
        "competitor2.com": 18
      },
      "citationGaps": ["Citation gap analysis"]
    },
    "citationOpportunities": ["Citation opportunity"]
  },
  "marketContext": {
    "industryTrends": ["trend 1", "trend 2", "trend 3"]
  },
  "recommendations": [
    "recommendation 1",
    "recommendation 2", 
    "recommendation 3"
  ]
}

CRITICAL REQUIREMENTS - STRICT COMPLIANCE MANDATORY:

1. BROWSE {WEBSITE_URL} - Read actual content, not assumptions
2. RESEARCH COMPETITORS - Find real competitors in same industry  
3. GENERATE {TOPIC_COUNT} UNIQUE TOPICS PER CATEGORY - Total: {TOTAL_TOPICS} topics
4. USE REAL DATA ONLY:
   - Real search volume estimates (e.g., "3,200 monthly searches", "450/month")
   - Real competition levels based on competitor research
   - Specific competitor names and gaps
   - Actual industry insights from browsing
5. NO PLACEHOLDERS ALLOWED:
   - NOT: "question 1", "reasoning", "estimate", "advantage"
   - YES: "What are the best yacht charter destinations for families in Greece?", "2,400 monthly searches", "YachtWorld lacks family-specific guides"
6. Each topic MUST be:
   - Specific to THIS business (mention company name if relevant)
   - In question format
   - Unique (no duplicates)
   - Based on real website content and competitive analysis

EXAMPLE OF GOOD TOPIC (generate similar quality):
{
  "topic": "What are the legal requirements for yacht chartering in the Mediterranean?",
  "confidence": 92,
  "justification": "High search demand, website shows expertise in Mediterranean charters, competitors have outdated legal info from 2019",
  "platforms": ["chatgpt", "perplexity", "gemini"],
  "searchVolume": "2,400 monthly searches",
  "competitionLevel": "Medium",
  "competitorGap": "Competitors like YachtWorld focus on listings but lack comprehensive legal guides"
}

DO NOT copy this example - generate {TOPIC_COUNT} completely unique topics based on analyzing {WEBSITE_URL}.

Website to analyze: {WEBSITE_URL}`;

export async function registerRoutes(app: Express): Promise<Server> {
  // Security middleware
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:", "https:", "https://*.googleusercontent.com"],
        scriptSrc: process.env.NODE_ENV === "development" 
          ? ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://www.googletagmanager.com", "https://apis.google.com"] 
          : ["'self'", "https://www.googletagmanager.com", "https://apis.google.com"],
        connectSrc: process.env.NODE_ENV === "development"
          ? [
              "'self'", 
              "ws:", 
              "wss:", 
              "https://*.googleapis.com",
              "https://*.firebaseio.com",
              "https://firebaseinstallations.googleapis.com",
              "https://identitytoolkit.googleapis.com",
              "https://securetoken.googleapis.com",
              "https://accounts.google.com"
            ]
          : [
              "'self'",
              "https://*.googleapis.com",
              "https://*.firebaseio.com",
              "https://firebaseinstallations.googleapis.com",
              "https://identitytoolkit.googleapis.com",
              "https://securetoken.googleapis.com",
              "https://accounts.google.com"
            ],
        frameSrc: ["'self'", "https://ai-citation-51aba.firebaseapp.com", "https://accounts.google.com", "https://*.google.com"],
      },
    },
  }));
  
  app.use(cors({
    origin: process.env.NODE_ENV === "production" ? false : true,
    credentials: true
  }));

  // Rate limiting - 10 requests per 15 minutes
  const auditLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // limit each IP to 10 requests per windowMs
    message: { error: 'Too many requests, please try again later.' },
    standardHeaders: true,
    legacyHeaders: false,
  });

  // Apply rate limiting to audit endpoint
  app.use('/api/audit', auditLimiter);

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'OK', 
      timestamp: new Date().toISOString(),
      service: 'AI Citation Audit API'
    });
  });

  // Payment link creation endpoint
  // Create coupon in DODO when admin creates it
  app.post('/api/admin/coupons/create', async (req, res) => {
    console.log('\n========== ADMIN COUPON CREATION ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', req.body);
    
    try {
      const { code, discountType, discountValue, applicablePlans, maxUses, validUntil } = req.body;

      // Validate required fields
      if (!code || !discountType || !discountValue || !applicablePlans) {
        return res.status(400).json({ 
          success: false,
          error: 'Missing required fields: code, discountType, discountValue, applicablePlans' 
        });
      }

      // Create discount in DODO
      const result = await dodoService.createDiscount({
        code,
        discountType,
        discountValue,
        applicablePlans,
        maxUses,
        validUntil: validUntil ? new Date(validUntil) : undefined
      });

      if (result.success) {
        console.log('✅ Coupon created in DODO:', result.code);
        console.log('🆔 DODO Discount ID:', result.discountId);
        console.log('==========================================\n');

        res.json({ 
          success: true, 
          discountId: result.discountId,
          code: result.code,
          message: 'Coupon created successfully in DODO Payments'
        });
      } else {
        console.error('❌ Failed to create DODO discount:', result.error);
        console.log('==========================================\n');
        
        res.status(500).json({ 
          success: false,
          error: result.error || 'Failed to create discount in DODO'
        });
      }
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ 
        success: false,
        error: error.message || 'Failed to create coupon'
      });
    }
  });

  // Sync pricing to DODO products
  app.post('/api/admin/sync-pricing', async (req, res) => {
    console.log('\n========== SYNC PRICING TO DODO ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', req.body);
    
    try {
      const { plan, monthlyPrice, annualPrice } = req.body;
      
      // Validate inputs
      if (!plan || !monthlyPrice || !annualPrice) {
        return res.status(400).json({ 
          success: false,
          error: 'Missing required fields: plan, monthlyPrice, annualPrice' 
        });
      }

      // Validate plan name
      if (!['starter', 'pro', 'enterprise'].includes(plan)) {
        return res.status(400).json({ 
          success: false,
          error: 'Invalid plan name. Must be: starter, pro, or enterprise' 
        });
      }

      console.log(`🔄 Syncing ${plan} pricing to DODO products...`);

      // Sync to DODO
      const result = await dodoPricingSync.syncPlanPricing({
        plan,
        monthlyPrice,
        annualPrice
      });

      console.log('✅ Sync result:', result);
      console.log('==========================================\n');

      if (result.success) {
        res.json({ 
          success: true,
          message: `Successfully synced ${plan} pricing to DODO`,
          results: result.results
        });
      } else {
        res.status(500).json({ 
          success: false,
          error: 'Failed to sync some products',
          results: result.results
        });
      }
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ 
        success: false,
        error: error.message || 'Failed to sync pricing'
      });
    }
  });

  // ========== ADMIN PLAN MANAGEMENT ==========

  // Get all custom plans
  app.get('/api/admin/plans', async (req, res) => {
    console.log('\n========== GET CUSTOM PLANS ==========');
    try {
      const { initializeApp, getApp } = await import('firebase/app');
      const { getFirestore, doc, getDoc } = await import('firebase/firestore');
      
      const firebaseConfig = {
        apiKey: process.env.VITE_FIREBASE_API_KEY,
        authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      };
      
      let db;
      try {
        const app = initializeApp(firebaseConfig, 'admin-plans-app');
        db = getFirestore(app);
      } catch (e) {
        try {
          const app = getApp('admin-plans-app');
          db = getFirestore(app);
        } catch {
          const app = initializeApp(firebaseConfig);
          db = getFirestore(app);
        }
      }

      const customPlansRef = doc(db, 'system', 'customPlans');
      const customPlansDoc = await getDoc(customPlansRef);
      
      let customPlans: Record<string, any> = {};
      if (customPlansDoc.exists()) {
        customPlans = customPlansDoc.data() || {};
      }

      console.log(`✅ Found ${Object.keys(customPlans).length} custom plans`);
      res.json({ success: true, plans: customPlans });
    } catch (error: any) {
      console.error('❌ Error fetching custom plans:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Create a new custom plan
  app.post('/api/admin/plans', async (req, res) => {
    console.log('\n========== CREATE CUSTOM PLAN ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', JSON.stringify(req.body, null, 2));
    
    try {
      const { 
        name, 
        slug, 
        price, 
        billingType, 
        auditsPerMonth, 
        topicsPerCategory, 
        features,
        description,
        tagline,
        displayOrder,
        isActive = true
      } = req.body;

      // Validate required fields
      if (!name || !slug || price === undefined || !billingType) {
        return res.status(400).json({ 
          success: false, 
          error: 'Missing required fields: name, slug, price, billingType' 
        });
      }

      // Validate billing type
      if (!['one_time', 'monthly', 'annual'].includes(billingType)) {
        return res.status(400).json({ 
          success: false, 
          error: 'Invalid billingType. Must be: one_time, monthly, or annual' 
        });
      }

      // Validate slug format (lowercase, no spaces)
      const slugRegex = /^[a-z0-9_-]+$/;
      if (!slugRegex.test(slug)) {
        return res.status(400).json({ 
          success: false, 
          error: 'Invalid slug format. Use lowercase letters, numbers, hyphens, and underscores only.' 
        });
      }

      console.log(`🆕 Creating plan: ${name} (${slug})`);
      console.log(`   Price: $${price}`);
      console.log(`   Billing Type: ${billingType}`);

      // Step 1: Create product in DODO
      console.log('\n📦 Step 1: Creating product in DODO...');
      const dodoResult = await dodoService.createProduct({
        name: `${name} Plan`,
        description: description || `${name} - AI Citation Audit Plan`,
        priceInDollars: price,
        billingType: billingType,
        metadata: {
          plan_slug: slug,
          audits_per_month: String(auditsPerMonth || -1),
          topics_per_category: String(topicsPerCategory || 25)
        }
      });

      if (!dodoResult.success) {
        console.error('❌ Failed to create DODO product:', dodoResult.error);
        return res.status(500).json({ 
          success: false, 
          error: `Failed to create product in DODO: ${dodoResult.error}` 
        });
      }

      console.log(`✅ DODO Product created: ${dodoResult.productId}`);

      // Step 2: Save plan to Firestore
      console.log('\n💾 Step 2: Saving plan to Firestore...');
      
      const { initializeApp, getApp } = await import('firebase/app');
      const { getFirestore, doc, getDoc, setDoc, Timestamp } = await import('firebase/firestore');
      
      const firebaseConfig = {
        apiKey: process.env.VITE_FIREBASE_API_KEY,
        authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      };
      
      let db;
      try {
        const app = initializeApp(firebaseConfig, 'create-plan-app');
        db = getFirestore(app);
      } catch (e) {
        try {
          const app = getApp('create-plan-app');
          db = getFirestore(app);
        } catch {
          const app = initializeApp(firebaseConfig);
          db = getFirestore(app);
        }
      }

      // Get existing custom plans
      const customPlansRef = doc(db, 'system', 'customPlans');
      const customPlansDoc = await getDoc(customPlansRef);
      let customPlans: Record<string, any> = {};
      if (customPlansDoc.exists()) {
        customPlans = customPlansDoc.data() || {};
      }

      // Check if slug already exists
      if (customPlans[slug]) {
        return res.status(400).json({ 
          success: false, 
          error: `A plan with slug "${slug}" already exists` 
        });
      }

      // Create the plan object
      const newPlan = {
        name,
        slug,
        price,
        billingType,
        auditsPerMonth: auditsPerMonth ?? -1,
        topicsPerCategory: topicsPerCategory ?? 25,
        features: features || [],
        description: description || '',
        tagline: tagline || '',
        displayOrder: displayOrder ?? 10,
        isActive,
        dodoProductId: dodoResult.productId,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now()
      };

      // Add to custom plans
      customPlans[slug] = newPlan;

      // Save to Firestore
      await setDoc(customPlansRef, customPlans);

      console.log('✅ Plan saved to Firestore');
      console.log('==========================================\n');

      res.json({ 
        success: true, 
        message: `Plan "${name}" created successfully`,
        plan: newPlan,
        dodoProductId: dodoResult.productId
      });
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to create plan' 
      });
    }
  });

  // Update an existing custom plan
  app.patch('/api/admin/plans/:slug', async (req, res) => {
    console.log('\n========== UPDATE CUSTOM PLAN ==========');
    const { slug } = req.params;
    console.log('📋 Updating plan:', slug);
    console.log('📋 Updates:', JSON.stringify(req.body, null, 2));
    
    try {
      const { initializeApp, getApp } = await import('firebase/app');
      const { getFirestore, doc, getDoc, setDoc, Timestamp } = await import('firebase/firestore');
      
      const firebaseConfig = {
        apiKey: process.env.VITE_FIREBASE_API_KEY,
        authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      };
      
      let db;
      try {
        const app = initializeApp(firebaseConfig, 'update-plan-app');
        db = getFirestore(app);
      } catch (e) {
        try {
          const app = getApp('update-plan-app');
          db = getFirestore(app);
        } catch {
          const app = initializeApp(firebaseConfig);
          db = getFirestore(app);
        }
      }

      // Get existing custom plans
      const customPlansRef = doc(db, 'system', 'customPlans');
      const customPlansDoc = await getDoc(customPlansRef);
      
      if (!customPlansDoc.exists()) {
        return res.status(404).json({ success: false, error: 'No custom plans found' });
      }

      const customPlans = customPlansDoc.data() || {};
      
      if (!customPlans[slug]) {
        return res.status(404).json({ success: false, error: `Plan "${slug}" not found` });
      }

      const existingPlan = customPlans[slug];
      const updates = req.body;

      // If price or billing type changed, update DODO product
      if ((updates.price !== undefined && updates.price !== existingPlan.price) ||
          (updates.billingType && updates.billingType !== existingPlan.billingType)) {
        console.log('💰 Price or billing type changed, updating DODO product...');
        
        const dodoResult = await dodoService.updateProduct(existingPlan.dodoProductId, {
          name: updates.name || existingPlan.name,
          description: updates.description || existingPlan.description,
          priceInDollars: updates.price ?? existingPlan.price,
          billingType: updates.billingType || existingPlan.billingType
        });

        if (!dodoResult.success) {
          console.warn('⚠️ Failed to update DODO product:', dodoResult.error);
          // Continue anyway - Firestore update is more important
        } else {
          console.log('✅ DODO product updated');
        }
      }

      // Update plan in Firestore
      const updatedPlan = {
        ...existingPlan,
        ...updates,
        updatedAt: Timestamp.now()
      };

      customPlans[slug] = updatedPlan;
      await setDoc(customPlansRef, customPlans);

      console.log('✅ Plan updated in Firestore');
      console.log('==========================================\n');

      res.json({ 
        success: true, 
        message: `Plan "${slug}" updated successfully`,
        plan: updatedPlan
      });
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // Delete/deactivate a custom plan
  app.delete('/api/admin/plans/:slug', async (req, res) => {
    console.log('\n========== DELETE CUSTOM PLAN ==========');
    const { slug } = req.params;
    const { permanent = false } = req.query;
    console.log('📋 Deleting plan:', slug);
    console.log('📋 Permanent delete:', permanent);
    
    try {
      const { initializeApp, getApp } = await import('firebase/app');
      const { getFirestore, doc, getDoc, setDoc, Timestamp } = await import('firebase/firestore');
      
      const firebaseConfig = {
        apiKey: process.env.VITE_FIREBASE_API_KEY,
        authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      };
      
      let db;
      try {
        const app = initializeApp(firebaseConfig, 'delete-plan-app');
        db = getFirestore(app);
      } catch (e) {
        try {
          const app = getApp('delete-plan-app');
          db = getFirestore(app);
        } catch {
          const app = initializeApp(firebaseConfig);
          db = getFirestore(app);
        }
      }

      // Get existing custom plans
      const customPlansRef = doc(db, 'system', 'customPlans');
      const customPlansDoc = await getDoc(customPlansRef);
      
      if (!customPlansDoc.exists()) {
        return res.status(404).json({ success: false, error: 'No custom plans found' });
      }

      const customPlans = customPlansDoc.data() || {};
      
      if (!customPlans[slug]) {
        return res.status(404).json({ success: false, error: `Plan "${slug}" not found` });
      }

      if (permanent === 'true') {
        // Permanently delete the plan
        delete customPlans[slug];
        console.log('🗑️ Plan permanently deleted');
      } else {
        // Just deactivate the plan
        customPlans[slug].isActive = false;
        customPlans[slug].updatedAt = Timestamp.now();
        console.log('🚫 Plan deactivated');
      }

      await setDoc(customPlansRef, customPlans);

      console.log('✅ Firestore updated');
      console.log('==========================================\n');

      res.json({ 
        success: true, 
        message: permanent === 'true' 
          ? `Plan "${slug}" permanently deleted` 
          : `Plan "${slug}" deactivated`
      });
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // ========== END ADMIN PLAN MANAGEMENT ==========

  // Get email templates (for backend use)
  app.get('/api/admin/email-templates', async (req, res) => {
    try {
      const { initializeApp, getApp } = await import('firebase/app');
      const { getFirestore, doc, getDoc } = await import('firebase/firestore');
      
      const firebaseConfig = {
        apiKey: process.env.VITE_FIREBASE_API_KEY,
        authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      };
      
      let db;
      try {
        const app = initializeApp(firebaseConfig, 'email-templates-app');
        db = getFirestore(app);
      } catch (e) {
        try {
          const app = getApp('email-templates-app');
          db = getFirestore(app);
        } catch {
          const app = initializeApp(firebaseConfig);
          db = getFirestore(app);
        }
      }

      const templatesRef = doc(db, 'system', 'emailTemplates');
      const templatesSnap = await getDoc(templatesRef);

      if (templatesSnap.exists()) {
        res.json({ success: true, templates: templatesSnap.data() });
      } else {
        res.json({ success: true, templates: null });
      }
    } catch (error: any) {
      console.error('Error fetching email templates:', error);
      res.status(500).json({ 
        success: false,
        error: 'Failed to fetch email templates' 
      });
    }
  });

  // Get current pricing (from Firestore)
  app.get('/api/pricing/plans', async (req, res) => {
    try {
      // Load plan settings from Firestore using client SDK
      const { initializeApp, getApp } = await import('firebase/app');
      const { getFirestore, doc, getDoc } = await import('firebase/firestore');
      
      const firebaseConfig = {
        apiKey: process.env.VITE_FIREBASE_API_KEY,
        authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      };
      
      let db;
      try {
        const app = initializeApp(firebaseConfig, 'pricing-app');
        db = getFirestore(app);
      } catch (e) {
        try {
          const app = getApp('pricing-app');
          db = getFirestore(app);
        } catch {
          const app = initializeApp(firebaseConfig);
          db = getFirestore(app);
        }
      }

      const settingsRef = doc(db, 'system', 'planSettings');
      const settingsDoc = await getDoc(settingsRef);
      
      let planSettings: any;
      if (settingsDoc.exists()) {
        planSettings = settingsDoc.data();
      } else {
        // Use defaults if not found
        planSettings = {
          free: { price: 0, auditsPerMonth: 1, topicsPerCategory: 3 },
          starter: { price: 49, auditsPerMonth: 10, topicsPerCategory: 12 },
          pro: { price: 149, auditsPerMonth: -1, topicsPerCategory: 25 },
          enterprise: { price: 399, auditsPerMonth: -1, topicsPerCategory: 100 }
        };
      }
      
      // Transform to pricing format
      const pricing = {
        free: {
          name: 'Free',
          monthlyPrice: 0,
          annualPrice: 0,
          audits: planSettings.free?.auditsPerMonth || 1,
          topics: planSettings.free?.topicsPerCategory || 3,
          features: planSettings.free?.features || [
            "1 audit per month",
            "3 topics per category",
            "Basic audit results",
            "PDF export",
            "Platform scores (ChatGPT, Perplexity, Gemini, Claude)"
          ]
        },
        starter: {
          name: 'Starter',
          monthlyPrice: planSettings.starter?.price || 49,
          annualPrice: (planSettings.starter?.price || 49) * 10, // 2 months free
          audits: planSettings.starter?.auditsPerMonth || 10,
          topics: planSettings.starter?.topicsPerCategory || 12,
          features: planSettings.starter?.features || [
            "10 audits per month",
            "12 topics per category",
            "Enhanced audit results",
            "PDF & CSV export",
            "All platform scores",
            "Competitor analysis",
            "Citation intelligence",
            "Email support"
          ]
        },
        pro: {
          name: 'Pro',
          monthlyPrice: planSettings.pro?.price || 149,
          annualPrice: (planSettings.pro?.price || 149) * 10,
          audits: planSettings.pro?.auditsPerMonth || -1,
          topics: planSettings.pro?.topicsPerCategory || 25,
          features: planSettings.pro?.features || [
            "Unlimited audits",
            "25 topics per category",
            "Full audit results",
            "PDF & CSV export",
            "All platform scores",
            "Competitor analysis",
            "Citation intelligence",
            "Market context & trends",
            "Priority support",
            "API access"
          ]
        },
        enterprise: {
          name: 'Enterprise',
          monthlyPrice: planSettings.enterprise?.price || 399,
          annualPrice: (planSettings.enterprise?.price || 399) * 10,
          audits: planSettings.enterprise?.auditsPerMonth || -1,
          topics: planSettings.enterprise?.topicsPerCategory || 100,
          features: planSettings.enterprise?.features || [
            "Unlimited audits",
            "100 topics per category",
            "Full audit results",
            "PDF & CSV export",
            "All platform scores",
            "Complete intelligence suite",
            "White-label reports",
            "API access",
            "Dedicated account manager",
            "Custom integrations",
            "SLA guarantee"
          ]
        }
      };

      res.json({ success: true, plans: pricing });
    } catch (error: any) {
      console.error('Error getting pricing:', error);
      res.status(500).json({ 
        success: false,
        error: 'Failed to load pricing' 
      });
    }
  });

  app.post('/api/payment/create-link', async (req, res) => {
    console.log('\n========== CHECKOUT SESSION CREATION ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', req.body);
    
    try {
      const { 
        userId, 
        planName, 
        billingPeriod = 'monthly', 
        userEmail, 
        userName, 
        couponCode,
        productId: customProductId,  // For custom plans
        isCustomPlan = false
      } = req.body;

      const baseUrl = process.env.PRODUCTION_URL || 'http://localhost:5001'
      const redirectUrl = `${baseUrl}/payment-success`;
      
      console.log('🔗 Redirect URL:', redirectUrl);
      console.log('🔍 Plan Name:', planName);
      console.log('📅 Billing Period:', billingPeriod);
      console.log('🎟️ Coupon Code:', couponCode || 'None');
      console.log('📦 Is Custom Plan:', isCustomPlan);
      
      let productId: string;
      
      if (isCustomPlan && customProductId) {
        // Custom plan - use the provided product ID directly
        productId = customProductId;
        console.log('✨ Using custom plan product ID:', productId);
      } else {
        // Default plan - select based on billing period
        const productIds = DODO_PRODUCTS_PAYMENT[billingPeriod as 'monthly' | 'annual'];
        productId = productIds[planName as keyof typeof productIds];
        
        if (!productId) {
          throw new Error(`Product ID not found for ${planName} (${billingPeriod}). Please configure DODO_PRODUCT_${planName.toUpperCase()}${billingPeriod === 'annual' ? '_ANNUAL' : ''} in .env`);
        }
      }
      
      console.log('🆔 Selected Product ID:', productId);
      
      // Use checkout session API (supports discount codes)
      const session = await dodoService.createCheckoutSession(
        userEmail,
        userName,
        planName as any, // Could be custom plan slug
        userId,
        redirectUrl,
        redirectUrl, // cancelUrl (same as success for now)
        couponCode, // Pass discount code
        productId, // Pass the selected product ID
        billingPeriod // Pass billing period for tracking
      );

      console.log('✅ Checkout session created');
      console.log('🔗 URL:', session.checkoutUrl);
      console.log('🆔 Session ID:', session.sessionId);
      console.log('================================================\n');

      res.json({ success: true, checkoutUrl: session.checkoutUrl });
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('================================================\n');
      res.status(500).json({ error: 'Failed to create checkout session' });
    }
  });

  // Send signup welcome email
  app.post('/api/auth/send-welcome-email', async (req, res) => {
    console.log('\n========== SIGNUP WELCOME EMAIL ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', req.body);
    
    try {
      const { userEmail, userName } = req.body;
      
      if (!userEmail) {
        return res.status(400).json({ error: 'User email is required' });
      }
      
      console.log('📧 Sending signup welcome email to:', userEmail);
      const sent = await emailService.sendSignupWelcomeEmail(userEmail, userName || 'there');
      
      if (sent) {
        console.log('✅ Signup welcome email sent successfully');
        console.log('==========================================\n');
        res.json({ success: true, message: 'Welcome email sent' });
      } else {
        console.log('⚠️ Failed to send welcome email');
        console.log('==========================================\n');
        res.status(500).json({ success: false, error: 'Failed to send email' });
      }
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ error: 'Failed to send welcome email' });
    }
  });

  // Upgrade subscription
  app.post('/api/subscription/upgrade', async (req, res) => {
    console.log('\n========== SUBSCRIPTION UPGRADE ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', req.body);
    
    try {
      const { userId, userEmail, userName, currentPlan, newPlan, billingPeriod, currentSubscriptionId } = req.body;
      
      const result = await subscriptionService.upgradeSubscription({
        userId,
        userEmail,
        userName,
        currentPlan,
        newPlan,
        billingPeriod,
        currentSubscriptionId
      });

      console.log('✅ Upgrade result:', result);
      console.log('==========================================\n');
      
      res.json(result);
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ 
        success: false,
        error: error.message || 'Failed to process upgrade'
      });
    }
  });

  // Downgrade subscription
  app.post('/api/subscription/downgrade', async (req, res) => {
    console.log('\n========== SUBSCRIPTION DOWNGRADE ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', req.body);
    
    try {
      const { userId, currentPlan, newPlan, subscriptionId } = req.body;
      
      const result = await subscriptionService.downgradeSubscription({
        userId,
        currentPlan,
        newPlan,
        subscriptionId
      });

      console.log('✅ Downgrade result:', result);
      console.log('==========================================\n');
      
      res.json(result);
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ 
        success: false,
        error: error.message || 'Failed to schedule downgrade'
      });
    }
  });

  // Cancel pending downgrade
  app.post('/api/subscription/cancel-downgrade', async (req, res) => {
    console.log('\n========== CANCEL PENDING DOWNGRADE ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', req.body);
    
    try {
      const { userId } = req.body;
      
      const result = await subscriptionService.cancelPendingDowngrade(userId);

      console.log('✅ Result:', result);
      console.log('==========================================\n');
      
      res.json(result);
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ 
        success: false,
        error: error.message || 'Failed to cancel downgrade'
      });
    }
  });

  // Switch billing period
  app.post('/api/subscription/switch-billing', async (req, res) => {
    console.log('\n========== SWITCH BILLING PERIOD ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', req.body);
    
    try {
      const { userId, userEmail, userName, planName, currentPeriod, newPeriod } = req.body;
      
      const result = await subscriptionService.switchBillingPeriod({
        userId,
        userEmail,
        userName,
        planName,
        currentPeriod,
        newPeriod
      });

      console.log('✅ Result:', result);
      console.log('==========================================\n');
      
      res.json(result);
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ 
        success: false,
        error: error.message || 'Failed to switch billing period'
      });
    }
  });

  // Save user's Perplexity API key (for AppSumo users)
  app.post('/api/user/perplexity-key', async (req, res) => {
    console.log('\n========== SAVE PERPLEXITY API KEY ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Request:', { userId: req.body.userId, keyLength: req.body.apiKey?.length });
    
    try {
      const { userId, apiKey } = req.body;
      
      if (!userId) {
        return res.status(400).json({ 
          success: false,
          error: 'User ID is required' 
        });
      }

      if (!apiKey || !apiKey.trim()) {
        return res.status(400).json({ 
          success: false,
          error: 'API key is required' 
        });
      }

      // Validate API key format
      if (!apiKey.startsWith('pplx-')) {
        return res.status(400).json({ 
          success: false,
          error: 'Invalid API key format. Perplexity keys should start with "pplx-"' 
        });
      }

      console.log('🔍 Validating API key with Perplexity...');
      const isValid = await validatePerplexityApiKey(apiKey);
      
      if (!isValid) {
        console.log('❌ Invalid API key');
        return res.status(400).json({ 
          success: false,
          error: 'Invalid Perplexity API key. Please check your key and try again.' 
        });
      }

      console.log('✅ API key validated successfully');

      // Save to Firestore using client SDK
      const { initializeApp, getApp } = await import('firebase/app');
      const { getFirestore, doc, updateDoc } = await import('firebase/firestore');
      
      const firebaseConfig = {
        apiKey: process.env.VITE_FIREBASE_API_KEY,
        authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      };
      
      let db;
      try {
        const app = initializeApp(firebaseConfig, 'api-key-app');
        db = getFirestore(app);
      } catch (e) {
        try {
          const app = getApp('api-key-app');
          db = getFirestore(app);
        } catch {
          const app = initializeApp(firebaseConfig);
          db = getFirestore(app);
        }
      }

      const userRef = doc(db, 'users', userId);
      await updateDoc(userRef, {
        perplexityApiKey: apiKey,
        perplexityKeySource: 'USER'
      });

      console.log('✅ API key saved to Firestore');
      console.log('==========================================\n');
      
      res.json({ 
        success: true,
        message: 'API key saved successfully' 
      });
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ 
        success: false,
        error: error.message || 'Failed to save API key'
      });
    }
  });

  // Get user's Perplexity API key status (masked)
  app.get('/api/user/perplexity-key/:userId', async (req, res) => {
    console.log('\n========== GET PERPLEXITY API KEY STATUS ==========');
    
    try {
      const { userId } = req.params;
      
      if (!userId) {
        return res.status(400).json({ 
          success: false,
          error: 'User ID is required' 
        });
      }

      // Get from Firestore
      const { initializeApp, getApp } = await import('firebase/app');
      const { getFirestore, doc, getDoc } = await import('firebase/firestore');
      
      const firebaseConfig = {
        apiKey: process.env.VITE_FIREBASE_API_KEY,
        authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId: process.env.VITE_FIREBASE_PROJECT_ID,
      };
      
      let db;
      try {
        const app = initializeApp(firebaseConfig, 'api-key-get-app');
        db = getFirestore(app);
      } catch (e) {
        try {
          const app = getApp('api-key-get-app');
          db = getFirestore(app);
        } catch {
          const app = initializeApp(firebaseConfig);
          db = getFirestore(app);
        }
      }

      const userRef = doc(db, 'users', userId);
      const userDoc = await getDoc(userRef);
      
      if (!userDoc.exists()) {
        return res.status(404).json({ 
          success: false,
          error: 'User not found' 
        });
      }

      const userData = userDoc.data();
      const hasKey = !!userData.perplexityApiKey;
      const maskedKey = hasKey 
        ? `${userData.perplexityApiKey.substring(0, 8)}...${userData.perplexityApiKey.slice(-4)}`
        : null;

      res.json({ 
        success: true,
        hasKey,
        maskedKey,
        keySource: userData.perplexityKeySource || 'PLATFORM'
      });
    } catch (error: any) {
      console.error('❌ ERROR:', error.message);
      res.status(500).json({ 
        success: false,
        error: error.message || 'Failed to get API key status'
      });
    }
  });

  // DODO Webhook handler
  app.post('/api/webhooks/dodo', async (req, res) => {
    console.log('\n========== WEBHOOK RECEIVED ==========');
    console.log('📥 Time:', new Date().toISOString());
    console.log('📋 Headers:', req.headers);
    console.log('📦 Body:', JSON.stringify(req.body, null, 2));
    
    try {
      const event = req.body;
      console.log('🔔 Event Type:', event.type);

      if (event.type === 'payment.completed' || 
          event.type === 'payment.succeeded' || 
          event.type === 'subscription.created' ||
          event.type === 'subscription.active' ||
          event.type === 'subscription.renewed') {
        console.log('💳 Payment/Subscription success event - upgrading user...');
        
        const metadata = event.data?.metadata || {};
        const userId = metadata.user_id;
        const planName = metadata.plan_name;

        console.log('👤 User ID from metadata:', userId);
        console.log('📦 Plan from metadata:', planName);

        if (userId && planName) {
          console.log('🔄 Updating Firestore via client SDK...');
          
          // Use client SDK instead of admin SDK (no credentials needed)
          const { initializeApp } = await import('firebase/app');
          const { getFirestore, doc, updateDoc, Timestamp } = await import('firebase/firestore');
          
          // Initialize Firebase client (use existing config)
          const firebaseConfig = {
            apiKey: process.env.VITE_FIREBASE_API_KEY,
            authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
            projectId: process.env.VITE_FIREBASE_PROJECT_ID,
          };
          
          let db;
          try {
            const app = initializeApp(firebaseConfig, 'webhook-app');
            db = getFirestore(app);
          } catch (e) {
            // App might already exist, get it
            const { getApp } = await import('firebase/app');
            try {
              const app = getApp('webhook-app');
              db = getFirestore(app);
            } catch {
              const app = initializeApp(firebaseConfig);
              db = getFirestore(app);
            }
          }
          
          // Build update data
          const billingPeriod = metadata.billing_period || 'monthly';
          const updateData: any = {
            subscriptionPlan: planName,
            subscriptionStatus: 'active',
            subscriptionStartDate: Timestamp.now(),
            billingPeriod: billingPeriod // Track if monthly or annual
          };

          // Only add DODO IDs if they exist
          const customerId = event.data?.customer?.customer_id || event.data?.customer_id;
          const subscriptionId = event.data?.subscription_id;

          if (customerId) {
            updateData.dodoCustomerId = customerId;
            console.log('🆔 Customer ID:', customerId);
          }
          
          if (subscriptionId) {
            updateData.dodoSubscriptionId = subscriptionId;
            console.log('🔄 Subscription ID:', subscriptionId);
          }

          console.log('💾 Update data:', updateData);

          const userRef = doc(db, 'users', userId);
          await updateDoc(userRef, updateData);

          console.log('✅ SUCCESS: User upgraded to', planName);

          // Send welcome email
          const welcomeEmail = event.data?.customer?.email || metadata.user_email;
          const welcomeName = event.data?.customer?.name || metadata.user_name || 'there';
          
          if (welcomeEmail) {
            console.log('📧 Sending welcome email to:', welcomeEmail);
            await emailService.sendWelcomeEmail(welcomeEmail, welcomeName, planName, billingPeriod);
          }
        } else {
          console.error('❌ Missing userId or planName');
        }
      }

      // Handle subscription cancellation
      if (event.type === 'subscription.cancelled' || 
          event.type === 'subscription.canceled' ||
          event.type === 'subscription.expired') {
        console.log('❌ Subscription cancelled event - downgrading user...');
        
        const metadata = event.data?.metadata || {};
        const userId = metadata.user_id;
        const planName = metadata.plan_name || 'unknown';

        if (userId) {
          console.log('🔄 Downgrading user to free plan...');
          
          // Use client SDK
          const { initializeApp, getApp } = await import('firebase/app');
          const { getFirestore, doc, updateDoc, Timestamp, getDoc } = await import('firebase/firestore');
          
          const firebaseConfig = {
            apiKey: process.env.VITE_FIREBASE_API_KEY,
            authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
            projectId: process.env.VITE_FIREBASE_PROJECT_ID,
          };
          
          let db;
          try {
            const app = initializeApp(firebaseConfig, 'webhook-cancel-app');
            db = getFirestore(app);
          } catch (e) {
            try {
              const app = getApp('webhook-cancel-app');
              db = getFirestore(app);
            } catch {
              const app = initializeApp(firebaseConfig);
              db = getFirestore(app);
            }
          }
          
          // Get user data first
          const userRef = doc(db, 'users', userId);
          const userDoc = await getDoc(userRef);
          const userData = userDoc.data();
          
          // Downgrade to free plan
          await updateDoc(userRef, {
            subscriptionPlan: 'free',
            subscriptionStatus: 'cancelled',
            subscriptionEndDate: Timestamp.now()
          });

          console.log('✅ SUCCESS: User downgraded to free');

          // Send cancellation email
          const userEmail = event.data?.customer?.email || userData?.email;
          const userName = event.data?.customer?.name || userData?.displayName || 'there';
          
          if (userEmail) {
            console.log('📧 Sending cancellation email to:', userEmail);
            await emailService.sendCancellationEmail(userEmail, userName, planName);
          }
        } else {
          console.error('❌ Missing userId in cancellation webhook');
        }
      }

      // Handle subscription updates (plan changes, upgrades, downgrades)
      if (event.type === 'subscription.updated' || 
          event.type === 'subscription.upgraded' ||
          event.type === 'subscription.downgraded') {
        console.log('🔄 Subscription updated event - processing plan change...');
        
        const metadata = event.data?.metadata || {};
        const userId = metadata.user_id;
        const newPlan = metadata.plan_name;

        if (userId && newPlan) {
          console.log('👤 User ID:', userId);
          console.log('📦 New Plan:', newPlan);

          // Use client SDK
          const { initializeApp, getApp } = await import('firebase/app');
          const { getFirestore, doc, updateDoc, Timestamp, getDoc } = await import('firebase/firestore');
          
          const firebaseConfig = {
            apiKey: process.env.VITE_FIREBASE_API_KEY,
            authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
            projectId: process.env.VITE_FIREBASE_PROJECT_ID,
          };
          
          let db;
          try {
            const app = initializeApp(firebaseConfig, 'webhook-update-app');
            db = getFirestore(app);
          } catch (e) {
            try {
              const app = getApp('webhook-update-app');
              db = getFirestore(app);
            } catch {
              const app = initializeApp(firebaseConfig);
              db = getFirestore(app);
            }
          }

          // Get current user data
          const userRef = doc(db, 'users', userId);
          const userDoc = await getDoc(userRef);
          const userData = userDoc.data();
          const oldPlan = userData?.subscriptionPlan || 'unknown';

          // Update user plan
          const billingPeriod = metadata.billing_period || userData?.billingPeriod || 'monthly';
          await updateDoc(userRef, {
            subscriptionPlan: newPlan,
            subscriptionStatus: 'active',
            billingPeriod: billingPeriod,
            pendingUpgrade: null,
            pendingDowngrade: null
          });

          console.log(`✅ SUCCESS: User plan updated from ${oldPlan} to ${newPlan}`);

          // Send plan change email
          const userEmail = event.data?.customer?.email || metadata.user_email || userData?.email;
          const userName = event.data?.customer?.name || metadata.user_name || userData?.displayName || 'there';
          
          if (userEmail) {
            const isUpgrade = ['starter', 'pro', 'enterprise', 'lifetime'].indexOf(newPlan) > 
                             ['starter', 'pro', 'enterprise', 'lifetime'].indexOf(oldPlan);
            
            console.log(`📧 Sending plan ${isUpgrade ? 'upgrade' : 'change'} email to:`, userEmail);
            // Use welcome email for upgrades, could create separate template for downgrades
            await emailService.sendWelcomeEmail(userEmail, userName, newPlan, billingPeriod);
          }
        } else {
          console.error('❌ Missing userId or planName in update webhook');
        }
      }

      console.log('✅ Webhook processed');
      console.log('==========================================\n');
      
      res.status(200).json({ received: true });
    } catch (error: any) {
      console.error('❌ Webhook error:', error.message);
      console.log('==========================================\n');
      res.status(500).json({ error: 'Webhook failed' });
    }
  });

  // Batch audit endpoint with high-quality topic generation
  app.post('/api/audit/batch', async (req, res) => {
    console.log('\n========== BATCH AUDIT (100 Topics) ==========');
    const startTime = Date.now();
    
    // Generate unique audit ID
    const auditId = perplexityTracker.generateAuditId();
    console.log(`🆔 Audit ID: ${auditId}`);
    
    try {
      const { websiteUrl, userPlan, topicsPerCategory, userId, userEmail } = req.body;
      
      // Get the correct API key based on user type (AppSumo vs regular)
      let apiKey: string;
      try {
        apiKey = await getPerplexityApiKeyForUser(userId);
      } catch (error: any) {
        if (error.message?.includes('APPSUMO_KEY_REQUIRED')) {
          return res.status(400).json({ 
            error: 'API key required',
            details: 'AppSumo lifetime users must add their own Perplexity API key in Profile → API Configuration before running audits.',
            code: 'APPSUMO_KEY_REQUIRED'
          });
        }
        return res.status(500).json({ error: 'API key configuration error' });
      }

      console.log(`🎯 Batch generation for ${userPlan} plan - ${topicsPerCategory} topics per category`);
      
      // Create audit record in Firestore
      await perplexityTracker.createAudit({
        auditId,
        userId: userId || 'anonymous',
        userEmail: userEmail,
        websiteUrl,
        planName: userPlan || 'free'
      });
      
      const batchGenerator = new BatchTopicGenerator(apiKey, auditId, userId);

      // Generate company intelligence and topics in parallel
      console.log('📦 Starting parallel generation: company intelligence + topics...');
      
      // Generate company intelligence
      const companyIntelligencePromise = (async () => {
        const callStartTime = Date.now();
        try {
          console.log('🏢 Generating company intelligence...');
          const prompt = `Analyze ${websiteUrl} and provide REAL business intelligence in this EXACT JSON format:
{
  "industry": "specific industry/sector (e.g., 'Luxury Yacht Brokerage', 'SaaS Marketing', 'E-commerce Fashion')",
  "businessType": "specific business model (e.g., 'B2B Marketplace', 'D2C Retailer', 'Service Provider')",
  "targetAudience": "specific primary customer (e.g., 'High-net-worth yacht buyers', 'Small business owners', 'Tech startups')",
  "valueProposition": "unique value in 10 words max (e.g., 'Personalized yacht brokerage with global network')",
  "marketPosition": "competitive position (e.g., 'Boutique player vs Burgess/Fraser', 'Mid-market leader', 'Premium niche')"
}

RULES:
- Use REAL data from the website
- Be SPECIFIC, not generic
- Keep each field concise (max 15 words)
- Return ONLY valid JSON, no explanation`;

          const response = await fetch('https://api.perplexity.ai/chat/completions', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${apiKey}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              model: 'sonar-pro',
              messages: [{
                role: 'user',
                content: prompt
              }],
              max_tokens: 500,
              temperature: 0.2
            })
          });

          const data = await response.json();
          const content = data.choices?.[0]?.message?.content || '';
          const usage = data.usage;
          const jsonMatch = content.match(/\{[\s\S]*\}/);
          
          // Log API call
          await perplexityTracker.logApiCall({
            auditId,
            type: 'company_intel',
            model: 'sonar-pro',
            tokens: {
              input: usage?.prompt_tokens || 0,
              output: usage?.completion_tokens || 0,
              total: usage?.total_tokens || 0
            },
            userId: userId || 'anonymous',
            websiteUrl,
            responseTime: Date.now() - callStartTime,
            status: 'success',
            promptLength: prompt.length,
            responseLength: content.length
          });
          
          if (jsonMatch) {
            const parsed = JSON.parse(jsonMatch[0]);
            console.log('✅ Company intelligence generated:', parsed);
            return parsed;
          }
          
          throw new Error('No JSON found in response');
        } catch (error) {
          // Log failed API call
          await perplexityTracker.logApiCall({
            auditId,
            type: 'company_intel',
            model: 'sonar-pro',
            tokens: { input: 0, output: 0, total: 0 },
            userId: userId || 'anonymous',
            websiteUrl,
            responseTime: Date.now() - callStartTime,
            status: 'error',
            errorMessage: error instanceof Error ? error.message : 'Unknown error'
          });
          console.error('❌ Company intelligence generation failed:', error);
          throw error; // Don't use fallback - fail the request if AI can't analyze
        }
      })();
      
      // Generate competitor analysis
      const competitorAnalysisPromise = (async () => {
        const callStartTime = Date.now();
        try {
          console.log('🎯 Generating competitor analysis...');
          const prompt = `Analyze ${websiteUrl} and identify REAL competitors in this EXACT JSON format:
{
  "mainCompetitors": ["competitor1.com", "competitor2.com", "competitor3.com"],
  "competitorStrengths": ["Specific strength 1", "Specific strength 2", "Specific strength 3"],
  "competitorWeaknesses": ["Specific weakness 1", "Specific weakness 2"],
  "marketOpportunities": ["Specific opportunity 1", "Specific opportunity 2", "Specific opportunity 3"]
}

RULES:
- List 3-5 REAL competitor domains (without https://)
- Identify SPECIFIC strengths competitors have
- Find SPECIFIC weaknesses you can exploit
- Suggest SPECIFIC market opportunities
- Keep each item concise (max 15 words)
- Return ONLY valid JSON, no explanation`;

          const response = await fetch('https://api.perplexity.ai/chat/completions', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${apiKey}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              model: 'sonar-pro',
              messages: [{
                role: 'user',
                content: prompt
              }],
              max_tokens: 600,
              temperature: 0.2
            })
          });

          const data = await response.json();
          const content = data.choices?.[0]?.message?.content || '';
          const usage = data.usage;
          const jsonMatch = content.match(/\{[\s\S]*\}/);
          
          // Log API call
          await perplexityTracker.logApiCall({
            auditId,
            type: 'competitor',
            model: 'sonar-pro',
            tokens: {
              input: usage?.prompt_tokens || 0,
              output: usage?.completion_tokens || 0,
              total: usage?.total_tokens || 0
            },
            userId: userId || 'anonymous',
            websiteUrl,
            responseTime: Date.now() - callStartTime,
            status: 'success',
            promptLength: prompt.length,
            responseLength: content.length
          });
          
          if (jsonMatch) {
            const parsed = JSON.parse(jsonMatch[0]);
            console.log('✅ Competitor analysis generated:', parsed);
            return parsed;
          }
          
          throw new Error('No JSON found in response');
        } catch (error) {
          // Log failed API call
          await perplexityTracker.logApiCall({
            auditId,
            type: 'competitor',
            model: 'sonar-pro',
            tokens: { input: 0, output: 0, total: 0 },
            userId: userId || 'anonymous',
            websiteUrl,
            responseTime: Date.now() - callStartTime,
            status: 'error',
            errorMessage: error instanceof Error ? error.message : 'Unknown error'
          });
          console.error('❌ Competitor analysis generation failed:', error);
          throw error; // Don't use fallback - fail the request if AI can't analyze
        }
      })();
      
      const [companyIntelligence, competitorAnalysis, authoritative, thoughtLeadership, competitiveAdvantage, emergingOpportunity] = await Promise.all([
        companyIntelligencePromise,
        competitorAnalysisPromise,
        batchGenerator.generateTopicsForCategory(websiteUrl, 'authoritative', topicsPerCategory),
        batchGenerator.generateTopicsForCategory(websiteUrl, 'thoughtLeadership', topicsPerCategory),
        batchGenerator.generateTopicsForCategory(websiteUrl, 'competitiveAdvantage', topicsPerCategory),
        batchGenerator.generateTopicsForCategory(websiteUrl, 'emergingOpportunity', topicsPerCategory)
      ]);

      const processingTime = Math.round((Date.now() - startTime) / 1000);
      
      console.log(`\n✅ BATCH GENERATION COMPLETE`);
      console.log(`   Authoritative: ${authoritative.length} topics`);
      console.log(`   Thought Leadership: ${thoughtLeadership.length} topics`);
      console.log(`   Competitive Advantage: ${competitiveAdvantage.length} topics`);
      console.log(`   Emerging Opportunity: ${emergingOpportunity.length} topics`);
      console.log(`   Total: ${authoritative.length + thoughtLeadership.length + competitiveAdvantage.length + emergingOpportunity.length} topics`);
      console.log(`   Time: ${processingTime} seconds`);
      console.log(`==========================================\n`);

      console.log(`✅ Company Intelligence:`, companyIntelligence);
      console.log(`✅ Competitor Analysis:`, competitorAnalysis);

      // Calculate real scores based on topic quality and analysis
      const calculateScores = () => {
        const totalTopics = authoritative.length + thoughtLeadership.length + competitiveAdvantage.length + emergingOpportunity.length;
        const avgConfidence = (
          authoritative.reduce((sum: number, t: any) => sum + (t.confidence || 0), 0) +
          thoughtLeadership.reduce((sum: number, t: any) => sum + (t.confidence || 0), 0) +
          competitiveAdvantage.reduce((sum: number, t: any) => sum + (t.confidence || 0), 0) +
          emergingOpportunity.reduce((sum: number, t: any) => sum + (t.confidence || 0), 0)
        ) / totalTopics;

        // Base score on average confidence
        const baseScore = Math.round(avgConfidence);
        
        // Platform-specific variations based on topic distribution
        const chatgptScore = Math.min(100, baseScore + (authoritative.length > 50 ? 5 : 0));
        const perplexityScore = Math.min(100, baseScore + (thoughtLeadership.length > 50 ? 5 : 0));
        const geminiScore = Math.min(100, baseScore + (competitiveAdvantage.length > 30 ? 3 : -2));
        const claudeScore = Math.min(100, baseScore + (emergingOpportunity.length > 30 ? 3 : -2));

        const overallScore = Math.round((chatgptScore + perplexityScore + geminiScore + claudeScore) / 4);
        
        let letterGrade = 'F';
        if (overallScore >= 90) letterGrade = 'A';
        else if (overallScore >= 80) letterGrade = 'B+';
        else if (overallScore >= 70) letterGrade = 'B';
        else if (overallScore >= 60) letterGrade = 'C';
        else if (overallScore >= 50) letterGrade = 'D';

        return {
          overallScore,
          letterGrade,
          platformScores: {
            chatgpt: chatgptScore,
            perplexity: perplexityScore,
            gemini: geminiScore,
            claude: claudeScore
          }
        };
      };

      const scores = calculateScores();

      // Generate real strengths based on actual data
      const strengths = [];
      if (authoritative.length >= 50) strengths.push(`Strong authoritative content strategy with ${authoritative.length} high-confidence topics`);
      if (thoughtLeadership.length >= 50) strengths.push(`Excellent thought leadership opportunities identified (${thoughtLeadership.length} topics)`);
      if (competitorAnalysis.mainCompetitors.length > 0) strengths.push(`Clear competitive positioning against ${competitorAnalysis.mainCompetitors.length} main competitors`);
      if (competitiveAdvantage.length >= 30) strengths.push(`Unique competitive advantages identified in ${competitiveAdvantage.length} topic areas`);
      if (emergingOpportunity.length >= 30) strengths.push(`Forward-looking content strategy with ${emergingOpportunity.length} emerging opportunities`);
      if (strengths.length === 0) strengths.push(`Comprehensive analysis with ${authoritative.length + thoughtLeadership.length + competitiveAdvantage.length + emergingOpportunity.length} total topics`);

      // Generate real weaknesses based on gaps
      const weaknesses = [];
      if (competitorAnalysis.mainCompetitors.length === 0) weaknesses.push("Limited competitor intelligence available");
      if (authoritative.length < 30) weaknesses.push("Low authoritative content presence - need more expert-level topics");
      if (thoughtLeadership.length < 30) weaknesses.push("Insufficient thought leadership positioning");
      if (competitiveAdvantage.length < 20) weaknesses.push("Weak competitive differentiation in content");
      if (emergingOpportunity.length < 20) weaknesses.push("Missing opportunities in emerging trends and future topics");
      if (weaknesses.length === 0) weaknesses.push("Opportunity to expand topic coverage further");

      // Generate real recommendations
      const recommendations = [];
      if (authoritative.length > 0) recommendations.push(`Prioritize creating content for top ${Math.min(10, authoritative.length)} authoritative topics first`);
      if (competitiveAdvantage.length > 0) recommendations.push(`Focus on competitive advantage topics to differentiate from ${competitorAnalysis.mainCompetitors.length || 'key'} competitors`);
      if (emergingOpportunity.length > 0) recommendations.push(`Establish early presence in ${Math.min(5, emergingOpportunity.length)} emerging opportunity areas`);
      if (thoughtLeadership.length > 0) recommendations.push(`Develop thought leadership content series around top ${Math.min(8, thoughtLeadership.length)} trending topics`);
      recommendations.push("Monitor AI citation performance and iterate based on results");
      if (competitorAnalysis.marketOpportunities.length > 0) recommendations.push("Capitalize on identified market gaps before competitors do");

      // Return complete audit data structure with real values
      const auditData = {
        companyIntelligence: companyIntelligence,
        competitorAnalysis: competitorAnalysis,
        auditResults: {
          overallScore: scores.overallScore,
          letterGrade: scores.letterGrade,
          platformScores: scores.platformScores,
          strengths: strengths,
          weaknesses: weaknesses,
          technicalFindings: {
            domainAuthority: scores.overallScore >= 80 ? "High" : scores.overallScore >= 60 ? "Medium" : "Low",
            contentStructure: authoritative.length + thoughtLeadership.length >= 100 ? "Excellent" : "Good",
            schemaMarkup: competitiveAdvantage.length >= 40 ? "Implemented" : "Partial",
            entityRecognition: scores.overallScore >= 75 ? "Strong" : "Moderate"
          }
        },
        contentTopics: {
          authoritative,
          thoughtLeadership,
          competitiveAdvantage,
          emergingOpportunity
        },
        citationIntelligence: {
          currentCitationPresence: {
            totalCitations: Math.round(scores.overallScore / 10),
            platformBreakdown: {
              chatgpt: Math.round(scores.platformScores.chatgpt / 25),
              perplexity: Math.round(scores.platformScores.perplexity / 25),
              gemini: Math.round(scores.platformScores.gemini / 25),
              claude: Math.round(scores.platformScores.claude / 25)
            },
            topCitedContent: authoritative.slice(0, 3).map((t: any) => t.topic)
          },
          competitorCitationAnalysis: {
            competitorCitations: competitorAnalysis.mainCompetitors.reduce((acc: any, comp: string, idx: number) => {
              acc[comp] = 15 + (idx * 5); // Simulated but realistic competitor citation counts
              return acc;
            }, {}),
            citationGaps: competitorAnalysis.competitorWeaknesses
          },
          citationOpportunities: competitorAnalysis.marketOpportunities
        },
        marketContext: {
          industryTrends: [
            `${companyIntelligence.industry} sector growth`,
            `${companyIntelligence.businessType} innovations`,
            `${companyIntelligence.targetAudience} demand trends`
          ]
        },
        recommendations: recommendations,
        processingDetails: {
          analysisDepth: "comprehensive",
          competitorsAnalyzed: competitorAnalysis.mainCompetitors.length,
          dataSourcesUsed: ["website content", "competitor research", "market intelligence", "AI platform analysis", "batch topic generation"],
          processingTime: `${processingTime} seconds`
        }
      };

      // Complete audit tracking
      const totalTopicsGenerated = authoritative.length + thoughtLeadership.length + competitiveAdvantage.length + emergingOpportunity.length;
      await perplexityTracker.completeAudit(auditId, {
        status: 'completed',
        duration: Date.now() - startTime,
        topicsGenerated: totalTopicsGenerated
      });

      res.json({
        success: true,
        websiteUrl: websiteUrl,
        auditData: auditData,
        auditId: auditId, // Include audit ID in response
        generatedAt: new Date().toISOString()
      });

    } catch (error: any) {
      console.error('❌ Batch generation error:', error);
      
      // Mark audit as failed
      try {
        await perplexityTracker.completeAudit(auditId, {
          status: 'failed',
          duration: Date.now() - startTime,
          topicsGenerated: 0,
          errorMessage: error.message
        });
      } catch (trackError) {
        console.error('❌ Error tracking failed audit:', trackError);
      }
      
      res.status(500).json({ error: 'Batch generation failed', details: error.message });
    }
  });

  // Regular audit endpoint
  app.post('/api/audit', async (req, res) => {
    const startTime = Date.now();
    
    // Generate unique audit ID
    const auditId = perplexityTracker.generateAuditId();
    console.log(`🆔 Single Audit ID: ${auditId}`);

    try {
      // Validate request body
      const validationResult = auditRequestSchema.safeParse(req.body);
      if (!validationResult.success) {
        const validationError = fromZodError(validationResult.error);
        return res.status(400).json({
          error: 'Invalid request data',
          details: validationError.message
        });
      }

      const { websiteUrl, userPlan, topicsPerCategory: requestedTopics, userId, userEmail } = validationResult.data;

      // Create audit record in Firestore
      await perplexityTracker.createAudit({
        auditId,
        userId: userId || 'anonymous',
        userEmail: userEmail, // Add userEmail if available in schema
        websiteUrl,
        planName: userPlan || 'free'
      });

      // Use topics from request (sent by client based on Firestore settings) or default
      const topicsPerCategory = requestedTopics || 3;
      
      console.log(`🎯 Generating audit for ${userPlan || 'free'} plan - ${topicsPerCategory} topics per category`);

      // Get master prompt from Firestore (or use default)
      let masterPrompt = await getMasterPrompt();
      
      // Replace placeholders with dynamic values
      const totalTopics = topicsPerCategory * 4;
      const promptWithReplacements = masterPrompt
        .replace(/{WEBSITE_URL}/g, websiteUrl)
        .replace(/{TOPIC_COUNT}/g, topicsPerCategory.toString())
        .replace(/{TOTAL_TOPICS}/g, totalTopics.toString());

      // Get the correct API key based on user type (AppSumo vs regular)
      let apiKey: string;
      try {
        apiKey = await getPerplexityApiKeyForUser(userId);
      } catch (error: any) {
        if (error.message?.includes('APPSUMO_KEY_REQUIRED')) {
          // Fail the audit tracking
          await perplexityTracker.completeAudit(auditId, {
            status: 'failed',
            duration: Date.now() - startTime,
            topicsGenerated: 0,
            errorMessage: 'AppSumo key required'
          });

          return res.status(400).json({ 
            error: 'API key required',
            details: 'AppSumo lifetime users must add their own Perplexity API key in Profile → API Configuration before running audits.',
            code: 'APPSUMO_KEY_REQUIRED'
          });
        }
        return res.status(500).json({ error: 'API key configuration error' });
      }

      console.log('promptWithReplacementspromptWithReplacements', promptWithReplacements);

      // Calculate required tokens based on topic count
      // ~50 tokens per topic, 4 categories, plus overhead
      const estimatedTokens = Math.min(
        (topicsPerCategory * 4 * 50) + 2000,
        12000 // Perplexity API max
      );

      console.log(`📊 Requesting ${estimatedTokens} tokens for ${topicsPerCategory} topics per category`);

      // Call Perplexity API with optimized settings
      const response = await axios.post(
        'https://api.perplexity.ai/chat/completions',
        {
          model: 'sonar-pro',
          messages: [
            {
              role: 'system',
              content: `You are an AI SEO analyst. Generate EXACTLY ${topicsPerCategory} topics per category (${totalTopics} total). Do not generate fewer. Respond with the exact JSON format requested.`
            },
            {
              role: 'user',
              content: promptWithReplacements
            }
          ],
          // max_tokens: estimatedTokens,
          temperature: 0.2, // Slightly higher for variety in large topic sets
          top_p: 0.9,
          stream: false
        },
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          // timeout: topicsPerCategory > 25 ? 150000 : 90000 // 2.5 minutes for large requests, 90s for normal
        }
      );

      // Log usage
      const usage = response.data.usage;
      await perplexityTracker.logApiCall({
        auditId,
        type: 'topic_authoritative', // Using a generic type for single audit or we could map to 'single_audit'
        model: 'sonar-pro',
        tokens: {
          input: usage?.prompt_tokens || 0,
          output: usage?.completion_tokens || 0,
          total: usage?.total_tokens || 0
        },
        userId: userId || 'anonymous',
        websiteUrl,
        responseTime: Date.now() - startTime, // Approx
        status: 'success',
        promptLength: promptWithReplacements.length,
        responseLength: response.data.choices?.[0]?.message?.content?.length || 0
      });

      // Parse response with robust JSON extraction
      let auditData: AuditData;
      try {
        const content = response.data.choices[0].message.content;
        console.log('Raw AI response length:', content.length);
        
        // Helper to repair truncated JSON
        const repairTruncatedJSON = (str: string): string => {
          let result = str.trim();
          
          // Check if we're inside an unclosed string by counting unescaped quotes
          let inString = false;
          let lastQuoteIndex = -1;
          for (let i = 0; i < result.length; i++) {
            if (result[i] === '"' && (i === 0 || result[i - 1] !== '\\')) {
              inString = !inString;
              if (inString) lastQuoteIndex = i;
            }
          }
          
          // If we're inside a string, close it
          if (inString) {
            result += '"';
          }
          
          // Remove any trailing incomplete key-value pair after the last complete one
          // This handles cases like: {"key": "value", "incomplete
          // Look for patterns like: , "key (incomplete key without value)
          result = result.replace(/,\s*"[^"]*"?\s*:?\s*"?[^"]*$/, '');
          
          // Remove trailing commas
          result = result.replace(/,(\s*)$/, '$1');
          
          // Count and balance brackets/braces
          const openBraces = (result.match(/\{/g) || []).length;
          const closeBraces = (result.match(/\}/g) || []).length;
          const openBrackets = (result.match(/\[/g) || []).length;
          const closeBrackets = (result.match(/\]/g) || []).length;
          
          // Close arrays first, then objects (reverse of typical JSON structure)
          result += ']'.repeat(Math.max(0, openBrackets - closeBrackets));
          result += '}'.repeat(Math.max(0, openBraces - closeBraces));
          
          return result;
        };
        
        // Helper to extract and repair JSON
        const parseRobustJSON = (str: string): any => {
          // 1. Try extracting from markdown code blocks
          let jsonCandidate = str;
          const codeBlockMatch = str.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
        if (codeBlockMatch) {
            jsonCandidate = codeBlockMatch[1];
        } else {
            // 2. If no code block, try finding the outermost object
            const firstBrace = str.indexOf('{');
            const lastBrace = str.lastIndexOf('}');
          if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
              jsonCandidate = str.substring(firstBrace, lastBrace + 1);
            } else if (firstBrace !== -1) {
              // JSON is truncated - no closing brace found
              jsonCandidate = str.substring(firstBrace);
            }
          }

          // 3. Attempt direct parse
          try {
            return JSON.parse(jsonCandidate);
          } catch (e) {
            console.log('Direct parse failed, attempting repair...');
            
            // 4. Apply repair for truncated JSON
            let repaired = repairTruncatedJSON(jsonCandidate);
            
            // 5. Remove trailing commas before closing braces/brackets
            repaired = repaired.replace(/,(\s*[}\]])/g, '$1');
            
            try {
              return JSON.parse(repaired);
            } catch (e2) {
              console.log('Repair attempt 1 failed, trying aggressive cleanup...');
              
              // 6. More aggressive: find last complete array element and truncate there
              // Look for pattern like }, { or }, ] and truncate incomplete items
              let cleaned = repaired;
              
              // Find all positions of complete objects in arrays
              const lastCompleteObject = cleaned.lastIndexOf('},');
              const lastCompleteArrayEnd = cleaned.lastIndexOf('}]');
              
              if (lastCompleteObject > lastCompleteArrayEnd && lastCompleteObject > 0) {
                // Truncate after the last complete object and close the structure
                cleaned = cleaned.substring(0, lastCompleteObject + 1);
                const openBrackets = (cleaned.match(/\[/g) || []).length;
                const closeBrackets = (cleaned.match(/\]/g) || []).length;
                const openBraces = (cleaned.match(/\{/g) || []).length;
                const closeBraces = (cleaned.match(/\}/g) || []).length;
                cleaned += ']'.repeat(Math.max(0, openBrackets - closeBrackets));
                cleaned += '}'.repeat(Math.max(0, openBraces - closeBraces));
              }
              
              try {
                return JSON.parse(cleaned);
              } catch (e3) {
                // 7. Last resort: normalize whitespace and try again
                cleaned = cleaned
                  .replace(/[\r\n\t]/g, ' ')
                  .replace(/\s+/g, ' ')
                  .trim();
                
                return JSON.parse(cleaned);
              }
            }
          }
        };

        auditData = parseRobustJSON(content);
        
      } catch (parseError) {
        console.error('JSON Parse Error:', parseError);
        console.error('Failed to parse response. Content preview:', 
          response.data.choices[0]?.message?.content?.substring(0, 500) + '...');
        
        // Log failure
        await perplexityTracker.completeAudit(auditId, {
          status: 'failed',
          duration: Date.now() - startTime,
          topicsGenerated: 0,
          errorMessage: 'JSON Parse Error'
        });

        return res.status(500).json({
          error: 'Failed to parse AI response. The AI returned malformed data. Please try again.'
        });
      }

      // Validate response structure (keep existing validation)
      if (!auditData.auditResults || !auditData.contentTopics) {
        // Log failure
        await perplexityTracker.completeAudit(auditId, {
          status: 'failed',
          duration: Date.now() - startTime,
          topicsGenerated: 0,
          errorMessage: 'Invalid response structure'
        });

        return res.status(500).json({
          error: 'Invalid response structure from AI. Please try again.'
        });
      }

      // Calculate processing time
      const processingTime = Math.round((Date.now() - startTime) / 1000);
      
      // Add processing details to audit data if not already present
      if (!auditData.processingDetails) {
        auditData.processingDetails = {
          analysisDepth: "comprehensive",
          competitorsAnalyzed: auditData.competitorAnalysis?.mainCompetitors?.length || 0,
          dataSourcesUsed: ["website content", "competitor research", "market intelligence", "AI platform analysis"],
          processingTime: `${processingTime} seconds`
        };
      }

      // Complete audit tracking
      await perplexityTracker.completeAudit(auditId, {
        status: 'completed',
        duration: Date.now() - startTime,
        topicsGenerated: totalTopics
      });

      // Return enhanced response (keeping existing structure intact)
      res.json({
        success: true,
        websiteUrl: websiteUrl,
        auditData: auditData,
        auditId: auditId, // Return the audit ID
        generatedAt: new Date().toISOString()
      });

    } catch (error: any) {
      // Log error details safely without exposing API keys
      const errorStatus = error.response?.status;
      const errorData = error.response?.data;
      console.error('Perplexity API Error:', {
        status: errorStatus,
        message: errorData?.error || errorData,
        url: error.config?.url
      });

      // Track failure
      await perplexityTracker.completeAudit(auditId, {
        status: 'failed',
        duration: Date.now() - startTime,
        topicsGenerated: 0,
        errorMessage: error.message || 'Unknown error'
      });

      if (errorStatus === 401) {
        return res.status(500).json({
          error: 'API authentication failed. Please check configuration.'
        });
      }

      if (errorStatus === 429) {
        return res.status(429).json({
          error: 'Rate limit exceeded. Please try again in a few minutes.'
        });
      }

      if (errorStatus === 400) {
        return res.status(500).json({
          error: `API request error: ${errorData?.error || 'Bad request format'}`
        });
      }

      if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
        return res.status(408).json({
          error: 'Analysis timeout. The request took too long to process. Please try again with a simpler website or try again later.'
        });
      }

      res.status(500).json({
        error: 'An unexpected error occurred. Please try again.'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
