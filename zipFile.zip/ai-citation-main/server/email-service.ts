import 'dotenv/config';

interface EmailParams {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

class EmailService {
  private apiKey: string;
  private fromEmail: string;
  private fromName: string;

  constructor() {
    this.apiKey = process.env.MAILERSEND_API_KEY || '';
    this.fromEmail = process.env.MAILERSEND_FROM_EMAIL || 'info@yourdomain.com';
    this.fromName = process.env.MAILERSEND_FROM_NAME || 'AI Citation Audit';

    if (!this.apiKey) {
      console.warn('⚠️ MAILERSEND_API_KEY not configured - emails will not be sent');
    }
  }

  /**
   * Send email using MailerSend API
   */
  async sendEmail(params: EmailParams): Promise<boolean> {
    if (!this.apiKey) {
      console.log('📧 Email not sent (API key not configured)');
      return false;
    }

    try {
      console.log(`📧 Sending email to ${params.to}: ${params.subject}`);

      const response = await fetch('https://api.mailersend.com/v1/email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          from: {
            email: this.fromEmail,
            name: this.fromName
          },
          to: [
            {
              email: params.to
            }
          ],
          subject: params.subject,
          text: params.text || params.subject,
          html: params.html
        })
      });

      if (response.ok) {
        console.log('✅ Email sent successfully');
        return true;
      } else {
        const errorData = await response.json();
        console.error('❌ Email sending failed:', errorData);
        return false;
      }
    } catch (error) {
      console.error('❌ Email sending error:', error);
      return false;
    }
  }

  /**
   * Send welcome email to new user (first signup)
   */
  async sendSignupWelcomeEmail(
    userEmail: string,
    userName: string
  ): Promise<boolean> {
    const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 20px; text-align: center; border-radius: 10px 10px 0 0; }
    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
    .welcome-icon { font-size: 60px; margin: 20px 0; }
    .features { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
    .feature-item { padding: 12px; margin: 8px 0; background: #f3f4f6; border-radius: 6px; border-left: 4px solid #667eea; }
    .cta-button { background: #667eea; color: white; padding: 14px 35px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 25px 0; font-weight: bold; }
    .info-box { background: #e0e7ff; border: 1px solid #667eea; padding: 15px; border-radius: 6px; margin: 20px 0; }
    .footer { text-align: center; color: #6b7280; padding: 20px; font-size: 14px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="welcome-icon">🎉</div>
      <h1>Welcome to AI Citation Audit!</h1>
      <p>Your account has been created successfully</p>
    </div>
    
    <div class="content">
      <h2>Hi ${userName},</h2>
      
      <p>Welcome aboard! We're excited to help you dominate AI-powered search results and get your business cited by ChatGPT, Perplexity, Gemini, and Claude.</p>
      
      <div class="features">
        <h3 style="margin-bottom: 15px;">🚀 What You Can Do Now:</h3>
        
        <div class="feature-item">
          <strong>🔍 Run Your First Audit</strong><br>
          <span style="font-size: 14px; color: #6b7280;">Analyze how AI platforms see your website and discover citation opportunities</span>
        </div>
        
        <div class="feature-item">
          <strong>📊 Get Actionable Insights</strong><br>
          <span style="font-size: 14px; color: #6b7280;">See your scores across ChatGPT, Perplexity, Gemini, and Claude</span>
        </div>
        
        <div class="feature-item">
          <strong>📥 Download Reports</strong><br>
          <span style="font-size: 14px; color: #6b7280;">Export professional PDF reports with all findings and recommendations</span>
        </div>
        
        <div class="feature-item">
          <strong>🏆 Beat Competitors</strong><br>
          <span style="font-size: 14px; color: #6b7280;">Discover content gaps and opportunities your competitors are missing</span>
        </div>
      </div>
      
      <div class="info-box">
        <strong>🎁 Your Free Plan Includes:</strong><br>
        • 1 audit per month<br>
        • 3 topics per category<br>
        • Basic platform scores<br>
        • PDF export<br>
        <br>
        <em>Want more? Upgrade to Pro for unlimited audits and advanced features!</em>
      </div>
      
      <center>
        <a href="${process.env.PRODUCTION_URL || 'http://localhost:5001'}" class="cta-button">
          🚀 Run Your First Audit
        </a>
      </center>
      
      <p style="margin-top: 30px;"><strong>Quick Start Guide:</strong></p>
      <ol style="line-height: 1.8;">
        <li>Enter your website URL</li>
        <li>Click "Run Audit"</li>
        <li>Wait 30-60 seconds for analysis</li>
        <li>Review your results and download the report</li>
      </ol>
      
      <p>Need help getting started? Check out our <a href="${process.env.PRODUCTION_URL || 'http://localhost:5001'}/help" style="color: #667eea;">Help Center</a> or reply to this email.</p>
      
      <p style="margin-top: 30px;">Happy optimizing! 🎯</p>
      <p><em>- The AI Citation Audit Team</em></p>
    </div>
    
    <div class="footer">
      <p><strong>AI Citation Audit</strong> - Dominate AI Search Results</p>
      <p>Questions? Email us at support@aicitationaudit.com</p>
      <p style="margin-top: 10px; font-size: 12px;">You're receiving this because you created an account with us.</p>
    </div>
  </div>
</body>
</html>
    `;

    return this.sendEmail({
      to: userEmail,
      subject: `🎉 Welcome to AI Citation Audit - Let's Get Started!`,
      html,
      text: `Welcome to AI Citation Audit, ${userName}! Your account has been created. Run your first audit at ${process.env.PRODUCTION_URL || 'http://localhost:5001'}`
    });
  }

  /**
   * Send welcome email to new subscriber
   */
  async sendWelcomeEmail(
    userEmail: string,
    userName: string,
    planName: string,
    billingPeriod: 'monthly' | 'annual' = 'monthly'
  ): Promise<boolean> {
    const planDetails = {
      starter: {
        name: 'Starter',
        monthlyPrice: '$49',
        annualPrice: '$490',
        audits: '10 audits/month',
        topics: '12 topics per category'
      },
      pro: {
        name: 'Pro',
        monthlyPrice: '$149',
        annualPrice: '$1,490',
        audits: 'Unlimited audits',
        topics: '25 topics per category'
      },
      enterprise: {
        name: 'Enterprise',
        monthlyPrice: '$399',
        annualPrice: '$3,990',
        audits: 'Unlimited audits',
        topics: '100 topics per category'
      }
    };

    const plan = planDetails[planName as keyof typeof planDetails];
    const price = billingPeriod === 'annual' ? plan.annualPrice : plan.monthlyPrice;
    const billingText = billingPeriod === 'annual' ? 'Annual (Save 2 months!)' : 'Monthly';

    const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 20px; text-align: center; border-radius: 10px 10px 0 0; }
    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
    .plan-badge { background: #667eea; color: white; padding: 8px 16px; border-radius: 20px; display: inline-block; margin: 20px 0; }
    .features { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
    .feature { padding: 10px 0; border-bottom: 1px solid #e5e7eb; }
    .feature:last-child { border-bottom: none; }
    .cta-button { background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 20px 0; }
    .footer { text-align: center; color: #6b7280; padding: 20px; font-size: 14px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🎉 Welcome to AI Citation Audit!</h1>
      <p>Thank you for subscribing to our ${plan.name} plan</p>
    </div>
    
    <div class="content">
      <h2>Hi ${userName},</h2>
      
      <p>Welcome to AI Citation Audit! Your subscription is now active and you're ready to dominate AI-powered search results.</p>
      
      <div class="plan-badge">
        ${plan.name} Plan - ${price}/${billingText}
      </div>
      
      <div class="features">
        <h3>What's Included:</h3>
        <div class="feature">✅ ${plan.audits}</div>
        <div class="feature">✅ ${plan.topics}</div>
        <div class="feature">✅ Full audit results with competitor analysis</div>
        <div class="feature">✅ Citation intelligence & market context</div>
        <div class="feature">✅ PDF export & downloadable reports</div>
        <div class="feature">✅ Priority email support</div>
      </div>
      
      <p><strong>Next Steps:</strong></p>
      <ul>
        <li>🔍 Run your first AI citation audit</li>
        <li>📊 Analyze your competitors</li>
        <li>📈 Start optimizing for AI search engines</li>
      </ul>
      
      <center>
        <a href="${process.env.PRODUCTION_URL || 'http://localhost:5001'}" class="cta-button">
          Get Started Now
        </a>
      </center>
      
      <p style="margin-top: 30px;">Need help? Reply to this email or visit our <a href="${process.env.PRODUCTION_URL || 'http://localhost:5001'}/help">Help Center</a>.</p>
    </div>
    
    <div class="footer">
      <p>AI Citation Audit - Dominate AI Search Results</p>
      <p>You're receiving this email because you subscribed to our service.</p>
    </div>
  </div>
</body>
</html>
    `;

    return this.sendEmail({
      to: userEmail,
      subject: `🎉 Welcome to AI Citation Audit - ${plan.name} Plan Activated!`,
      html,
      text: `Welcome to AI Citation Audit! Your ${plan.name} plan is now active. Start running audits at ${process.env.PRODUCTION_URL || 'http://localhost:5001'}`
    });
  }

  /**
   * Send cancellation email when subscription ends
   */
  async sendCancellationEmail(
    userEmail: string,
    userName: string,
    planName: string,
    cancellationReason?: string
  ): Promise<boolean> {
    const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 40px 20px; text-align: center; border-radius: 10px 10px 0 0; }
    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
    .info-box { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; border-radius: 4px; }
    .feedback { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
    .cta-button { background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 20px 0; }
    .footer { text-align: center; color: #6b7280; padding: 20px; font-size: 14px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>😢 Sorry to See You Go</h1>
      <p>Your subscription has been cancelled</p>
    </div>
    
    <div class="content">
      <h2>Hi ${userName},</h2>
      
      <p>We've received your cancellation request for the ${planName.toUpperCase()} plan.</p>
      
      <div class="info-box">
        <strong>⚠️ Important:</strong> You'll continue to have access to your current plan until the end of your billing period. After that, your account will be downgraded to the Free plan.
      </div>
      
      <div class="feedback">
        <h3>We'd Love Your Feedback</h3>
        <p>Help us improve! Please let us know why you cancelled:</p>
        ${cancellationReason ? `<p><em>"${cancellationReason}"</em></p>` : ''}
        <p>Your feedback helps us serve you better in the future.</p>
      </div>
      
      <p><strong>What happens next:</strong></p>
      <ul>
        <li>✅ Your current plan remains active until the end of the billing period</li>
        <li>📉 After that, you'll be moved to the Free plan (1 audit/month)</li>
        <li>💾 All your audit history will be preserved</li>
        <li>🔄 You can resubscribe anytime at the same or different plan</li>
      </ul>
      
      <center>
        <a href="${process.env.PRODUCTION_URL || 'http://localhost:5001'}/pricing" class="cta-button">
          View Pricing Plans
        </a>
      </center>
      
      <p style="margin-top: 30px;">Changed your mind? You can reactivate your subscription anytime from your <a href="${process.env.PRODUCTION_URL || 'http://localhost:5001'}/pricing">pricing page</a>.</p>
      
      <p>We hope to see you again soon! 💙</p>
    </div>
    
    <div class="footer">
      <p>AI Citation Audit - Dominate AI Search Results</p>
      <p>Have questions? Contact us at support@aicitationaudit.com</p>
    </div>
  </div>
</body>
</html>
    `;

    return this.sendEmail({
      to: userEmail,
      subject: `Subscription Cancelled - We'll Miss You 😢`,
      html,
      text: `Your ${planName.toUpperCase()} plan subscription has been cancelled. You'll have access until the end of your billing period, then you'll be moved to the Free plan. Resubscribe anytime at ${process.env.PRODUCTION_URL || 'http://localhost:5001'}/pricing`
    });
  }

  /**
   * Send payment success email (alternate to welcome for immediate confirmation)
   */
  async sendPaymentSuccessEmail(
    userEmail: string,
    userName: string,
    planName: string,
    amount: number,
    billingPeriod: 'monthly' | 'annual' = 'monthly'
  ): Promise<boolean> {
    const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 40px 20px; text-align: center; border-radius: 10px 10px 0 0; }
    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
    .receipt { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e5e7eb; }
    .receipt-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #e5e7eb; }
    .receipt-row:last-child { border-bottom: none; font-weight: bold; }
    .cta-button { background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 20px 0; }
    .footer { text-align: center; color: #6b7280; padding: 20px; font-size: 14px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>✅ Payment Successful!</h1>
      <p>Thank you for your purchase</p>
    </div>
    
    <div class="content">
      <h2>Hi ${userName},</h2>
      
      <p>Your payment has been processed successfully! Your <strong>${planName.toUpperCase()}</strong> plan is now active.</p>
      
      <div class="receipt">
        <h3>Receipt</h3>
        <div class="receipt-row">
          <span>Plan:</span>
          <span>${planName.toUpperCase()}</span>
        </div>
        <div class="receipt-row">
          <span>Billing:</span>
          <span>${billingPeriod === 'annual' ? 'Annual (2 months free!)' : 'Monthly'}</span>
        </div>
        <div class="receipt-row">
          <span>Amount Paid:</span>
          <span>$${amount}</span>
        </div>
      </div>
      
      <center>
        <a href="${process.env.PRODUCTION_URL || 'http://localhost:5001'}" class="cta-button">
          Start Using Your Plan
        </a>
      </center>
      
      <p style="margin-top: 30px;">Questions? Contact us at support@aicitationaudit.com</p>
    </div>
    
    <div class="footer">
      <p>AI Citation Audit - Dominate AI Search Results</p>
      <p>This is your payment confirmation email.</p>
    </div>
  </div>
</body>
</html>
    `;

    return this.sendEmail({
      to: userEmail,
      subject: `✅ Payment Confirmed - ${planName.toUpperCase()} Plan Active`,
      html,
      text: `Payment successful! Your ${planName.toUpperCase()} plan is now active. Amount: $${amount} (${billingPeriod}). Start using it at ${process.env.PRODUCTION_URL || 'http://localhost:5001'}`
    });
  }
}

export const emailService = new EmailService();

