// Note: We'll use environment-based defaults since Firebase Admin needs service account
// The frontend will handle Firestore reads for plan settings

const DEFAULT_PROMPT = `Browse {WEBSITE_URL} and analyze competitors. Return this EXACT JSON structure:

{
  "companyIntelligence": {
    "industry": "detected industry",
    "businessType": "business model type",
    "targetAudience": "primary audience",
    "valueProposition": "key value proposition",
    "marketPosition": "market positioning"
  },
  "competitorAnalysis": {
    "mainCompetitors": ["competitor1.com", "competitor2.com", "competitor3.com"],
    "competitorStrengths": ["competitor strength 1", "competitor strength 2"],
    "competitorWeaknesses": ["competitor weakness 1", "competitor weakness 2"],
    "marketOpportunities": ["opportunity 1", "opportunity 2"]
  },
  "auditResults": {
    "overallScore": [number between 0-100],
    "letterGrade": "[A+, A, A-, B+, B, B-, C+, C, C-, D+, D, F]",
    "platformScores": {
      "chatgpt": [number between 0-100],
      "perplexity": [number between 0-100],
      "gemini": [number between 0-100],
      "claude": [number between 0-100]
    },
    "strengths": ["strength 1", "strength 2", "strength 3"],
    "weaknesses": ["weakness 1", "weakness 2", "weakness 3"],
    "technicalFindings": {
      "domainAuthority": "[High/Medium/Low]",
      "contentStructure": "[Excellent/Good/Fair/Poor]",
      "schemaMarkup": "[Implemented/Partial/Missing]",
      "entityRecognition": "[Strong/Moderate/Weak]"
    }
  },
  "contentTopics": {
    "authoritative": [{"topic": "question", "confidence": [85-95], "justification": "reasoning", "platforms": ["platforms"], "searchVolume": "estimate", "competitionLevel": "Low/Medium/High", "competitorGap": "advantage"}],
    "thoughtLeadership": [{"topic": "question", "confidence": [70-84], "justification": "reasoning", "platforms": ["platforms"], "searchVolume": "estimate", "competitionLevel": "Low/Medium/High", "competitorGap": "advantage"}],
    "competitiveAdvantage": [{"topic": "question", "confidence": [50-69], "justification": "reasoning", "platforms": ["platforms"], "searchVolume": "estimate", "competitionLevel": "Low/Medium/High", "competitorGap": "gap"}],
    "emergingOpportunity": [{"topic": "question", "confidence": [30-49], "justification": "potential", "platforms": ["platforms"], "searchVolume": "estimate", "competitionLevel": "Low/Medium/High", "competitorGap": "opportunity"}]
  },
  "citationIntelligence": {
    "currentCitationPresence": {
      "totalCitations": 5,
      "platformBreakdown": {"chatgpt": 1, "perplexity": 2, "gemini": 1, "claude": 1},
      "topCitedContent": ["content"]
    },
    "competitorCitationAnalysis": {
      "competitorCitations": {"competitor1.com": 25},
      "citationGaps": ["gap"]
    },
    "citationOpportunities": ["opportunity"]
  },
  "marketContext": {
    "industryTrends": ["trend 1", "trend 2", "trend 3"]
  },
  "recommendations": ["recommendation 1", "recommendation 2", "recommendation 3"]
}

Replace placeholders with real data from {WEBSITE_URL}. Include all sections.

Website: {WEBSITE_URL}`;

export async function getMasterPrompt(): Promise<string> {
  // For now, return default prompt
  // Frontend admin panel updates will be handled client-side
  return DEFAULT_PROMPT;
}

// Get plan settings - using defaults for now
// Client SDK handles the actual Firestore reads
export async function getPlanSettings(plan: string): Promise<{ topicsPerCategory: number }> {
  // Default topic counts by plan
  const defaults: Record<string, number> = {
    free: 3,
    starter: 12,
    pro: 25,
    enterprise: 100,
    lifetime: 100
  };

  return { topicsPerCategory: defaults[plan] || 3 };
}

