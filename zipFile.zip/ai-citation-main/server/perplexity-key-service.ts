import 'dotenv/config';
import { initializeApp, getApp } from 'firebase/app';
import { getFirestore, doc, getDoc } from 'firebase/firestore';

// Initialize Firebase client SDK
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
};

let db: any;
try {
  const app = initializeApp(firebaseConfig, 'perplexity-key-service');
  db = getFirestore(app);
} catch (e: any) {
  if (e.code === 'app/duplicate-app') {
    const app = getApp('perplexity-key-service');
    db = getFirestore(app);
  } else {
    const app = initializeApp(firebaseConfig);
    db = getFirestore(app);
  }
}

/**
 * Get the correct Perplexity API key for a user
 * AppSumo lifetime users use their own key, others use platform key
 */
export async function getPerplexityApiKeyForUser(userId?: string): Promise<string> {
  // If no userId provided, use platform key
  if (!userId || userId === 'anonymous') {
    const platformKey = process.env.PERPLEXITY_API_KEY;
    if (!platformKey) {
      throw new Error('Platform Perplexity API key not configured');
    }
    console.log('🔑 Using platform Perplexity API key');
    return platformKey;
  }

  try {
    // Get user from Firestore
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      console.log('⚠️ User not found, using platform key');
      return process.env.PERPLEXITY_API_KEY!;
    }

    const userData = userDoc.data();

    // Check if AppSumo lifetime user
    if (userData.subscriptionPlan === 'lifetime') {
      console.log('🎁 AppSumo lifetime user detected');
      
      // Check if user has their own key
      if (userData.perplexityApiKey) {
        console.log('✅ Using user\'s own Perplexity API key');
        return userData.perplexityApiKey;
      } else {
        // AppSumo user WITHOUT key - this is an error!
        console.error('❌ AppSumo user has no Perplexity API key');
        throw new Error('APPSUMO_KEY_REQUIRED: AppSumo lifetime users must add their own Perplexity API key. Please add your key in Profile → API Configuration.');
      }
    }

    // All other users (free, starter, pro, enterprise) - use platform key
    console.log(`🔑 Using platform key for ${userData.subscriptionPlan} user`);
    const platformKey = process.env.PERPLEXITY_API_KEY;
    if (!platformKey) {
      throw new Error('Platform Perplexity API key not configured');
    }
    return platformKey;
  } catch (error: any) {
    // If it's the AppSumo key required error, re-throw it
    if (error.message?.includes('APPSUMO_KEY_REQUIRED')) {
      throw error;
    }
    
    // For other errors, fall back to platform key
    console.error('⚠️ Error getting user key, falling back to platform key:', error.message);
    const platformKey = process.env.PERPLEXITY_API_KEY;
    if (!platformKey) {
      throw new Error('Platform Perplexity API key not configured');
    }
    return platformKey;
  }
}

/**
 * Validate if a Perplexity API key works
 */
export async function validatePerplexityApiKey(apiKey: string): Promise<boolean> {
  try {
    const response = await fetch('https://api.perplexity.ai/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'sonar-pro',
        messages: [{
          role: 'user',
          content: 'Test'
        }],
        max_tokens: 10
      })
    });

    return response.ok || response.status === 200;
  } catch (error) {
    console.error('API key validation error:', error);
    return false;
  }
}

