# Overview

This is an AI Citation Audit SaaS application built with React (frontend) and Express.js (backend). The application analyzes websites for AI search visibility across platforms like ChatGPT, Perplexity, Gemini, and Claude. Users submit a website URL and receive comprehensive audit results including platform-specific scores, strengths/weaknesses analysis, technical findings, and content topic recommendations for improved AI citation opportunities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Styling**: Tailwind CSS with CSS variables for theming, configured for dark mode

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful API with a single `/api/audit` endpoint for website analysis
- **Request Handling**: JSON middleware with URL encoding support
- **Security**: Helmet for security headers, CORS enabled, express-rate-limit for API protection
- **External API Integration**: Axios for making HTTP requests to AI analysis services
- **Development**: Vite middleware integration for hot module replacement in development

## Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM configured (schema in `shared/schema.ts`)
- **Session Storage**: connect-pg-simple for PostgreSQL session storage
- **Database Provider**: Neon Database (@neondatabase/serverless) for serverless PostgreSQL
- **Migrations**: Drizzle-kit for database schema migrations

## Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL backing store
- **Security Headers**: Helmet middleware for XSS protection and security headers
- **Rate Limiting**: Express-rate-limit to prevent API abuse
- **CORS**: Configured for cross-origin requests

## External Dependencies
- **Database**: Neon PostgreSQL database (serverless)
- **AI Analysis**: External AI service integration via HTTP requests (specific provider not visible in current implementation)
- **UI Components**: Radix UI primitives for accessible component foundation
- **Validation**: Zod for runtime type checking and validation
- **Development Tools**: Replit-specific plugins for development environment integration

## Key Design Patterns
- **Shared Schema**: Common TypeScript types and Zod schemas in `shared/` directory for type safety between frontend and backend
- **Component Architecture**: Modular React components with clear separation of concerns (audit form, results display, loading states)
- **Error Handling**: Centralized error handling with user-friendly toast notifications
- **Type Safety**: Full TypeScript implementation with strict type checking
- **Responsive Design**: Mobile-first responsive design with Tailwind CSS
- **API Integration**: Centralized API client with proper error handling and response validation