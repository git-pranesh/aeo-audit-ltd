import { useState } from "react";
import { Search, Users, TrendingUp, Clock, ChevronDown, ChevronUp, Info } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { ContentTopic } from "@shared/schema";

interface EnhancedTopicCardProps {
  topic: ContentTopic;
  index: number;
}

export default function EnhancedTopicCard({ topic, index }: EnhancedTopicCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  
  const getCompetitionColor = (level?: string) => {
    switch (level?.toLowerCase()) {
      case 'low': return 'bg-green-500/20 text-green-400';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400';
      case 'high': return 'bg-red-500/20 text-red-400';
      default: return 'bg-muted/30 text-muted-foreground';
    }
  };

  return (
    <Card className="bg-card border border-border rounded-lg hover:border-primary/50 transition-colors">
      <CardContent className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <h4 className="text-sm font-medium text-foreground leading-tight pr-2">
            {topic.topic}
          </h4>
          <div className="text-xs text-green-400 font-semibold ml-2 flex-shrink-0">
            {topic.confidence}%
          </div>
        </div>

        {/* Enhanced Data Row */}
        {(topic.searchVolume || topic.competitionLevel) && (
          <div className="flex items-center gap-2 mb-3 text-xs">
            {topic.searchVolume && (
              <div className="flex items-center gap-1 text-muted-foreground">
                <Search className="h-3 w-3" />
                <span>{topic.searchVolume}</span>
              </div>
            )}
            {topic.competitionLevel && (
              <Badge variant="secondary" className={`text-xs px-2 py-0.5 ${getCompetitionColor(topic.competitionLevel)}`}>
                {topic.competitionLevel} Competition
              </Badge>
            )}
          </div>
        )}

        {/* Justification */}
        <p className="text-xs text-muted-foreground mb-3 leading-relaxed">
          {topic.justification}
        </p>

        {/* Platforms */}
        <div className="flex flex-wrap gap-1 mb-3">
          {topic.platforms.map((platform, idx) => (
            <span
              key={idx}
              className="px-2 py-1 bg-primary/20 text-primary text-xs rounded"
            >
              {platform}
            </span>
          ))}
        </div>

        {/* Citation Potential (if available) */}
        {topic.citationPotential && (
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-3 p-2 bg-muted/20 rounded">
            <div className="flex items-center gap-1">
              <TrendingUp className="h-3 w-3" />
              <span>Opportunity: {topic.citationPotential.opportunityScore}/100</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              <span>{topic.citationPotential.timeToRank}</span>
            </div>
          </div>
        )}

        {/* Show Details Button */}
        {(topic.competitorGap || topic.currentAIResponse || topic.optimalContentStructure || topic.platformOptimization) && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowDetails(!showDetails)}
            className="w-full text-xs h-6 mt-2"
          >
            <Info className="h-3 w-3 mr-1" />
            {showDetails ? 'Hide Details' : 'Show Details'}
            {showDetails ? <ChevronUp className="h-3 w-3 ml-1" /> : <ChevronDown className="h-3 w-3 ml-1" />}
          </Button>
        )}

        {/* Expanded Details */}
        {showDetails && (
          <div className="mt-3 space-y-3 border-t pt-3">
            {/* Competitor Gap */}
            {topic.competitorGap && (
              <div>
                <div className="text-xs font-medium text-foreground mb-1">Competitive Advantage</div>
                <div className="text-xs text-muted-foreground bg-green-500/10 p-2 rounded">
                  {topic.competitorGap}
                </div>
              </div>
            )}

            {/* Current AI Response */}
            {topic.currentAIResponse && (
              <div>
                <div className="text-xs font-medium text-foreground mb-1">Current AI Landscape</div>
                <div className="text-xs text-muted-foreground bg-blue-500/10 p-2 rounded">
                  {topic.currentAIResponse}
                </div>
              </div>
            )}

            {/* Content Structure */}
            {topic.optimalContentStructure && (
              <div>
                <div className="text-xs font-medium text-foreground mb-2">Optimal Content Structure</div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Format:</span>
                    <span className="text-foreground">{topic.optimalContentStructure.format}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Length:</span>
                    <span className="text-foreground">{topic.optimalContentStructure.length}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Type:</span>
                    <span className="text-foreground">{topic.optimalContentStructure.contentType}</span>
                  </div>
                  {topic.optimalContentStructure.sections.length > 0 && (
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Recommended Sections:</div>
                      <div className="flex flex-wrap gap-1">
                        {topic.optimalContentStructure.sections.map((section, idx) => (
                          <span key={idx} className="text-xs bg-muted/30 px-2 py-1 rounded">
                            {section}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Platform Optimization */}
            {topic.platformOptimization && (
              <div>
                <div className="text-xs font-medium text-foreground mb-2">Platform Optimization</div>
                <div className="space-y-2">
                  {Object.entries(topic.platformOptimization).map(([platform, optimization]) => (
                    <div key={platform} className="bg-muted/20 p-2 rounded">
                      <div className="text-xs font-medium text-primary mb-1 capitalize">{platform}</div>
                      <div className="text-xs text-muted-foreground">{optimization}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
