import { Quote, TrendingUp, BarChart3, Target } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import type { CitationIntelligence } from "@shared/schema";

interface CitationIntelligenceProps {
  citationIntelligence: CitationIntelligence;
}

export default function CitationIntelligenceComponent({ citationIntelligence }: CitationIntelligenceProps) {
  const { currentCitationPresence, competitorCitationAnalysis, citationOpportunities } = citationIntelligence;
  
  // Calculate total competitor citations for comparison
  const competitorCitations = Object.values(competitorCitationAnalysis.competitorCitations);
  const totalCompetitorCitations = competitorCitations.reduce((sum, citations) => sum + citations, 0);
  const avgCompetitorCitations = competitorCitations.length > 0 ? Math.round(totalCompetitorCitations / competitorCitations.length) : 0;

  return (
    <section className="mb-8">
      <div className="text-center mb-6">
        <h2 className="text-3xl font-bold mb-2">Citation Intelligence</h2>
        <p className="text-muted-foreground">Your current AI citation status vs competitors</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6 mb-6">
        {/* Current Citation Status */}
        <Card className="bg-card border border-border shadow-lg fade-in-up">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center mr-3">
                <Quote className="h-4 w-4 text-blue-400" />
              </div>
              <h3 className="text-lg font-semibold">Your Citations</h3>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">
                {currentCitationPresence.totalCitations}
              </div>
              <div className="text-sm text-muted-foreground mb-4">Total Citations</div>
              
              {/* Platform Breakdown */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span>ChatGPT</span>
                  <span className="font-semibold">{currentCitationPresence.platformBreakdown.chatgpt}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span>Perplexity</span>
                  <span className="font-semibold">{currentCitationPresence.platformBreakdown.perplexity}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span>Gemini</span>
                  <span className="font-semibold">{currentCitationPresence.platformBreakdown.gemini}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span>Claude</span>
                  <span className="font-semibold">{currentCitationPresence.platformBreakdown.claude}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Competitor Comparison */}
        <Card className="bg-card border border-border shadow-lg fade-in-up">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-orange-500/20 rounded-lg flex items-center justify-center mr-3">
                <BarChart3 className="h-4 w-4 text-orange-400" />
              </div>
              <h3 className="text-lg font-semibold">vs Competitors</h3>
            </div>
            <div className="space-y-3">
              {Object.entries(competitorCitationAnalysis.competitorCitations).map(([competitor, citations]) => (
                <div key={competitor} className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground truncate mr-2">{competitor}</div>
                  <div className="flex items-center space-x-2">
                    <div className="text-sm font-semibold">{citations}</div>
                    <div className={`text-xs px-2 py-1 rounded ${
                      citations > currentCitationPresence.totalCitations 
                        ? 'bg-red-500/20 text-red-400' 
                        : 'bg-green-500/20 text-green-400'
                    }`}>
                      {citations > currentCitationPresence.totalCitations ? 'Ahead' : 'Behind'}
                    </div>
                  </div>
                </div>
              ))}
              <div className="border-t pt-3 mt-3">
                <div className="flex items-center justify-between text-sm font-semibold">
                  <span>Average</span>
                  <span>{avgCompetitorCitations}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Performance Summary */}
        <Card className="bg-card border border-border shadow-lg fade-in-up">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center mr-3">
                <TrendingUp className="h-4 w-4 text-green-400" />
              </div>
              <h3 className="text-lg font-semibold">Performance</h3>
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-xs text-muted-foreground mb-1">vs Average Competitor</div>
                <div className={`text-2xl font-bold ${
                  currentCitationPresence.totalCitations >= avgCompetitorCitations 
                    ? 'text-green-400' 
                    : 'text-red-400'
                }`}>
                  {currentCitationPresence.totalCitations >= avgCompetitorCitations ? '+' : ''}
                  {currentCitationPresence.totalCitations - avgCompetitorCitations}
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-2">Top Cited Content</div>
                <div className="space-y-1">
                  {currentCitationPresence.topCitedContent.slice(0, 2).map((content, index) => (
                    <div key={index} className="text-xs text-muted-foreground bg-muted/30 rounded p-2">
                      {content}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Citation Gaps & Opportunities */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Citation Gaps */}
        <Card className="bg-card border border-border shadow-lg fade-in-up">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-red-500/20 rounded-lg flex items-center justify-center mr-3">
                <Target className="h-4 w-4 text-red-400" />
              </div>
              <h3 className="text-lg font-semibold">Citation Gaps</h3>
            </div>
            <div className="space-y-3">
              {competitorCitationAnalysis.citationGaps.map((gap, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-red-400 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{gap}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Citation Opportunities */}
        <Card className="bg-card border border-border shadow-lg fade-in-up">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center mr-3">
                <TrendingUp className="h-4 w-4 text-green-400" />
              </div>
              <h3 className="text-lg font-semibold">Citation Opportunities</h3>
            </div>
            <div className="space-y-3">
              {citationOpportunities.map((opportunity, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{opportunity}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
