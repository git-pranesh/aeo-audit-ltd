import { useEffect, useState } from "react";
import { Loader2, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { db } from "@/lib/firebase";
import { doc, getDoc } from "firebase/firestore";

const DEFAULT_LOADING_MESSAGES = [
  "Good things take time—like getting cited by AI engines..",
  "Analyzing how ChatGPT, Perplexity, Gemini, and Claude view your website",
  "Scanning 1000+ AI search patterns to find your citation opportunities..",
  "Comparing your domain authority against top-ranked AI citations...",
  "Identifying content gaps where your competitors are getting cited...",
  "We're building your roadmap to AI search dominance. Worth the wait!",
  "Fun fact: 99% of businesses aren't on AI search radar. You're about to join the 1%.",
  "Deep analysis in progress—your competitors wish they had this intel...",
  "Processing enterprise-grade analysis: 4 platforms × 100 topics × citation probability algorithms...",
  "Our AI is analyzing millions of successful citations to predict your best topics...",
  "Running advanced entity recognition and content structure optimization...",
  "Brewing 100+ topics that AI platforms will love citing. Almost there!"
];

export default function LoadingState() {
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [fade, setFade] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(DEFAULT_LOADING_MESSAGES);

  // Load loading messages from Firestore
  useEffect(() => {
    const loadMessages = async () => {
      try {
        const docRef = doc(db, 'settings', 'homePageContent');
        const docSnap = await getDoc(docRef);

        if (docSnap.exists() && docSnap.data().loadingMessages) {
          setLoadingMessages(docSnap.data().loadingMessages);
          console.log('✅ Loading messages loaded from database');
        }
      } catch (error) {
        console.error('❌ Error loading messages:', error);
      }
    };

    loadMessages();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setFade(false);
      
      setTimeout(() => {
        setCurrentMessageIndex((prev) => (prev + 1) % loadingMessages.length);
        setFade(true);
      }, 300);
    }, 4000); // Change message every 4 seconds

    return () => clearInterval(interval);
  }, [loadingMessages]);

  return (
    <section className="mb-12">
      <div className="max-w-3xl mx-auto text-center">
        <Card className="bg-gradient-to-br from-card via-card to-primary/5 border-2 border-primary/20 shadow-2xl">
          <CardContent className="p-12">
            {/* Animated Spinner */}
            <div className="relative mb-8 flex justify-center">
              <div className="relative w-24 h-24">
                {/* Outer ring - static */}
                <div className="absolute inset-0 rounded-full border-4 border-primary/10"></div>
                
                {/* Spinning ring */}
                <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-primary animate-spin"></div>
                
                {/* Inner pulsing icon */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles className="h-12 w-12 text-primary animate-pulse" />
              </div>
              </div>
            </div>

            {/* Main Title */}
            <h3 className="text-2xl font-bold mb-3 bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              AI Citation Analysis in Progress
            </h3>

            {/* Rotating Messages */}
            <div className="min-h-[80px] flex items-center justify-center mb-6">
              <p 
                className={`text-lg text-muted-foreground max-w-2xl transition-opacity duration-300 ${
                  fade ? 'opacity-100' : 'opacity-0'
                }`}
                style={{ 
                  fontStyle: 'italic',
                  lineHeight: '1.6'
                }}
              >
                {loadingMessages[currentMessageIndex]}
              </p>
            </div>

            {/* Progress Indicator */}
            <div className="flex items-center justify-center space-x-2 text-sm text-primary">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span className="font-medium">This may take 30-60 seconds for comprehensive analysis</span>
            </div>

            {/* Animated Progress Bar */}
            <div className="mt-6 w-full bg-muted/30 rounded-full h-2 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-primary via-purple-600 to-primary bg-[length:200%_100%] animate-shimmer"
                style={{
                  width: '100%',
                  animation: 'shimmer 2s ease-in-out infinite'
                }}
              ></div>
            </div>
          </CardContent>
        </Card>
      </div>

      <style>{`
        @keyframes shimmer {
          0% {
            background-position: -200% 0;
          }
          100% {
            background-position: 200% 0;
          }
        }
      `}</style>
    </section>
  );
}
