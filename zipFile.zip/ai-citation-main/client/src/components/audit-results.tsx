import { useState } from "react";
import { CheckCircle, AlertTriangle, Settings, Lightbulb, Share2, Clock, Database } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type { AuditData, ContentTopic } from "@shared/schema";
import CompanyIntelligenceComponent from "./company-intelligence";
import CompetitorAnalysisComponent from "./competitor-analysis";
import CitationIntelligenceComponent from "./citation-intelligence";
import MarketContextComponent from "./market-context";
import EnhancedTopicCard from "./enhanced-topic-card";
import EnhancedRecommendationsComponent from "./enhanced-recommendations";

interface AuditResultsProps {
  auditData: AuditData;
  websiteUrl: string;
}

export default function AuditResults({ auditData, websiteUrl }: AuditResultsProps) {
  const { toast } = useToast();
  const [activeTopicCategory, setActiveTopicCategory] = useState<keyof typeof auditData.contentTopics>("authoritative");
  const [showAllTopics, setShowAllTopics] = useState(false);

  const topicCategories = [
    { key: "authoritative" as const, label: "Authoritative", range: "85-95%" },
    { key: "thoughtLeadership" as const, label: "Thought Leadership", range: "70-84%" },
    { key: "competitiveAdvantage" as const, label: "Competitive Advantage", range: "50-69%" },
    { key: "emergingOpportunity" as const, label: "Emerging Opportunity", range: "30-49%" }
  ];

  // Share functionality
  const handleShare = async () => {
    const shareData = {
      title: `AI Citation Audit Results for ${new URL(websiteUrl).hostname}`,
      text: `AI Citation Score: ${auditData.auditResults.overallScore}/100 (Grade: ${auditData.auditResults.letterGrade}). Get your website analyzed for AI search visibility.`,
      url: window.location.href
    };

    try {
      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
        toast({
          title: "Shared successfully",
          description: "Audit results have been shared.",
        });
      } else {
        // Fallback to clipboard
        await navigator.clipboard.writeText(`${shareData.title}\n${shareData.text}\n${shareData.url}`);
        toast({
          title: "Copied to clipboard",
          description: "Audit results summary has been copied to your clipboard.",
        });
      }
    } catch (error) {
      console.error('Share failed:', error);
      toast({
        title: "Share failed",
        description: "Unable to share results. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Get current topic count dynamically
  const getCurrentTopicCount = () => {
    return auditData.contentTopics[activeTopicCategory]?.length || 0;
  };

  // Get topics to display (limited or all)
  const getTopicsToDisplay = () => {
    const topics = auditData.contentTopics[activeTopicCategory] || [];
    return showAllTopics ? topics : topics.slice(0, 9);
  };

  const renderTopicCard = (topic: ContentTopic, index: number) => (
    <EnhancedTopicCard key={index} topic={topic} index={index} />
  );

  return (
    <section className="space-y-8">
      {/* Company Intelligence - New */}
      {auditData.companyIntelligence && (
        <CompanyIntelligenceComponent 
          companyIntelligence={auditData.companyIntelligence} 
          websiteUrl={websiteUrl} 
        />
      )}

      {/* Overall Score Card */}
      <Card className="bg-card border border-border shadow-lg fade-in-up">
        <CardContent className="p-8 text-center">
          <div className="mb-6">
            <h2 className="text-2xl font-bold mb-2">Overall AI Citation Score</h2>
            <p className="text-muted-foreground">Your website's visibility across AI platforms</p>
          </div>
          <div className="flex items-center justify-center space-x-8 mb-8">
            <div>
              <div className="text-6xl font-bold text-primary mb-2" data-testid="text-overall-score">
                {auditData.auditResults.overallScore}
              </div>
              <div className="text-sm text-muted-foreground">Overall Score</div>
            </div>
            <div className="w-px h-20 bg-border"></div>
            <div>
              <div className="text-4xl font-bold text-foreground mb-2" data-testid="text-letter-grade">
                {auditData.auditResults.letterGrade}
              </div>
              <div className="text-sm text-muted-foreground">Letter Grade</div>
            </div>
          </div>

          {/* Platform Scores Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-muted/30 rounded-lg p-4">
              <div className="flex items-center justify-center mb-2">
                <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
                  <div className="w-4 h-4 bg-primary rounded-full"></div>
                </div>
              </div>
              <div className="text-sm font-medium text-muted-foreground mb-1">ChatGPT</div>
              <div className="text-2xl font-bold text-foreground" data-testid="text-chatgpt-score">
                {auditData.auditResults.platformScores.chatgpt}
              </div>
            </div>
            <div className="bg-muted/30 rounded-lg p-4">
              <div className="flex items-center justify-center mb-2">
                <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
                  <div className="w-4 h-4 bg-primary rounded-full"></div>
                </div>
              </div>
              <div className="text-sm font-medium text-muted-foreground mb-1">Perplexity</div>
              <div className="text-2xl font-bold text-foreground" data-testid="text-perplexity-score">
                {auditData.auditResults.platformScores.perplexity}
              </div>
            </div>
            <div className="bg-muted/30 rounded-lg p-4">
              <div className="flex items-center justify-center mb-2">
                <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
                  <div className="w-4 h-4 bg-primary rounded-full"></div>
                </div>
              </div>
              <div className="text-sm font-medium text-muted-foreground mb-1">Gemini</div>
              <div className="text-2xl font-bold text-foreground" data-testid="text-gemini-score">
                {auditData.auditResults.platformScores.gemini}
              </div>
            </div>
            <div className="bg-muted/30 rounded-lg p-4">
              <div className="flex items-center justify-center mb-2">
                <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
                  <div className="w-4 h-4 bg-primary rounded-full"></div>
                </div>
              </div>
              <div className="text-sm font-medium text-muted-foreground mb-1">Claude</div>
              <div className="text-2xl font-bold text-foreground" data-testid="text-claude-score">
                {auditData.auditResults.platformScores.claude}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Findings Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Strengths */}
        <Card className="bg-card border border-border shadow-lg fade-in-up">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center mr-3">
                <CheckCircle className="h-4 w-4 text-green-400" />
              </div>
              <h3 className="text-lg font-semibold">Strengths</h3>
            </div>
            <div className="space-y-3">
              {auditData.auditResults.strengths.map((strength, index) => (
                <div key={index} className="flex items-start space-x-3" data-testid={`strength-${index}`}>
                  <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-muted-foreground">{strength}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Weaknesses */}
        <Card className="bg-card border border-border shadow-lg fade-in-up">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-yellow-500/20 rounded-lg flex items-center justify-center mr-3">
                <AlertTriangle className="h-4 w-4 text-yellow-400" />
              </div>
              <h3 className="text-lg font-semibold">Areas for Improvement</h3>
            </div>
            <div className="space-y-3">
              {auditData.auditResults.weaknesses.map((weakness, index) => (
                <div key={index} className="flex items-start space-x-3" data-testid={`weakness-${index}`}>
                  <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-muted-foreground">{weakness}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Technical Findings */}
        <Card className="bg-card border border-border shadow-lg fade-in-up md:col-span-2 lg:col-span-1">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center mr-3">
                <Settings className="h-4 w-4 text-blue-400" />
              </div>
              <h3 className="text-lg font-semibold">Technical Analysis</h3>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Domain Authority</span>
                <span className="text-sm font-medium text-green-400" data-testid="text-domain-authority">
                  {auditData.auditResults.technicalFindings.domainAuthority}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Content Structure</span>
                <span className="text-sm font-medium text-blue-400" data-testid="text-content-structure">
                  {auditData.auditResults.technicalFindings.contentStructure}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Schema Markup</span>
                <span className="text-sm font-medium text-green-400" data-testid="text-schema-markup">
                  {auditData.auditResults.technicalFindings.schemaMarkup}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Entity Recognition</span>
                <span className="text-sm font-medium text-yellow-400" data-testid="text-entity-recognition">
                  {auditData.auditResults.technicalFindings.entityRecognition}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Competitor Analysis - New */}
      {auditData.competitorAnalysis && (
        <CompetitorAnalysisComponent competitorAnalysis={auditData.competitorAnalysis} />
      )}

      {/* Citation Intelligence - New */}
      {auditData.citationIntelligence && (
        <CitationIntelligenceComponent citationIntelligence={auditData.citationIntelligence} />
      )}

      {/* Content Topics Section */}
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-2">Content Opportunities</h2>
          <p className="text-muted-foreground">AI-generated topics to boost your citation potential</p>
        </div>

        {/* Topic Categories Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {topicCategories.map((category) => (
            <Button
              key={category.key}
              variant={activeTopicCategory === category.key ? "default" : "secondary"}
              size="sm"
              onClick={() => setActiveTopicCategory(category.key)}
              data-testid={`tab-${category.key}`}
            >
              {category.label} ({auditData.contentTopics[category.key]?.length || 0})
            </Button>
          ))}
        </div>

        {/* Topic Content */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {getTopicsToDisplay().map((topic, index) => renderTopicCard(topic, index))}
          
          {/* Show more/less button */}
          {getCurrentTopicCount() > 9 && (
          <div className="md:col-span-2 lg:col-span-3 text-center pt-4">
              <Button 
                variant="secondary" 
                onClick={() => setShowAllTopics(!showAllTopics)}
                data-testid="button-show-more-topics"
              >
                {showAllTopics ? 'Show Less' : `Show All ${getCurrentTopicCount()} Topics`}
                <svg className={`ml-2 h-4 w-4 transform ${showAllTopics ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </Button>
          </div>
          )}
        </div>
      </div>

      {/* Market Context - New */}
      {auditData.marketContext && (
        <MarketContextComponent marketContext={auditData.marketContext} />
      )}

      {/* Processing Details - New */}
      {auditData.processingDetails && (
        <Card className="bg-card border border-border shadow-lg fade-in-up">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-gray-500/20 rounded-lg flex items-center justify-center mr-3">
                <Database className="h-4 w-4 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold">Analysis Details</h3>
            </div>
            <div className="grid md:grid-cols-4 gap-4 text-center">
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="text-sm font-medium text-foreground mb-1">Depth</div>
                <div className="text-xs text-muted-foreground capitalize">{auditData.processingDetails.analysisDepth}</div>
              </div>
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="text-sm font-medium text-foreground mb-1">Competitors</div>
                <div className="text-xs text-muted-foreground">{auditData.processingDetails.competitorsAnalyzed}</div>
              </div>
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="text-sm font-medium text-foreground mb-1">Data Sources</div>
                <div className="text-xs text-muted-foreground">{auditData.processingDetails.dataSourcesUsed.length}</div>
              </div>
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="text-sm font-medium text-foreground mb-1 flex items-center justify-center gap-1">
                  <Clock className="h-3 w-3" />
                  Processing Time
                </div>
                <div className="text-xs text-muted-foreground">{auditData.processingDetails.processingTime}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recommendations */}
      {auditData.enhancedRecommendations && auditData.enhancedRecommendations.length > 0 ? (
        <EnhancedRecommendationsComponent recommendations={auditData.enhancedRecommendations} />
      ) : (
      <Card className="bg-card border border-border shadow-lg fade-in-up">
        <CardContent className="p-8">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center mr-4">
              <Lightbulb className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">Actionable Recommendations</h2>
              <p className="text-muted-foreground">Priority actions to improve your AI citation score</p>
            </div>
          </div>
          
          <div className="space-y-4">
            {auditData.recommendations.map((recommendation, index) => (
              <div
                key={index}
                className="flex items-start space-x-4 p-4 bg-muted/30 rounded-lg"
                data-testid={`recommendation-${index}`}
              >
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold text-sm flex-shrink-0">
                  {index + 1}
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{recommendation}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      )}
    </section>
  );
}
