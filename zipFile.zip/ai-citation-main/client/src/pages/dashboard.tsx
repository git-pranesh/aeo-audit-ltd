import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { BarChart3, FileText, TrendingUp, User as UserIcon, Crown, History } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { auditDb, getDynamicPlanLimits } from "@/lib/firestore-utils";
import type { AuditDocument } from "@/lib/firestore-utils";

export default function Dashboard() {
  const { user, userDoc, isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [audits, setAudits] = useState<AuditDocument[]>([]);
  const [loadingAudits, setLoadingAudits] = useState(true);
  const [planLimits, setPlanLimits] = useState<any>(null);

  // Load dynamic plan limits
  useEffect(() => {
    getDynamicPlanLimits().then(limits => setPlanLimits(limits));
  }, []);

  // Redirect if not authenticated
  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation('/');
    }
  }, [loading, isAuthenticated, setLocation]);

  // Load user's audit history
  useEffect(() => {
    if (user && userDoc) {
      loadAuditHistory();
    }
  }, [user, userDoc]);

  const loadAuditHistory = async () => {
    if (!user) return;
    
    setLoadingAudits(true);
    try {
      const userAudits = await auditDb.getUserAudits(user.uid, 10);
      setAudits(userAudits);
    } catch (error) {
      console.error('Error loading audit history:', error);
    } finally {
      setLoadingAudits(false);
    }
  };

  // Get user initials
  const getUserInitials = () => {
    if (!user) return 'U';
    if (user.displayName) {
      return user.displayName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    }
    return user.email?.[0].toUpperCase() || 'U';
  };

  // Get plan color
  const getPlanColor = (plan: string) => {
    switch (plan) {
      case 'free': return 'bg-gray-500/20 text-gray-400';
      case 'starter': return 'bg-blue-500/20 text-blue-400';
      case 'pro': return 'bg-purple-500/20 text-purple-400';
      case 'enterprise': return 'bg-orange-500/20 text-orange-400';
      case 'lifetime': return 'bg-green-500/20 text-green-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  // Calculate usage percentage
  const getUsagePercentage = () => {
    if (!userDoc || !planLimit) return 0;
    const limit = planLimit.auditsPerMonth;
    if (limit === -1) return 0; // Unlimited
    return Math.min((userDoc.auditsUsedThisMonth / limit) * 100, 100);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-muted border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!userDoc) {
    return null;
  }

  const planLimit = planLimits ? planLimits[userDoc.subscriptionPlan] : null;
  const isUnlimited = planLimit?.auditsPerMonth === -1;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={() => setLocation('/')}>
              ← Back to Home
            </Button>
            <h1 className="text-xl font-bold">Dashboard</h1>
            <Button variant="outline" onClick={() => setLocation('/profile')}>
              <UserIcon className="h-4 w-4 mr-2" />
              Profile
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Welcome back, {user?.displayName?.split(' ')[0] || 'User'}!</h2>
          <p className="text-muted-foreground">Manage your AI citation audits and subscription</p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Profile Card */}
          <Card className="bg-card border border-border shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4 mb-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={userDoc?.customPhotoURL || user?.photoURL || undefined} />
                  <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                    {getUserInitials()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{user?.displayName || 'User'}</h3>
                  <p className="text-sm text-muted-foreground">{user?.email}</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Member since</span>
                  <span className="font-medium">
                    {userDoc.createdAt?.toDate().toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total audits</span>
                  <span className="font-medium">{userDoc.totalAuditsRun}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Current Plan */}
          <Card className="bg-card border border-border shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center mr-3">
                  <Crown className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Current Plan</h3>
                  <Badge className={`mt-1 capitalize ${getPlanColor(userDoc.subscriptionPlan)}`}>
                    {userDoc.subscriptionPlan} Plan
                  </Badge>
                </div>
              </div>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Audits per month</span>
                  <span className="font-medium">
                    {isUnlimited ? 'Unlimited' : (planLimit?.auditsPerMonth || '-')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Topics per audit</span>
                  <span className="font-medium">{planLimit?.topicsPerCategory || '-'} per category</span>
                </div>
                {userDoc.subscriptionPlan === 'free' && (
                  <Button 
                    className="w-full mt-4" 
                    size="sm"
                    onClick={() => setLocation('/pricing')}
                  >
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Upgrade Plan
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Usage Stats */}
          <Card className="bg-card border border-border shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center mr-3">
                  <BarChart3 className="h-5 w-5 text-blue-400" />
                </div>
                <h3 className="font-semibold">Monthly Usage</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Audits used</span>
                    <span className="font-medium">
                      {userDoc.auditsUsedThisMonth} / {isUnlimited ? '∞' : (planLimit?.auditsPerMonth || '-')}
                    </span>
                  </div>
                  {!isUnlimited && planLimit && (
                    <Progress value={getUsagePercentage()} className="h-2" />
                  )}
                </div>
                <div className="text-xs text-muted-foreground">
                  {isUnlimited 
                    ? 'You have unlimited audits' 
                    : planLimit ? `${planLimit.auditsPerMonth - userDoc.auditsUsedThisMonth} audits remaining this month` : 'Loading...'
                  }
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Audit History */}
        <Card className="bg-card border border-border shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center">
              <History className="h-5 w-5 mr-2" />
              Audit History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingAudits ? (
              <div className="text-center py-8">
                <div className="w-12 h-12 border-4 border-muted border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading audit history...</p>
              </div>
            ) : audits.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-semibold mb-2">No audits yet</h3>
                <p className="text-muted-foreground mb-4">Run your first AI citation audit to see results here</p>
                <Button onClick={() => setLocation('/')}>
                  Run Your First Audit
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {audits.map((audit) => (
                  <div 
                    key={audit.auditId}
                    className="border border-border rounded-lg p-4 hover:border-primary/50 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-semibold text-foreground mb-1">
                          {new URL(audit.websiteUrl).hostname.replace('www.', '')}
                        </h4>
                        <p className="text-xs text-muted-foreground">
                          {audit.generatedAt?.toDate().toLocaleDateString()} at {audit.generatedAt?.toDate().toLocaleTimeString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-primary">
                          {audit.auditData.auditResults.overallScore}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Grade: {audit.auditData.auditResults.letterGrade}
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-2 mb-3">
                      <div className="text-center p-2 bg-muted/30 rounded">
                        <div className="text-xs text-muted-foreground mb-1">ChatGPT</div>
                        <div className="text-sm font-semibold">{audit.auditData.auditResults.platformScores.chatgpt}</div>
                      </div>
                      <div className="text-center p-2 bg-muted/30 rounded">
                        <div className="text-xs text-muted-foreground mb-1">Perplexity</div>
                        <div className="text-sm font-semibold">{audit.auditData.auditResults.platformScores.perplexity}</div>
                      </div>
                      <div className="text-center p-2 bg-muted/30 rounded">
                        <div className="text-xs text-muted-foreground mb-1">Gemini</div>
                        <div className="text-sm font-semibold">{audit.auditData.auditResults.platformScores.gemini}</div>
                      </div>
                      <div className="text-center p-2 bg-muted/30 rounded">
                        <div className="text-xs text-muted-foreground mb-1">Claude</div>
                        <div className="text-sm font-semibold">{audit.auditData.auditResults.platformScores.claude}</div>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <Badge variant="secondary" className="capitalize">
                        {audit.userPlanAtTime} plan
                      </Badge>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setLocation(`/audit/${audit.auditId}`)}
                      >
                        View Details →
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

