import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { ArrowLeft, Download, Share2, FileText, Table } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { auditDb, type AuditDocument } from "@/lib/firestore-utils";
import { CSVExporter } from "@/lib/csv-exporter";
import { usePDFExport } from "@/hooks/use-pdf-export";
import AuditResults from "@/components/audit-results";

export default function AuditDetail() {
  const { toast } = useToast();
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, params] = useRoute("/audit/:auditId");
  const [, setLocation] = useLocation();
  const [audit, setAudit] = useState<AuditDocument | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      setLocation('/');
      return;
    }

    if (params?.auditId && user) {
      loadAuditDetails(params.auditId);
    }
  }, [params?.auditId, authLoading, isAuthenticated, user?.uid]);

  const loadAuditDetails = async (auditId: string) => {
    setLoading(true);
    try {
      const auditData = await auditDb.getAudit(auditId);
      
      if (!auditData) {
        toast({
          title: "Audit not found",
          description: "The requested audit could not be found.",
          variant: "destructive",
        });
        setLocation('/dashboard');
        return;
      }

      // Verify audit belongs to current user
      if (user && auditData.userId !== user.uid) {
        toast({
          title: "Access denied",
          description: "You don't have permission to view this audit.",
          variant: "destructive",
        });
        setLocation('/dashboard');
        return;
      }

      setAudit(auditData);
    } catch (error) {
      console.error('Error loading audit:', error);
      toast({
        title: "Error loading audit",
        description: "Failed to load audit details. Please try again.",
        variant: "destructive",
      });
      setLocation('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  // PDF Export Hook
  const { handleDownloadPDF, handleShare, isGenerating: isPDFGenerating } = usePDFExport({
    auditData: audit?.auditData || null,
    websiteUrl: audit?.websiteUrl || '',
    generatedAt: audit?.generatedAt?.toDate().toISOString()
  });

  // CSV Download
  const handleDownloadCSV = () => {
    if (!audit) return;

    try {
      const csvExporter = new CSVExporter({
        auditData: audit.auditData,
        websiteUrl: audit.websiteUrl,
        generatedAt: audit.generatedAt.toDate().toISOString()
      });
      
      const csvContent = csvExporter.generateFullCSV();
      const domain = new URL(audit.websiteUrl).hostname.replace('www.', '');
      const filename = `ai-citation-audit-${domain}-${audit.generatedAt.toDate().toISOString().split('T')[0]}.csv`;
      
      csvExporter.downloadCSV(filename, csvContent);
      
      toast({
        title: "CSV Report Downloaded",
        description: "Your audit data has been exported to CSV format.",
      });
    } catch (error) {
      console.error('CSV export failed:', error);
      toast({
        title: "CSV Export Failed",
        description: "Unable to export CSV report. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (loading || authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-muted border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading audit details...</p>
        </div>
      </div>
    );
  }

  if (!audit) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={() => setLocation('/dashboard')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
            <div className="text-center">
              <h1 className="text-lg font-bold">{new URL(audit.websiteUrl).hostname.replace('www.', '')}</h1>
              <p className="text-xs text-muted-foreground">
                {audit.generatedAt.toDate().toLocaleDateString()} at {audit.generatedAt.toDate().toLocaleTimeString()}
              </p>
            </div>
            <div className="w-32"></div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Audit Results */}
        <AuditResults auditData={audit.auditData} websiteUrl={audit.websiteUrl} />

        {/* Export Options */}
        <div className="flex flex-wrap justify-center gap-4 pt-8">
          <Button onClick={handleDownloadPDF} disabled={isPDFGenerating} data-testid="button-download-pdf">
            <FileText className="h-4 w-4 mr-2" />
            {isPDFGenerating ? 'Generating...' : 'Save as PDF'}
          </Button>
          <Button variant="secondary" onClick={handleDownloadCSV} data-testid="button-download-csv">
            <Table className="h-4 w-4 mr-2" />
            Export CSV Data
          </Button>
          <Button variant="outline" onClick={handleShare} disabled={isPDFGenerating} data-testid="button-share">
            <Share2 className="h-4 w-4 mr-2" />
            {isPDFGenerating ? 'Preparing...' : 'Share PDF Report'}
          </Button>
        </div>
      </main>
    </div>
  );
}

