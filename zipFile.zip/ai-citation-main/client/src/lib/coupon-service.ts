import { db } from './firebase';
import { collection, query, where, getDocs, updateDoc, doc, Timestamp } from 'firebase/firestore';
import { userDb } from './firestore-utils';

interface CouponValidationResult {
  valid: boolean;
  discount?: {
    type: 'percentage' | 'fixed';
    value: number;
  };
  message: string;
}

export const couponService = {
  // Validate discount coupon
  async validateCoupon(code: string, plan: string): Promise<CouponValidationResult> {
    try {
      const couponsRef = collection(db, 'coupons');
      const q = query(couponsRef, where('code', '==', code.toUpperCase()));
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        return {
          valid: false,
          message: 'Invalid coupon code'
        };
      }

      const couponDoc = snapshot.docs[0];
      const coupon = couponDoc.data();

      // Check if active
      if (!coupon.isActive) {
        return {
          valid: false,
          message: 'This coupon is no longer active'
        };
      }

      // Check if expired
      const now = new Date();
      const validUntil = coupon.validUntil.toDate();
      if (now > validUntil) {
        return {
          valid: false,
          message: 'This coupon has expired'
        };
      }

      // Check usage limit
      if (coupon.timesUsed >= coupon.maxUses) {
        return {
          valid: false,
          message: 'This coupon has reached its usage limit'
        };
      }

      // Check if applicable to selected plan
      if (!coupon.applicablePlans.includes(plan)) {
        return {
          valid: false,
          message: `This coupon is not applicable to the ${plan} plan`
        };
      }

      return {
        valid: true,
        discount: {
          type: coupon.discountType,
          value: coupon.discountValue
        },
        message: 'Coupon applied successfully!'
      };
    } catch (error) {
      console.error('Error validating coupon:', error);
      return {
        valid: false,
        message: 'Error validating coupon. Please try again.'
      };
    }
  },

  // Apply coupon (increment usage count)
  async applyCoupon(code: string): Promise<void> {
    try {
      const couponsRef = collection(db, 'coupons');
      const q = query(couponsRef, where('code', '==', code.toUpperCase()));
      const snapshot = await getDocs(q);

      if (!snapshot.empty) {
        const couponDoc = snapshot.docs[0];
        const currentUsage = couponDoc.data().timesUsed || 0;
        
        await updateDoc(doc(db, 'coupons', couponDoc.id), {
          timesUsed: currentUsage + 1
        });
      }
    } catch (error) {
      console.error('Error applying coupon:', error);
    }
  },

  // Calculate discounted price
  calculateDiscountedPrice(
    originalPrice: number,
    discountType: 'percentage' | 'fixed',
    discountValue: number
  ): number {
    if (discountType === 'percentage') {
      return originalPrice * (1 - discountValue / 100);
    } else {
      return Math.max(0, originalPrice - discountValue);
    }
  },

  // Validate AppSumo code
  async validateAppSumoCode(code: string): Promise<{
    valid: boolean;
    message: string;
  }> {
    try {
      const appSumoRef = collection(db, 'appsumo');
      const q = query(appSumoRef, where('code', '==', code.toUpperCase()));
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        return {
          valid: false,
          message: 'Invalid AppSumo code'
        };
      }

      const codeDoc = snapshot.docs[0];
      const codeData = codeDoc.data();

      if (codeData.isRedeemed) {
        return {
          valid: false,
          message: 'This code has already been redeemed'
        };
      }

      return {
        valid: true,
        message: 'Valid AppSumo lifetime deal code!'
      };
    } catch (error) {
      console.error('Error validating AppSumo code:', error);
      return {
        valid: false,
        message: 'Error validating code. Please try again.'
      };
    }
  },

  // Redeem AppSumo code
  async redeemAppSumoCode(code: string, userId: string, userEmail: string): Promise<boolean> {
    try {
      // Mark code as redeemed
      const appSumoRef = collection(db, 'appsumo');
      const q = query(appSumoRef, where('code', '==', code.toUpperCase()));
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        return false;
      }

      const codeDoc = snapshot.docs[0];
      
      // Update code status
      await updateDoc(doc(db, 'appsumo', codeDoc.id), {
        isRedeemed: true,
        redeemedBy: userEmail,
        redeemedAt: Timestamp.now()
      });

      // Update user to lifetime plan
      await userDb.updateUser(userId, {
        subscriptionPlan: 'lifetime',
        subscriptionStatus: 'active',
        appSumoCode: code.toUpperCase()
      });

      console.log('✅ AppSumo code redeemed:', code);
      return true;
    } catch (error) {
      console.error('Error redeeming AppSumo code:', error);
      return false;
    }
  }
};

