/**
 * Clean, Simple PDF Generator using jsPDF directly
 * No html2canvas dependency = No canvas size limits
 * Works for any document size
 */
import { jsPDF } from 'jspdf';
import type { AuditData } from "@shared/schema";

interface AuditPDFOptions {
  auditData: AuditData;
  websiteUrl: string;
  generatedAt: string;
}

export class AuditPDFGenerator {
  private pdf: jsPDF;
  private auditData: AuditData;
  private domain: string;
  private generatedAt: string;
  private y: number = 25; // Current Y position
  private pageWidth: number;
  private pageHeight: number;
  private margin: number = 20;
  private contentWidth: number;

  constructor(options: AuditPDFOptions) {
    this.pdf = new jsPDF('portrait', 'mm', 'a4');
    this.auditData = options.auditData;
    this.domain = new URL(options.websiteUrl).hostname.replace('www.', '');
    this.generatedAt = options.generatedAt;
    this.pageWidth = this.pdf.internal.pageSize.getWidth();
    this.pageHeight = this.pdf.internal.pageSize.getHeight();
    this.contentWidth = this.pageWidth - (this.margin * 2);
  }

  /**
   * Check if we need a new page
   */
  private checkPageBreak(requiredSpace: number = 20): void {
    if (this.y + requiredSpace > this.pageHeight - 20) {
      this.pdf.addPage();
      this.y = 25;
    }
  }

  /**
   * Add a section title
   */
  private addSectionTitle(title: string): void {
    this.checkPageBreak(25);
    this.y += 8;
    this.pdf.setFontSize(14);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.setTextColor(30, 30, 30);
    this.pdf.text(title, this.margin, this.y);
    this.y += 4;
    
    // Underline
    this.pdf.setDrawColor(99, 102, 241); // Indigo
    this.pdf.setLineWidth(0.5);
    this.pdf.line(this.margin, this.y, this.margin + 60, this.y);
    this.y += 8;
  }

  /**
   * Add wrapped text
   */
  private addText(text: string, fontSize: number = 10, isBold: boolean = false): void {
    this.pdf.setFontSize(fontSize);
    this.pdf.setFont('helvetica', isBold ? 'bold' : 'normal');
    this.pdf.setTextColor(60, 60, 60);
    
    const lines = this.pdf.splitTextToSize(text, this.contentWidth);
    const lineHeight = fontSize * 0.4;
    
    for (const line of lines) {
      this.checkPageBreak(lineHeight + 2);
      this.pdf.text(line, this.margin, this.y);
      this.y += lineHeight;
    }
    this.y += 2;
  }

  /**
   * Add a key-value pair
   */
  private addKeyValue(key: string, value: string | number): void {
    this.checkPageBreak(8);
    this.pdf.setFontSize(10);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.setTextColor(100, 100, 100);
    this.pdf.text(`${key}:`, this.margin, this.y);
    
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.setTextColor(30, 30, 30);
    this.pdf.text(String(value), this.margin + 45, this.y);
    this.y += 6;
  }

  /**
   * Add bullet point
   */
  private addBulletPoint(text: string, bulletColor: number[] = [99, 102, 241]): void {
    this.checkPageBreak(12);
    
    // Bullet
    this.pdf.setFillColor(bulletColor[0], bulletColor[1], bulletColor[2]);
    this.pdf.circle(this.margin + 2, this.y - 1.5, 1, 'F');
    
    // Text
    this.pdf.setFontSize(9);
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.setTextColor(60, 60, 60);
    
    const lines = this.pdf.splitTextToSize(text, this.contentWidth - 10);
    for (let i = 0; i < lines.length; i++) {
      if (i > 0) this.checkPageBreak(5);
      this.pdf.text(lines[i], this.margin + 7, this.y);
      this.y += 4.5;
    }
    this.y += 1;
  }

  /**
   * Generate the header section
   */
  private addHeader(): void {
    // Title
    this.pdf.setFontSize(22);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.setTextColor(30, 30, 30);
    this.pdf.text('AI Citation Audit Report', this.margin, this.y);
    this.y += 10;
    
    // Domain
    this.pdf.setFontSize(14);
    this.pdf.setTextColor(99, 102, 241); // Indigo
    this.pdf.text(this.domain, this.margin, this.y);
    this.y += 8;
    
    // Generated date
    this.pdf.setFontSize(9);
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.setTextColor(120, 120, 120);
    const dateStr = new Date(this.generatedAt).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    this.pdf.text(`Generated: ${dateStr}`, this.margin, this.y);
    this.y += 5;
    
    // Separator line
    this.pdf.setDrawColor(200, 200, 200);
    this.pdf.setLineWidth(0.3);
    this.pdf.line(this.margin, this.y, this.pageWidth - this.margin, this.y);
    this.y += 10;
  }

  /**
   * Add overall scores section
   */
  private addScores(): void {
    const { auditResults } = this.auditData;
    
    this.addSectionTitle('Overall Performance');
    
    // Main scores in boxes
    const boxWidth = 40;
    const boxHeight = 25;
    const startX = this.margin;
    
    // Overall Score Box
    this.pdf.setFillColor(99, 102, 241);
    this.pdf.roundedRect(startX, this.y, boxWidth, boxHeight, 3, 3, 'F');
    this.pdf.setTextColor(255, 255, 255);
    this.pdf.setFontSize(18);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text(String(auditResults.overallScore), startX + 12, this.y + 12);
    this.pdf.setFontSize(8);
    this.pdf.text('Score', startX + 14, this.y + 20);
    
    // Grade Box
    this.pdf.setFillColor(139, 92, 246);
    this.pdf.roundedRect(startX + boxWidth + 5, this.y, boxWidth, boxHeight, 3, 3, 'F');
    this.pdf.setFontSize(16);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text(auditResults.letterGrade, startX + boxWidth + 17, this.y + 12);
    this.pdf.setFontSize(8);
    this.pdf.text('Grade', startX + boxWidth + 17, this.y + 20);
    
    this.y += boxHeight + 10;
    
    // Platform scores
    this.pdf.setTextColor(60, 60, 60);
    this.addKeyValue('ChatGPT', `${auditResults.platformScores.chatgpt}/100`);
    this.addKeyValue('Perplexity', `${auditResults.platformScores.perplexity}/100`);
    this.addKeyValue('Gemini', `${auditResults.platformScores.gemini}/100`);
    this.addKeyValue('Claude', `${auditResults.platformScores.claude}/100`);
    
    this.y += 5;
  }

  /**
   * Add findings section
   */
  private addFindings(): void {
    const { auditResults } = this.auditData;
    
    this.addSectionTitle('Key Findings');
    
    // Strengths
    this.pdf.setFontSize(11);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.setTextColor(16, 185, 129); // Green
    this.pdf.text('Strengths', this.margin, this.y);
    this.y += 6;
    
    for (const strength of auditResults.strengths) {
      this.addBulletPoint(strength, [16, 185, 129]);
    }
    this.y += 4;
    
    // Weaknesses
    this.pdf.setFontSize(11);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.setTextColor(245, 158, 11); // Amber
    this.pdf.text('Areas for Improvement', this.margin, this.y);
    this.y += 6;
    
    for (const weakness of auditResults.weaknesses) {
      this.addBulletPoint(weakness, [245, 158, 11]);
    }
    this.y += 4;
    
    // Technical Findings
    this.pdf.setFontSize(11);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.setTextColor(60, 60, 60);
    this.pdf.text('Technical Analysis', this.margin, this.y);
    this.y += 6;
    
    this.addKeyValue('Domain Authority', auditResults.technicalFindings.domainAuthority);
    this.addKeyValue('Content Structure', auditResults.technicalFindings.contentStructure);
    this.addKeyValue('Schema Markup', auditResults.technicalFindings.schemaMarkup);
    this.addKeyValue('Entity Recognition', auditResults.technicalFindings.entityRecognition);
  }

  /**
   * Add company intelligence section
   */
  private addCompanyIntelligence(): void {
    if (!this.auditData.companyIntelligence) return;
    
    const ci = this.auditData.companyIntelligence;
    
    this.addSectionTitle('Company Intelligence');
    
    this.addKeyValue('Industry', ci.industry);
    this.addKeyValue('Business Type', ci.businessType);
    this.addKeyValue('Target Audience', ci.targetAudience);
    this.addKeyValue('Market Position', ci.marketPosition);
    
    if (ci.valueProposition) {
      this.y += 2;
      this.pdf.setFontSize(10);
      this.pdf.setFont('helvetica', 'bold');
      this.pdf.setTextColor(100, 100, 100);
      this.pdf.text('Value Proposition:', this.margin, this.y);
      this.y += 5;
      this.addText(ci.valueProposition);
    }
  }

  /**
   * Add content topics section
   */
  private addTopics(): void {
    const categories = [
      { key: 'authoritative' as const, label: 'Authoritative Topics (85-95%)', color: [99, 102, 241] },
      { key: 'thoughtLeadership' as const, label: 'Thought Leadership (70-84%)', color: [139, 92, 246] },
      { key: 'competitiveAdvantage' as const, label: 'Competitive Advantage (50-69%)', color: [59, 130, 246] },
      { key: 'emergingOpportunity' as const, label: 'Emerging Opportunities (30-49%)', color: [16, 185, 129] }
    ];

    // Count total topics
    const totalTopics = categories.reduce((sum, cat) => {
      return sum + this.auditData.contentTopics[cat.key].length;
    }, 0);

    this.addSectionTitle(`Content Opportunities (${totalTopics} Topics)`);

    for (const category of categories) {
      const topics = this.auditData.contentTopics[category.key];
      if (topics.length === 0) continue;
      
      this.checkPageBreak(20);
      
      // Category header
      this.pdf.setFillColor(category.color[0], category.color[1], category.color[2]);
      this.pdf.roundedRect(this.margin, this.y, this.contentWidth, 8, 2, 2, 'F');
      this.pdf.setTextColor(255, 255, 255);
      this.pdf.setFontSize(10);
      this.pdf.setFont('helvetica', 'bold');
      this.pdf.text(`${category.label} - ${topics.length} Topics`, this.margin + 3, this.y + 5.5);
      this.y += 12;

      // Topics
      for (let i = 0; i < topics.length; i++) {
        const topic = topics[i];
        this.checkPageBreak(25);
        
        // Topic number and title
        this.pdf.setFontSize(10);
        this.pdf.setFont('helvetica', 'bold');
        this.pdf.setTextColor(30, 30, 30);
        
        const titleText = `${i + 1}. ${topic.topic}`;
        const titleLines = this.pdf.splitTextToSize(titleText, this.contentWidth - 20);
        for (const line of titleLines) {
          this.pdf.text(line, this.margin + 2, this.y);
          this.y += 4.5;
        }
        
        // Confidence
        this.pdf.setFontSize(9);
        this.pdf.setTextColor(16, 185, 129);
        this.pdf.text(`${topic.confidence}%`, this.pageWidth - this.margin - 10, this.y - 4.5);
        
        // Justification
        if (topic.justification) {
          this.pdf.setFontSize(8);
          this.pdf.setFont('helvetica', 'italic');
          this.pdf.setTextColor(100, 100, 100);
          const justLines = this.pdf.splitTextToSize(topic.justification, this.contentWidth - 5);
          for (const line of justLines.slice(0, 2)) { // Max 2 lines
            this.pdf.text(line, this.margin + 2, this.y);
            this.y += 3.5;
          }
        }
        
        // Platforms
        if (topic.platforms && topic.platforms.length > 0) {
          this.pdf.setFontSize(7);
          this.pdf.setFont('helvetica', 'normal');
          this.pdf.setTextColor(99, 102, 241);
          this.pdf.text(`Platforms: ${topic.platforms.join(', ')}`, this.margin + 2, this.y);
          this.y += 4;
        }
        
        this.y += 3;
      }
      
      this.y += 5;
    }
  }

  /**
   * Add recommendations section
   */
  private addRecommendations(): void {
    if (!this.auditData.recommendations || this.auditData.recommendations.length === 0) return;
    
    this.addSectionTitle('Recommendations');
    
    for (let i = 0; i < this.auditData.recommendations.length; i++) {
      const rec = this.auditData.recommendations[i];
      this.checkPageBreak(15);
      
      // Number circle
      this.pdf.setFillColor(16, 185, 129);
      this.pdf.circle(this.margin + 3, this.y - 1, 3, 'F');
      this.pdf.setTextColor(255, 255, 255);
      this.pdf.setFontSize(7);
      this.pdf.setFont('helvetica', 'bold');
      this.pdf.text(String(i + 1), this.margin + 1.8, this.y);
      
      // Recommendation text
      this.pdf.setTextColor(30, 30, 30);
      this.pdf.setFontSize(9);
      this.pdf.setFont('helvetica', 'normal');
      
      const lines = this.pdf.splitTextToSize(rec, this.contentWidth - 12);
      for (let j = 0; j < lines.length; j++) {
        if (j > 0) this.checkPageBreak(5);
        this.pdf.text(lines[j], this.margin + 10, this.y);
        this.y += 4;
      }
      this.y += 3;
    }
  }

  /**
   * Add footer
   */
  private addFooter(): void {
    this.checkPageBreak(20);
    this.y += 10;
    
    // Separator
    this.pdf.setDrawColor(200, 200, 200);
    this.pdf.setLineWidth(0.3);
    this.pdf.line(this.margin, this.y, this.pageWidth - this.margin, this.y);
    this.y += 8;
    
    this.pdf.setFontSize(8);
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.setTextColor(130, 130, 130);
    this.pdf.text('Generated by AI Citation Audit', this.pageWidth / 2, this.y, { align: 'center' });
    this.y += 4;
    this.pdf.text(`© ${new Date().getFullYear()} AI Citation Audit. All rights reserved.`, this.pageWidth / 2, this.y, { align: 'center' });
  }

  /**
   * Generate the complete PDF
   */
  private generate(): void {
    this.addHeader();
    this.addScores();
    this.addFindings();
    this.addCompanyIntelligence();
    this.addTopics();
    this.addRecommendations();
    this.addFooter();
  }

  /**
   * Get filename for the PDF
   */
  public getFileName(): string {
    return `AI-Citation-Audit-${this.domain}-${new Date().toISOString().split('T')[0]}.pdf`;
  }

  /**
   * Download the PDF
   */
  public downloadPDF(): void {
    console.log('📄 Generating PDF...');
    this.generate();
    this.pdf.save(this.getFileName());
    console.log('✅ PDF downloaded successfully');
  }

  /**
   * Share the PDF (with fallbacks)
   */
  public async sharePDF(): Promise<void> {
    console.log('📄 Generating PDF for sharing...');
    this.generate();
    
    const blob = this.pdf.output('blob');
    const fileName = this.getFileName();
    const file = new File([blob], fileName, { type: 'application/pdf' });
    
    console.log(`📊 PDF generated: ${(blob.size / 1024).toFixed(1)}KB`);
    
    // 1. Try Native Share API (mobile & supported desktop)
    if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          title: `AI Citation Audit - ${this.domain}`,
          text: `Overall Score: ${this.auditData.auditResults.overallScore}/100`,
          files: [file]
        });
        console.log('✅ PDF shared via native share');
        return;
      } catch (error: any) {
        if (error.name === 'AbortError') {
          throw error; // User cancelled
        }
        console.warn('Native share failed, trying fallback:', error);
      }
    }

    // 2. Fallback: Open in new tab
    const url = URL.createObjectURL(blob);
    const newTab = window.open(url, '_blank');
    
    if (newTab) {
      console.log('📄 PDF opened in new tab');
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      throw new Error('OPENED_IN_TAB');
    }

    // 3. Last resort: Download
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    console.log('📄 PDF downloaded as fallback');
    throw new Error('FALLBACK_DOWNLOAD');
  }
}

