import type { AuditData } from "@shared/schema";

interface CSVExporterOptions {
  auditData: AuditData;
  websiteUrl: string;
  generatedAt: string;
}

export class CSVExporter {
  private auditData: AuditData;
  private websiteUrl: string;
  private generatedAt: string;
  private domain: string;

  constructor(options: CSVExporterOptions) {
    this.auditData = options.auditData;
    this.websiteUrl = options.websiteUrl;
    this.generatedAt = options.generatedAt;
    this.domain = new URL(options.websiteUrl).hostname.replace('www.', '');
  }

  private escapeCSV(value: string): string {
    if (value.includes(',') || value.includes('"') || value.includes('\n')) {
      return `"${value.replace(/"/g, '""')}"`;
    }
    return value;
  }

  private generateOverviewCSV(): string {
    const { auditResults } = this.auditData;
    const rows = [
      ['AI Citation Audit Report'],
      ['Website', this.domain],
      ['URL', this.websiteUrl],
      ['Generated', new Date(this.generatedAt).toLocaleString()],
      [''],
      ['OVERALL PERFORMANCE'],
      ['Overall Score', auditResults.overallScore.toString()],
      ['Letter Grade', auditResults.letterGrade],
      [''],
      ['PLATFORM SCORES'],
      ['ChatGPT', auditResults.platformScores.chatgpt.toString()],
      ['Perplexity', auditResults.platformScores.perplexity.toString()],
      ['Gemini', auditResults.platformScores.gemini.toString()],
      ['Claude', auditResults.platformScores.claude.toString()],
      [''],
      ['TECHNICAL FINDINGS'],
      ['Domain Authority', auditResults.technicalFindings.domainAuthority],
      ['Content Structure', auditResults.technicalFindings.contentStructure],
      ['Schema Markup', auditResults.technicalFindings.schemaMarkup],
      ['Entity Recognition', auditResults.technicalFindings.entityRecognition]
    ];

    return rows.map(row => row.map(cell => this.escapeCSV(cell)).join(',')).join('\n');
  }

  private generateStrengthsWeaknessesCSV(): string {
    const { auditResults } = this.auditData;
    const rows = [
      ['Type', 'Finding'],
      ...auditResults.strengths.map(strength => ['Strength', strength]),
      ...auditResults.weaknesses.map(weakness => ['Weakness', weakness])
    ];

    return rows.map(row => row.map(cell => this.escapeCSV(cell)).join(',')).join('\n');
  }

  private generateCompanyIntelligenceCSV(): string {
    if (!this.auditData.companyIntelligence) return '';

    const { companyIntelligence } = this.auditData;
    const rows = [
      ['Field', 'Value'],
      ['Industry', companyIntelligence.industry],
      ['Business Type', companyIntelligence.businessType],
      ['Target Audience', companyIntelligence.targetAudience],
      ['Value Proposition', companyIntelligence.valueProposition],
      ['Market Position', companyIntelligence.marketPosition]
    ];

    if (companyIntelligence.businessModel) {
      rows.push(['Business Model', companyIntelligence.businessModel]);
    }

    if (companyIntelligence.geographicFocus) {
      rows.push(['Geographic Focus', companyIntelligence.geographicFocus.join('; ')]);
    }

    if (companyIntelligence.serviceOfferings) {
      rows.push(['Service Offerings', companyIntelligence.serviceOfferings.join('; ')]);
    }

    return rows.map(row => row.map(cell => this.escapeCSV(cell)).join(',')).join('\n');
  }

  private generateCompetitorAnalysisCSV(): string {
    if (!this.auditData.competitorAnalysis) return '';

    const { competitorAnalysis } = this.auditData;
    const rows = [
      ['Analysis Type', 'Details'],
      ['Main Competitors', competitorAnalysis.mainCompetitors.join('; ')],
      ...competitorAnalysis.competitorStrengths.map(strength => ['Competitor Strength', strength]),
      ...competitorAnalysis.competitorWeaknesses.map(weakness => ['Competitor Weakness', weakness]),
      ...competitorAnalysis.marketOpportunities.map(opportunity => ['Market Opportunity', opportunity])
    ];

    if (competitorAnalysis.competitiveAdvantages) {
      rows.push(...competitorAnalysis.competitiveAdvantages.map(advantage => ['Competitive Advantage', advantage]));
    }

    return rows.map(row => row.map(cell => this.escapeCSV(cell)).join(',')).join('\n');
  }

  private generateTopicsCSV(): string {
    const categories = [
      { key: 'authoritative', label: 'Authoritative' },
      { key: 'thoughtLeadership', label: 'Thought Leadership' },
      { key: 'competitiveAdvantage', label: 'Competitive Advantage' },
      { key: 'emergingOpportunity', label: 'Emerging Opportunity' }
    ];

    const headers = [
      'Category',
      'Topic',
      'Confidence',
      'Justification',
      'Platforms',
      'Search Volume',
      'Competition Level',
      'Competitor Gap'
    ];

    const rows = [headers];

    categories.forEach(category => {
      const topics = this.auditData.contentTopics[category.key as keyof typeof this.auditData.contentTopics];
      topics.forEach(topic => {
        rows.push([
          category.label,
          topic.topic,
          topic.confidence.toString(),
          topic.justification,
          topic.platforms.join('; '),
          topic.searchVolume || 'N/A',
          topic.competitionLevel || 'N/A',
          topic.competitorGap || 'N/A'
        ]);
      });
    });

    return rows.map(row => row.map(cell => this.escapeCSV(cell)).join(',')).join('\n');
  }

  private generateCitationIntelligenceCSV(): string {
    if (!this.auditData.citationIntelligence) return '';

    const { citationIntelligence } = this.auditData;
    const rows = [
      ['Metric', 'Value'],
      ['Total Citations', citationIntelligence.currentCitationPresence.totalCitations.toString()],
      ['ChatGPT Citations', citationIntelligence.currentCitationPresence.platformBreakdown.chatgpt.toString()],
      ['Perplexity Citations', citationIntelligence.currentCitationPresence.platformBreakdown.perplexity.toString()],
      ['Gemini Citations', citationIntelligence.currentCitationPresence.platformBreakdown.gemini.toString()],
      ['Claude Citations', citationIntelligence.currentCitationPresence.platformBreakdown.claude.toString()],
      [''],
      ['Top Cited Content', ''],
      ...citationIntelligence.currentCitationPresence.topCitedContent.map(content => ['', content]),
      [''],
      ['Competitor Citations', ''],
      ...Object.entries(citationIntelligence.competitorCitationAnalysis.competitorCitations)
        .map(([competitor, citations]) => [competitor, citations.toString()]),
      [''],
      ['Citation Gaps', ''],
      ...citationIntelligence.competitorCitationAnalysis.citationGaps.map(gap => ['', gap]),
      [''],
      ['Citation Opportunities', ''],
      ...citationIntelligence.citationOpportunities.map(opportunity => ['', opportunity])
    ];

    return rows.map(row => row.map(cell => this.escapeCSV(cell)).join(',')).join('\n');
  }

  private generateRecommendationsCSV(): string {
    const rows = [
      ['Priority', 'Recommendation'],
      ...this.auditData.recommendations.map((recommendation, index) => [
        (index + 1).toString(),
        recommendation
      ])
    ];

    return rows.map(row => row.map(cell => this.escapeCSV(cell)).join(',')).join('\n');
  }

  public generateFullCSV(): string {
    const sections = [
      this.generateOverviewCSV(),
      '',
      'STRENGTHS & WEAKNESSES',
      this.generateStrengthsWeaknessesCSV(),
      ''
    ];

    if (this.auditData.companyIntelligence) {
      sections.push(
        'COMPANY INTELLIGENCE',
        this.generateCompanyIntelligenceCSV(),
        ''
      );
    }

    if (this.auditData.competitorAnalysis) {
      sections.push(
        'COMPETITOR ANALYSIS',
        this.generateCompetitorAnalysisCSV(),
        ''
      );
    }

    sections.push(
      'CONTENT TOPICS',
      this.generateTopicsCSV(),
      ''
    );

    if (this.auditData.citationIntelligence) {
      sections.push(
        'CITATION INTELLIGENCE',
        this.generateCitationIntelligenceCSV(),
        ''
      );
    }

    sections.push(
      'RECOMMENDATIONS',
      this.generateRecommendationsCSV()
    );

    return sections.join('\n');
  }

  public generateTopicsOnlyCSV(): string {
    return this.generateTopicsCSV();
  }

  public downloadCSV(filename: string, csvContent: string): void {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  }
}

