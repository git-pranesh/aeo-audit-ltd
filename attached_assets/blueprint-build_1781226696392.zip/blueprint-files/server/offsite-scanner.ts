/**
 * Off-Site Authority Scanner — Module 4 (0–30 points)
 *
 * Brand mentions on third-party sites: r=0.664 with AI citation probability.
 * Brands are 6.5x more likely to be cited through third-party sources than own site.
 *
 * Three tiers:
 *   Entity Foundation (0–10): KG, Wikidata, Wikipedia, Crunchbase, LinkedIn
 *   Review Platforms  (0–10): G2, Capterra, Trustpilot
 *   Community         (0–10): Reddit presence (via community-scanner.ts)
 *
 * APIs: All free.
 *   Google KG: 100K req/day free
 *   Wikidata:  completely free
 *   Wikipedia: completely free
 *   Others:    URL existence checks only (no API needed)
 */

import type { OffsiteSignals } from './blueprint-signals';
import { scanRedditPresence } from './community-scanner';

export async function scanOffsitePresence(
  brandName: string,
  domain: string,
  industry: string,
  companyName: string
): Promise<OffsiteSignals> {
  // Run all checks in parallel (with individual timeouts)
  const [entityResults, reviewResults, redditResults] = await Promise.allSettled([
    checkEntityFoundation(brandName, domain, companyName),
    checkReviewPlatforms(brandName, domain),
    scanRedditPresence(brandName, domain, industry),
  ]);

  const entity = entityResults.status === 'fulfilled' ? entityResults.value : defaultEntityResult();
  const reviews = reviewResults.status === 'fulfilled' ? reviewResults.value : defaultReviewResult();
  const reddit = redditResults.status === 'fulfilled' ? redditResults.value : defaultRedditResult();

  const offsiteScore = Math.min(30,
    entity.entityFoundationScore +
    reviews.reviewPlatformScore +
    reddit.communityScore
  );

  return {
    // Entity
    knowledgeGraphEntityType: entity.entityType,
    wikidataQNumber: entity.wikidataQNumber,
    wikipediaArticleExists: entity.wikipediaExists,
    crunchbaseProfileExists: entity.crunchbaseExists,
    linkedinCompanyPageExists: entity.linkedinExists,
    entityFoundationScore: entity.entityFoundationScore,

    // Reviews
    g2ProfileExists: reviews.g2Exists,
    g2ReviewCount: reviews.g2ReviewCount,
    capteRraProfileExists: reviews.capteRraExists,
    trustpilotProfileExists: reviews.trustpilotExists,
    reviewPlatformScore: reviews.reviewPlatformScore,

    // Community
    redditBrandMentionCount: reddit.brandMentionCount,
    redditRelevantSubreddits: reddit.relevantSubredditsForCategory,
    redditBrandPresentInSubreddits: reddit.brandPresentInSubreddits,
    communityScore: reddit.communityScore,

    offsiteScore,
  };
}

// ─── Entity Foundation ────────────────────────────────────────────────────────

async function checkEntityFoundation(brandName: string, domain: string, companyName: string) {
  const [kgResult, wikidataResult, wikipediaResult, crunchbaseResult, linkedinResult] =
    await Promise.allSettled([
      checkGoogleKnowledgeGraph(brandName),
      checkWikidata(brandName),
      checkWikipedia(brandName),
      checkUrlExists(`https://www.crunchbase.com/organization/${slugify(brandName)}`),
      checkUrlExists(`https://www.linkedin.com/company/${slugify(brandName)}`),
    ]);

  const kg = kgResult.status === 'fulfilled' ? kgResult.value : null;
  const wikidata = wikidataResult.status === 'fulfilled' ? wikidataResult.value : null;
  const wikipediaExists = wikipediaResult.status === 'fulfilled' ? wikipediaResult.value : false;
  const crunchbaseExists = crunchbaseResult.status === 'fulfilled' ? crunchbaseResult.value : false;
  const linkedinExists = linkedinResult.status === 'fulfilled' ? linkedinResult.value : false;

  let entityFoundationScore = 0;
  if (kg?.found) entityFoundationScore += 4;
  if (wikidata?.found) entityFoundationScore += 3;
  if (wikipediaExists) entityFoundationScore += 2;
  if (crunchbaseExists) entityFoundationScore += 1;
  // LinkedIn existence is common, don't score it separately

  return {
    entityType: kg?.entityType ?? null,
    wikidataQNumber: wikidata?.qNumber ?? null,
    wikipediaExists,
    crunchbaseExists,
    linkedinExists,
    entityFoundationScore: Math.min(10, entityFoundationScore),
  };
}

async function checkGoogleKnowledgeGraph(brandName: string) {
  const apiKey = process.env.GOOGLE_KG_API_KEY;
  if (!apiKey) return { found: false, entityType: null };

  try {
    const url = `https://kgsearch.googleapis.com/v1/entities:search?query=${encodeURIComponent(brandName)}&key=${apiKey}&limit=3`;
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) return { found: false, entityType: null };

    const data = await res.json() as any;
    const items = data?.itemListElement ?? [];
    if (items.length === 0) return { found: false, entityType: null };

    const entityType = items[0]?.result?.['@type']?.[0] ?? 'Organization';
    return { found: true, entityType };
  } catch {
    return { found: false, entityType: null };
  }
}

async function checkWikidata(brandName: string) {
  try {
    const url = `https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${encodeURIComponent(brandName)}&language=en&limit=3&format=json&origin=*`;
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) return { found: false, qNumber: null };

    const data = await res.json() as any;
    const results = data?.search ?? [];
    if (results.length === 0) return { found: false, qNumber: null };

    return { found: true, qNumber: results[0]?.id ?? null };
  } catch {
    return { found: false, qNumber: null };
  }
}

async function checkWikipedia(brandName: string): Promise<boolean> {
  try {
    const url = `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(brandName)}&limit=3&format=json&origin=*`;
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) return false;

    const data = await res.json() as any;
    const titles = data?.[1] ?? [];
    return titles.some((t: string) =>
      t.toLowerCase().includes(brandName.toLowerCase().split(' ')[0])
    );
  } catch {
    return false;
  }
}

// ─── Review Platforms ─────────────────────────────────────────────────────────

async function checkReviewPlatforms(brandName: string, domain: string) {
  const slug = slugify(brandName);
  const domainSlug = domain.split('.')[0];

  const [g2Result, capteRraResult, trustpilotResult] = await Promise.allSettled([
    checkG2Profile(slug, domainSlug),
    checkUrlExists(`https://www.capterra.com/p/search/?q=${encodeURIComponent(brandName)}`),
    checkUrlExists(`https://www.trustpilot.com/review/${domain}`),
  ]);

  const g2 = g2Result.status === 'fulfilled' ? g2Result.value : { exists: false, reviewCount: null };
  const capteRraExists = capteRraResult.status === 'fulfilled' ? capteRraResult.value : false;
  const trustpilotExists = trustpilotResult.status === 'fulfilled' ? trustpilotResult.value : false;

  // Blueprint: 4.6–6.3 citations for sites on multiple review platforms vs 1.8 for absent
  let reviewPlatformScore = 0;
  if (g2.exists) reviewPlatformScore += 4;
  if (capteRraExists) reviewPlatformScore += 3;
  if (trustpilotExists) reviewPlatformScore += 3;

  return {
    g2Exists: g2.exists,
    g2ReviewCount: g2.reviewCount,
    capteRraExists,
    trustpilotExists,
    reviewPlatformScore: Math.min(10, reviewPlatformScore),
  };
}

async function checkG2Profile(slug: string, domainSlug: string): Promise<{ exists: boolean; reviewCount: number | null }> {
  try {
    // Try common G2 URL patterns
    const urls = [
      `https://www.g2.com/products/${slug}/reviews`,
      `https://www.g2.com/products/${domainSlug}/reviews`,
    ];

    for (const url of urls) {
      const exists = await checkUrlExists(url);
      if (exists) return { exists: true, reviewCount: null }; // count requires scraping
    }

    return { exists: false, reviewCount: null };
  } catch {
    return { exists: false, reviewCount: null };
  }
}

// ─── Utilities ────────────────────────────────────────────────────────────────

async function checkUrlExists(url: string): Promise<boolean> {
  try {
    const res = await fetch(url, {
      method: 'GET',
      signal: AbortSignal.timeout(6000),
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; CitationRocketBot/1.0)' },
      redirect: 'follow',
    });
    return res.ok && res.status < 400;
  } catch {
    return false;
  }
}

function slugify(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

// ─── Default values ───────────────────────────────────────────────────────────

function defaultEntityResult() {
  return { entityType: null, wikidataQNumber: null, wikipediaExists: false, crunchbaseExists: false, linkedinExists: false, entityFoundationScore: 0 };
}

function defaultReviewResult() {
  return { g2Exists: false, g2ReviewCount: null, capteRraExists: false, trustpilotExists: false, reviewPlatformScore: 0 };
}

function defaultRedditResult() {
  return { brandMentionCount: 0, relevantSubredditsForCategory: [], brandPresentInSubreddits: [], communityScore: 0 };
}
