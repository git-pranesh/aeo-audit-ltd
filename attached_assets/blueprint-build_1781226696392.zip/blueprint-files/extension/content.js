/**
 * Citation Rocket — Chrome Extension Content Script
 * 
 * Runs Phase 1 blueprint modules client-side:
 *   - Answer Capsule detection (Module 1)
 *   - AI Bot Access check (Module 3) — robots.txt fetch
 *   - Schema Completeness (Module 6) — JSON-LD parse
 *   - Content Freshness (Module 5) — dateModified check
 *   - Fan-Out Coverage (Module 7) — heading structure
 *
 * Zero backend calls. Zero API cost. Works on any page instantly.
 * Shows overlay with quick AEO score + "Run Full Audit" button.
 */

(function() {
  'use strict';

  // Only inject once
  if (document.getElementById('cr-aeo-overlay')) return;

  const domain = window.location.hostname.replace(/^www\./, '');
  const pageUrl = window.location.href;

  async function runQuickAudit() {
    const html = document.documentElement.outerHTML;
    const text = document.body.innerText || '';

    const [answerScore, schemaScore, freshnessScore, fanOutScore, botScore] = await Promise.all([
      scoreAnswerCapsule(html, text),
      scoreSchemaCompleteness(html),
      scoreFreshness(html),
      scoreFanOut(html),
      scoreBotAccess(domain),
    ]);

    const maxPoints = 25 + 20 + 15 + 10 + 10; // = 80
    const rawScore = answerScore.score + schemaScore.score + freshnessScore.score + fanOutScore.score + botScore.score;
    const normalizedScore = Math.round((rawScore / maxPoints) * 100);

    const grade = normalizedScore >= 80 ? 'A' : normalizedScore >= 65 ? 'B' :
                  normalizedScore >= 50 ? 'C' : normalizedScore >= 35 ? 'D' : 'F';

    return {
      score: normalizedScore,
      grade,
      modules: { answerScore, schemaScore, freshnessScore, fanOutScore, botScore },
      criticalIssues: getCriticalIssues(botScore, schemaScore, answerScore),
    };
  }

  // ─── Module 1: Answer Capsule ─────────────────────────────────────────────

  function scoreAnswerCapsule(html, text) {
    const first150 = text.split(/\s+/).slice(0, 150).join(' ');
    const h1 = document.querySelector('h1');
    const h1Text = h1 ? h1.textContent.trim() : '';
    const questionStarters = /^(how|what|why|when|which|who|where)\b/i;

    const h1IsDeclarative = h1Text && !questionStarters.test(h1Text);
    const hasDefinitionFirst = /^[A-Z][^.]{3,60} (is a|is an|is the|refers to|means )/i.test(first150.trim());
    const hasDataPoint = /\b\d+(\.\d+)?(%|percent|million|billion|x|×)\b|\bstudy (found|shows)\b/i.test(first150);
    const questionHeadings = document.querySelectorAll('h2, h3');
    const questionHeadingCount = Array.from(questionHeadings).filter(h =>
      questionStarters.test(h.textContent.trim())
    ).length;

    let score = 0;
    if (h1IsDeclarative) score += 3;
    if (hasDefinitionFirst) score += 6;
    if (hasDataPoint) score += 5;
    score += Math.min(6, questionHeadingCount * 2);

    return {
      score: Math.min(25, score),
      max: 25,
      label: 'Answer Capsule',
      issues: [
        !h1IsDeclarative && 'H1 is a question (use declarative format instead)',
        !hasDefinitionFirst && 'Opening paragraph lacks definition-first structure',
        !hasDataPoint && 'No data points in opening 3 sentences',
      ].filter(Boolean),
    };
  }

  // ─── Module 6: Schema ─────────────────────────────────────────────────────

  function scoreSchemaCompleteness(html) {
    const jsonLdScripts = document.querySelectorAll('script[type="application/ld+json"]');
    const schemas = [];
    jsonLdScripts.forEach(s => {
      try { schemas.push(...[JSON.parse(s.textContent)].flat()); } catch {}
    });

    const hasOrg = schemas.some(s => ['Organization', 'Corporation', 'LocalBusiness'].includes(s['@type']));
    const hasArticle = schemas.some(s => ['Article', 'BlogPosting'].includes(s['@type']));
    const hasFaq = schemas.some(s => s['@type'] === 'FAQPage');
    const hasBreadcrumb = schemas.some(s => s['@type'] === 'BreadcrumbList');
    const hasHowTo = schemas.some(s => s['@type'] === 'HowTo');

    const orgSchema = schemas.find(s => ['Organization', 'Corporation', 'LocalBusiness'].includes(s['@type']));
    const orgHasSameAs = Array.isArray(orgSchema?.sameAs) && orgSchema.sameAs.length > 0;

    let score = 0;
    if (hasOrg) score += 5;
    if (orgHasSameAs) score += 2;
    if (hasArticle) score += 4;
    if (hasFaq) score += 4;
    if (hasBreadcrumb) score += 3;
    if (hasHowTo) score += 2;

    return {
      score: Math.min(20, score),
      max: 20,
      label: 'Schema',
      detected: { hasOrg, hasArticle, hasFaq, hasBreadcrumb, hasHowTo },
      issues: [
        !hasOrg && 'Missing Organization schema',
        !orgHasSameAs && hasOrg && 'Organization schema missing sameAs links',
        !hasFaq && 'Missing FAQPage schema',
        !hasArticle && 'Missing Article schema on content pages',
      ].filter(Boolean),
    };
  }

  // ─── Module 5: Freshness ──────────────────────────────────────────────────

  function scoreFreshness(html) {
    const dateModifiedMatch = html.match(/"dateModified"\s*:\s*"(\d{4}-\d{2}-\d{2})/) ||
                              html.match(/property="article:modified_time"\s+content="(\d{4}-\d{2}-\d{2})/);
    let daysSince = null;
    if (dateModifiedMatch) {
      daysSince = Math.floor((Date.now() - new Date(dateModifiedMatch[1]).getTime()) / 86400000);
    }

    const hasVisibleUpdated = /\b(last updated|updated on)\s*:?\s*/i.test(document.body.innerText);
    const hasLlmsTxt = false; // checked separately via fetch (async)

    let score = 0;
    if (daysSince !== null) {
      if (daysSince <= 30) score += 7;
      else if (daysSince <= 90) score += 5;
      else if (daysSince <= 180) score += 3;
      else score += 1;
    }
    if (hasVisibleUpdated) score += 4;

    return {
      score: Math.min(15, score),
      max: 15,
      label: 'Freshness',
      daysSince,
      issues: [
        !dateModifiedMatch && 'No dateModified in schema markup',
        !hasVisibleUpdated && 'No visible "Last Updated" annotation',
        daysSince > 180 && `Content is ${daysSince} days old — refresh recommended`,
      ].filter(Boolean),
    };
  }

  // ─── Module 7: Fan-Out ────────────────────────────────────────────────────

  function scoreFanOut(html) {
    const h1 = document.querySelector('h1');
    const h1Text = h1 ? h1.textContent.trim() : '';
    const questionStarters = /^(how|what|why|when|which|who|where)\b/i;
    const h1IsQuestion = questionStarters.test(h1Text);

    const headings = document.querySelectorAll('h2, h3');
    let answerBlockCount = 0;
    headings.forEach(h => {
      const next = h.nextElementSibling;
      if (next && next.tagName === 'P') {
        const words = next.textContent.trim().split(/\s+/).length;
        if (words >= 40 && words <= 150) answerBlockCount++;
      }
    });

    let score = 0;
    if (!h1IsQuestion) score += 3;
    score += Math.min(7, answerBlockCount * 2);

    return {
      score: Math.min(10, score),
      max: 10,
      label: 'Fan-Out',
      headingCount: headings.length,
      answerBlockCount,
      issues: [
        h1IsQuestion && 'H1 is a question (declarative H1 gets 26% more citations)',
        answerBlockCount === 0 && 'No answer blocks detected under headings',
      ].filter(Boolean),
    };
  }

  // ─── Module 3: Bot Access (async robots.txt fetch) ────────────────────────

  async function scoreBotAccess(domain) {
    const CITATION_BOTS = ['OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'PerplexityBot', 'anthropic-ai'];
    let robotsTxt = '';
    let llmsTxtExists = false;

    try {
      const [robotsRes, llmsRes] = await Promise.allSettled([
        fetch(`https://${domain}/robots.txt`),
        fetch(`https://${domain}/llms.txt`, { method: 'HEAD' }),
      ]);

      if (robotsRes.status === 'fulfilled' && robotsRes.value.ok) {
        robotsTxt = await robotsRes.value.text();
      }
      llmsTxtExists = llmsRes.status === 'fulfilled' && llmsRes.value.ok;
    } catch {}

    const blocked = CITATION_BOTS.filter(bot => {
      const lines = robotsTxt.split('\n');
      let inBotBlock = false;
      for (const line of lines) {
        if (line.startsWith('User-agent:')) {
          inBotBlock = line.toLowerCase().includes(bot.toLowerCase()) || line.includes('*');
        }
        if (inBotBlock && line.startsWith('Disallow: /') && !line.includes('/specific')) {
          return true;
        }
      }
      return false;
    });

    let score = 0;
    if (blocked.length === 0) score += 5;
    else score += Math.max(0, 5 - blocked.length * 2);
    if (llmsTxtExists) score += 3;
    if (/Sitemap:/i.test(robotsTxt)) score += 2;

    return {
      score: Math.min(10, score),
      max: 10,
      label: 'Bot Access',
      citationBotsBlocked: blocked,
      llmsTxtExists,
      issues: [
        blocked.length > 0 && `Citation bots blocked: ${blocked.join(', ')}`,
        !llmsTxtExists && 'No llms.txt found',
      ].filter(Boolean),
    };
  }

  function getCriticalIssues(botScore, schemaScore, answerScore) {
    const issues = [];
    if (botScore.citationBotsBlocked?.length > 0) {
      issues.push({ severity: 'critical', text: `AI citation bots blocked: ${botScore.citationBotsBlocked.join(', ')}` });
    }
    if (!schemaScore.detected?.hasOrg) {
      issues.push({ severity: 'high', text: 'Missing Organization schema markup' });
    }
    if (!answerScore.issues?.includes(false) && answerScore.score < 8) {
      issues.push({ severity: 'high', text: 'Opening content not structured as answer capsule' });
    }
    return issues;
  }

  // ─── UI Overlay ───────────────────────────────────────────────────────────

  function buildOverlay(audit) {
    const { score, grade, modules, criticalIssues } = audit;
    const color = score >= 70 ? '#22c55e' : score >= 50 ? '#f59e0b' : '#ef4444';
    const fullAuditUrl = `https://citationrocket.com/?url=${encodeURIComponent(pageUrl)}`;

    const overlay = document.createElement('div');
    overlay.id = 'cr-aeo-overlay';
    overlay.style.cssText = `
      position: fixed; bottom: 20px; right: 20px; z-index: 999999;
      background: #1a1a2e; color: #fff; border-radius: 12px;
      padding: 16px; width: 280px; font-family: -apple-system, sans-serif;
      box-shadow: 0 4px 24px rgba(0,0,0,0.4); font-size: 13px;
      border: 1px solid rgba(255,255,255,0.1);
    `;

    overlay.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <div style="font-weight:700; font-size:14px;">🚀 Citation Rocket</div>
        <button id="cr-close" style="background:none;border:none;color:#999;cursor:pointer;font-size:18px;">×</button>
      </div>
      <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
        <div style="font-size:36px; font-weight:800; color:${color}; line-height:1;">${score}</div>
        <div>
          <div style="font-size:11px; color:#999;">Quick AEO Score</div>
          <div style="font-size:22px; font-weight:700; color:${color};">${grade}</div>
          <div style="font-size:10px; color:#666;">out of 80 on-page pts</div>
        </div>
      </div>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px; margin-bottom:12px;">
        ${Object.values(modules).map(m => `
          <div style="background:rgba(255,255,255,0.05); border-radius:6px; padding:6px;">
            <div style="font-size:10px; color:#999;">${m.label}</div>
            <div style="font-size:14px; font-weight:700; color:${m.score/m.max >= 0.7 ? '#22c55e' : m.score/m.max >= 0.4 ? '#f59e0b' : '#ef4444'};">
              ${m.score}/${m.max}
            </div>
          </div>
        `).join('')}
      </div>
      ${criticalIssues.length > 0 ? `
        <div style="background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.3); border-radius:6px; padding:8px; margin-bottom:12px;">
          <div style="font-size:11px; font-weight:700; color:#ef4444; margin-bottom:4px;">⚠️ Critical Issues</div>
          ${criticalIssues.slice(0,2).map(i => `<div style="font-size:11px; color:#fca5a5;">• ${i.text}</div>`).join('')}
        </div>
      ` : ''}
      <a href="${fullAuditUrl}" target="_blank" style="
        display:block; background:#6366f1; color:#fff; text-align:center;
        padding:8px; border-radius:8px; text-decoration:none; font-weight:600;
        font-size:13px;
      ">Run Full Audit (E-E-A-T + Off-Site + Citation Check)</a>
    `;

    document.getElementById('cr-close')?.addEventListener('click', () => overlay.remove());
    document.body.appendChild(overlay);
    overlay.querySelector('#cr-close')?.addEventListener('click', () => overlay.remove());
  }

  // ─── Run ──────────────────────────────────────────────────────────────────

  runQuickAudit().then(buildOverlay).catch(console.error);
})();
