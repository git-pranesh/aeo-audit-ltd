# Blueprint Routes Patch

## New files to drop into /server:
- blueprint-signals.ts
- answer-capsule-engine.ts
- ai-bot-auditor.ts
- eeat-detector.ts
- offsite-scanner.ts
- community-scanner.ts
- blueprint-orchestrator.ts

## 1. Add import to routes.ts (after existing imports):
```
import { runBlueprintAudit } from './blueprint-orchestrator';
```

## 2. Wire into the audit handler (around line 3400, after scrapeWebsiteContent completes):

FIND this block in routes.ts:
```
const contentSignals = extractContentSignals(html, text, sitemapUrls, confirmedContext);
const scoringResult = calculatePlatformScoresV2(contentSignals, ...);
```

ADD AFTER it (non-blocking, runs in parallel with existing logic):
```
// Blueprint audit — runs in parallel, non-blocking on failure
let blueprintResult = null;
try {
  blueprintResult = await runBlueprintAudit({
    websiteUrl,
    html,
    text,
    sitemapUrls,
    brandName: companyName || domainName,
    companyName: companyName || domainName,
    industry: confirmedContext?.industry || '',
    primaryQuery: keywords?.[0] || '',
  });
} catch (err: any) {
  console.warn('⚠️ Blueprint audit failed (non-blocking):', err?.message);
}
```

## 3. Include blueprintResult in the final res.json response:

FIND:
```
res.json({
  success: true,
  websiteUrl: websiteUrl,
  auditData: auditData,
  auditId: auditId,
  generatedAt: new Date().toISOString()
});
```

REPLACE WITH:
```
res.json({
  success: true,
  websiteUrl: websiteUrl,
  auditData: {
    ...auditData,
    blueprintResult,  // Add blueprint result here
  },
  auditId: auditId,
  generatedAt: new Date().toISOString()
});
```

## 4. Add environment variables to Replit Secrets:

GOOGLE_KG_API_KEY
- Get free at: https://console.cloud.google.com/apis/library/kgsearch.googleapis.com
- Free tier: 100,000 requests/day
- Used for: E-E-A-T authority signals (is brand a recognized entity?)

No other new env vars needed.
- Wikidata: free, no auth
- Reddit: public JSON endpoints, no auth
- G2/Capterra/Trustpilot: URL existence checks, no auth

## 5. Frontend (audit-results.tsx) — add new blueprint section:

After the existing score breakdown section, add:

```tsx
{auditData.blueprintResult && (
  <section className="space-y-4">
    <h3 className="text-xl font-bold">AEO Blueprint Score</h3>
    <div className="grid grid-cols-4 gap-4">
      <ScoreCard label="Answer Capsule" score={auditData.blueprintResult.answerCapsule.answerCapsuleScore} max={25} />
      <ScoreCard label="E-E-A-T" score={auditData.blueprintResult.eeat.eeAtScore} max={35} />
      <ScoreCard label="Bot Access" score={auditData.blueprintResult.botAccess.botAccessScore} max={10} />
      <ScoreCard label="Off-Site" score={auditData.blueprintResult.offsite.offsiteScore} max={30} />
      <ScoreCard label="Freshness" score={auditData.blueprintResult.freshness.freshnessScore} max={15} />
      <ScoreCard label="Schema" score={auditData.blueprintResult.schemaCompleteness.schemaCompletenessScore} max={20} />
      <ScoreCard label="Fan-Out" score={auditData.blueprintResult.fanOut.fanOutScore} max={10} />
      <ScoreCard label="Entity" score={auditData.blueprintResult.entityConsistency.entityConsistencyScore} max={5} />
    </div>
    <div className="text-2xl font-bold">
      Blueprint Score: {auditData.blueprintResult.normalizedScore}/100
    </div>
    {auditData.blueprintResult.criticalGaps.length > 0 && (
      <div>
        <h4 className="font-bold text-red-600">Critical Gaps</h4>
        {auditData.blueprintResult.criticalGaps.map((gap, i) => (
          <div key={i} className="border-l-4 border-red-500 pl-3 my-2">
            <div className="font-medium">{gap.signal}</div>
            <div className="text-sm text-gray-600">{gap.fix}</div>
            <div className="text-sm text-green-600">+{gap.estimatedScoreGain} pts</div>
          </div>
        ))}
      </div>
    )}
  </section>
)}
```
