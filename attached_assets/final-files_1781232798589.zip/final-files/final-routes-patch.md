# Final Routes Patch — All Remaining Changes

## New files to add:
- server/llm-router.ts → drop into /server/
- client/src/components/blueprint-score-display.tsx → drop into /client/src/components/

---

## CHANGE 1: Add OpenRouter env var to Replit Secrets

Key name: OPENROUTER_API_KEY
Get key at: https://openrouter.ai/settings/keys
Free to create. You pay per call, no monthly fee.
Add credit: $10 is enough for thousands of audits.

---

## CHANGE 2: Update citation-snapshot-service.ts to use OpenRouter

Find the Perplexity API call in server/citation-snapshot-service.ts.
It likely uses OpenAI SDK with a custom baseURL pointing to api.perplexity.ai.

Find something like:
```typescript
const openai = new OpenAI({
  apiKey: process.env.PERPLEXITY_API_KEY || perplexityKey,
  baseURL: 'https://api.perplexity.ai',
});
```

Replace the API call initialization with:
```typescript
import { citationSnapshotCall } from './llm-router';
```

Then find where the actual API call is made (something like `openai.chat.completions.create()`).
Replace each API call with:
```typescript
const responseText = await citationSnapshotCall(promptContent, userByokKey);
```

Where `userByokKey` is the user's OpenRouter key from their account settings
(same as where you previously stored the Perplexity key — just rename the field).

The model `perplexity/sonar` on OpenRouter is the SAME live search model
as direct Perplexity API. Citations and live search work identically.

---

## CHANGE 3: Replace OpenAI calls with llm-router in routes.ts

Find all calls to OpenAI in routes.ts (search for "openai.chat.completions.create").
There should be 2-3 calls:
1. Company intelligence extraction
2. Topic generation
3. Content verification (if any)

For each call, replace with llm-router equivalent:

BEFORE (typical pattern):
```typescript
const completion = await openai.chat.completions.create({
  model: 'gpt-4o-mini',
  messages: [...],
  response_format: { type: 'json_object' }
});
const result = JSON.parse(completion.choices[0].message.content);
```

AFTER:
```typescript
import { llmJsonCall } from './llm-router';

const result = await llmJsonCall({
  task: 'companyIntelligence',   // or 'topicGeneration' depending on what the call does
  messages: [...],               // same messages array
  maxTokens: 1000,
});
```

---

## CHANGE 4: Add handleDodoApiWebhook call to existing Dodo webhook handler

Find the existing Dodo webhook handler in routes.ts.
Search for: `webhookSecret` or `verifyWebhookSignature` — it's around line 2770.

Inside that handler, after the signature verification succeeds and you parse the event,
add this line:

```typescript
import { handleDodoApiWebhook } from './dodo-api-billing';

// Add inside the webhook handler after signature verification:
await handleDodoApiWebhook({ type: event.type, data: event.data }).catch(err => {
  console.warn('⚠️ Dodo API webhook handler failed (non-blocking):', err?.message);
});
```

This hooks API subscription activations/cancellations into the API key system.

---

## CHANGE 5: Add BlueprintScoreDisplay to audit-results.tsx

At the top of client/src/components/audit-results.tsx, add import:
```typescript
import BlueprintScoreDisplay from '@/components/blueprint-score-display';
```

Inside the return JSX, after the existing score explanation section
(after the "Why These Scores?" collapsible block, around line 390),
add:

```tsx
{/* AEO Blueprint Score */}
{auditData.blueprintResult && (
  <BlueprintScoreDisplay blueprint={auditData.blueprintResult} />
)}
```

---

## CHANGE 6: Update BYOK field name in user settings (optional cleanup)

If you previously had a "Perplexity API Key" field in user settings,
rename it to "OpenRouter API Key" in the UI copy.
The backend field name in Firestore can stay as-is or be renamed to `openrouterKey`.

The BYOK flow:
- User goes to openrouter.ai → creates account → gets API key (sk-or-...)
- Pastes it in Citation Rocket settings
- All their AI calls (DeepSeek for cheap tasks + Perplexity Sonar for citation) go through their key
- They control and see all costs in their OpenRouter dashboard

---

## Summary: What each change does

| Change | File | What it does |
|--------|------|-------------|
| 1 | Replit Secrets | Adds OPENROUTER_API_KEY |
| 2 | citation-snapshot-service.ts | Routes Perplexity Sonar through OpenRouter |
| 3 | routes.ts | Routes GPT-4o calls to DeepSeek V4 Flash (18x cheaper) |
| 4 | routes.ts | Hooks API subscription events into API key billing |
| 5 | audit-results.tsx | Displays 8 blueprint module scores in UI |
| 6 | User settings UI | Renames "Perplexity key" to "OpenRouter key" |
