# AGENTS.md — Pressense

## Project Overview
**Website:** https://www.pressense.co/
**Company:** Pressense
**Industry:** Custom Internal Software Development
**Audience:** Founder-led B2B tech companies and SaaS startups needing scalable GTM systems

## What This Site Is
Diagnostic-first build partner fixing GTM with fractional CMO and custom software

## Key Topics
- Custom Internal Software Development

## Site Structure
- **Total pages:** 67
- **Documentation:** 2 pages at https://www.pressense.co//docs
- **Blog/Resources:** 2 posts at https://www.pressense.co//blog
- **FAQ:** Not available


## Content References
- llms.txt: https://www.pressense.co//llms.txt
- llms-full.txt: https://www.pressense.co//llms-full.txt
- Sitemap: https://www.pressense.co//sitemap.xml

## AI Crawling
This site welcomes crawling by all AI assistants. See robots.txt for details.
GPTBot, PerplexityBot, ClaudeBot, and GoogleExtendedBot are explicitly allowed.

## Contact
For questions about this site's content: https://www.pressense.co//contact

## Last Updated
2026-07-16